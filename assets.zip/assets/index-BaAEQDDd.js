function D2(e) {
	return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e
} ! function () {
	const e = document.createElement("link").relList;
	if (!(e && e.supports && e.supports("modulepreload"))) {
		for (const e of document.querySelectorAll('link[rel="modulepreload"]')) t(e);
		new MutationObserver(e => {
			for (const n of e)
				if ("childList" === n.type)
					for (const e of n.addedNodes) "LINK" === e.tagName && "modulepreload" === e.rel && t(e)
		}).observe(document, {
			childList: !0,
			subtree: !0
		})
	}

	function t(e) {
		if (e.ep) return;
		e.ep = !0;
		const t = function (e) {
			const t = {};
			return e.integrity && (t.integrity = e.integrity), e.referrerPolicy && (t.referrerPolicy = e.referrerPolicy), "use-credentials" === e.crossOrigin ? t.credentials = "include" : "anonymous" === e.crossOrigin ? t.credentials = "omit" : t.credentials = "same-origin", t
		}(e);
		fetch(e.href, t)
	}
}();
var by, xy, Af = {
	exports: {}
},
	hs = {};
/**
 * @license React
 * react-jsx-runtime.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
function N2() {
	if (by) return hs;
	by = 1;
	var e = Symbol.for("react.transitional.element"),
		t = Symbol.for("react.fragment");

	function n(t, n, r) {
		var i = null;
		if (void 0 !== r && (i = "" + r), void 0 !== n.key && (i = "" + n.key), "key" in n)
			for (var a in r = {}, n) "key" !== a && (r[a] = n[a]);
		else r = n;
		return n = r.ref, {
			$$typeof: e,
			type: t,
			key: i,
			ref: void 0 !== n ? n : null,
			props: r
		}
	}
	return hs.Fragment = t, hs.jsx = n, hs.jsxs = n, hs
}

function O2() {
	return xy || (xy = 1, Af.exports = N2()), Af.exports
}
var Sy, Ty, E = O2(),
	Mf = {
		exports: {}
	},
	dt = {};
/**
 * @license React
 * react.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
function z2() {
	if (Sy) return dt;
	Sy = 1;
	var e = Symbol.for("react.transitional.element"),
		t = Symbol.for("react.portal"),
		n = Symbol.for("react.fragment"),
		r = Symbol.for("react.strict_mode"),
		i = Symbol.for("react.profiler"),
		a = Symbol.for("react.consumer"),
		o = Symbol.for("react.context"),
		s = Symbol.for("react.forward_ref"),
		l = Symbol.for("react.suspense"),
		u = Symbol.for("react.memo"),
		c = Symbol.for("react.lazy"),
		d = Symbol.for("react.activity"),
		f = Symbol.for("react.view_transition"),
		h = Symbol.iterator;
	var p = {
		isMounted: function () {
			return !1
		},
		enqueueForceUpdate: function () { },
		enqueueReplaceState: function () { },
		enqueueSetState: function () { }
	},
		m = Object.assign,
		g = {};

	function v(e, t, n) {
		this.props = e, this.context = t, this.refs = g, this.updater = n || p
	}

	function y() { }

	function b(e, t, n) {
		this.props = e, this.context = t, this.refs = g, this.updater = n || p
	}
	v.prototype.isReactComponent = {}, v.prototype.setState = function (e, t) {
		if ("object" != typeof e && "function" != typeof e && null != e) throw Error("takes an object of state variables to update or a function which returns an object of state variables.");
		this.updater.enqueueSetState(this, e, t, "setState")
	}, v.prototype.forceUpdate = function (e) {
		this.updater.enqueueForceUpdate(this, e, "forceUpdate")
	}, y.prototype = v.prototype;
	var x = b.prototype = new y;
	x.constructor = b, m(x, v.prototype), x.isPureReactComponent = !0;
	var w = Array.isArray;

	function S() { }
	var E = {
		H: null,
		A: null,
		T: null,
		S: null
	},
		k = Object.prototype.hasOwnProperty;

	function T(t, n, r) {
		var i = r.ref;
		return {
			$$typeof: e,
			type: t,
			key: n,
			ref: void 0 !== i ? i : null,
			props: r
		}
	}

	function P(t) {
		return "object" == typeof t && null !== t && t.$$typeof === e
	}
	var C = /\/+/g;

	function N(e, t) {
		return "object" == typeof e && null !== e && null != e.key ? function (e) {
			var t = {
				"=": "=0",
				":": "=2"
			};
			return "$" + e.replace(/[=:]/g, function (e) {
				return t[e]
			})
		}("" + e.key) : t.toString(36)
	}

	function M(n, r, i, a, o) {
		var s = typeof n;
		("undefined" === s || "boolean" === s) && (n = null);
		var l = !1;
		if (null === n) l = !0;
		else switch (s) {
			case "bigint":
			case "string":
			case "number":
				l = !0;
				break;
			case "object":
				switch (n.$$typeof) {
					case e:
					case t:
						l = !0;
						break;
					case c:
						return M((l = n._init)(n._payload), r, i, a, o)
				}
		}
		if (l) return o = o(n), l = "" === a ? "." + N(n, 0) : a, w(o) ? (i = "", null != l && (i = l.replace(C, "$&/") + "/"), M(o, r, i, "", function (e) {
			return e
		})) : null != o && (P(o) && (o = function (e, t) {
			return T(e.type, t, e.props)
		}(o, i + (null == o.key || n && n.key === o.key ? "" : ("" + o.key).replace(C, "$&/") + "/") + l)), r.push(o)), 1;
		l = 0;
		var u = "" === a ? "." : a + ":";
		if (w(n))
			for (var d = 0; d < n.length; d++) l += M(a = n[d], r, i, s = u + N(a, d), o);
		else if (d = function (e) {
			return null === e || "object" != typeof e ? null : "function" == typeof (e = h && e[h] || e["@@iterator"]) ? e : null
		}(n), "function" == typeof d)
			for (n = d.call(n), d = 0; !(a = n.next()).done;) l += M(a = a.value, r, i, s = u + N(a, d++), o);
		else if ("object" === s) {
			if ("function" == typeof n.then) return M(function (e) {
				switch (e.status) {
					case "fulfilled":
						return e.value;
					case "rejected":
						throw e.reason;
					default:
						switch ("string" == typeof e.status ? e.then(S, S) : (e.status = "pending", e.then(function (t) {
							"pending" === e.status && (e.status = "fulfilled", e.value = t)
						}, function (t) {
							"pending" === e.status && (e.status = "rejected", e.reason = t)
						})), e.status) {
							case "fulfilled":
								return e.value;
							case "rejected":
								throw e.reason
						}
				}
				throw e
			}(n), r, i, a, o);
			throw r = String(n), Error("Objects are not valid as a React child (found: " + ("[object Object]" === r ? "object with keys {" + Object.keys(n).join(", ") + "}" : r) + "). If you meant to render a collection of children, use an array instead.")
		}
		return l
	}

	function A(e, t, n) {
		if (null == e) return e;
		var r = [],
			i = 0;
		return M(e, r, "", "", function (e) {
			return t.call(n, e, i++)
		}), r
	}

	function _(e) {
		if (-1 === e._status) {
			var t = (0, e._result)();
			t.then(function (n) {
				(0 === e._status || -1 === e._status) && (e._status = 1, e._result = n, void 0 === t.status && (t.status = "fulfilled", t.value = n))
			}, function (n) {
				(0 === e._status || -1 === e._status) && (e._status = 2, e._result = n, void 0 === t.status && (t.status = "rejected", t.reason = n))
			}), -1 === e._status && (e._status = 0, e._result = t)
		}
		if (1 === e._status) return e._result.default;
		throw e._result
	}
	var L = "function" == typeof reportError ? reportError : function (e) {
		if ("object" == typeof window && "function" == typeof window.ErrorEvent) {
			var t = new window.ErrorEvent("error", {
				bubbles: !0,
				cancelable: !0,
				message: "object" == typeof e && null !== e && "string" == typeof e.message ? String(e.message) : String(e),
				error: e
			});
			if (!window.dispatchEvent(t)) return
		} else if ("object" == typeof process && "function" == typeof process.emit) return void process.emit("uncaughtException", e);
		console.error(e)
	};

	function D(e) {
		var t = E.T,
			n = {};
		n.types = null !== t ? t.types : null, E.T = n;
		try {
			var r = e(),
				i = E.S;
			null !== i && i(n, r), "object" == typeof r && null !== r && "function" == typeof r.then && r.then(S, L)
		} catch (e) {
			L(e)
		} finally {
			null !== t && null !== n.types && (t.types = n.types), E.T = t
		}
	}
	var j = {
		map: A,
		forEach: function (e, t, n) {
			A(e, function () {
				t.apply(this, arguments)
			}, n)
		},
		count: function (e) {
			var t = 0;
			return A(e, function () {
				t++
			}), t
		},
		toArray: function (e) {
			return A(e, function (e) {
				return e
			}) || []
		},
		only: function (e) {
			if (!P(e)) throw Error("React.Children.only expected to receive a single React element child.");
			return e
		}
	};
	return dt.Activity = d, dt.Children = j, dt.Component = v, dt.Fragment = n, dt.Profiler = i, dt.PureComponent = b, dt.StrictMode = r, dt.Suspense = l, dt.ViewTransition = f, dt.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = E, dt.__COMPILER_RUNTIME = {
		__proto__: null,
		c: function (e) {
			return E.H.useMemoCache(e)
		}
	}, dt.addTransitionType = function e(t) {
		var n = E.T;
		if (null !== n) {
			var r = n.types;
			null === r ? n.types = [t] : -1 === r.indexOf(t) && r.push(t)
		} else D(e.bind(null, t))
	}, dt.cache = function (e) {
		return function () {
			return e.apply(null, arguments)
		}
	}, dt.cacheSignal = function () {
		return null
	}, dt.cloneElement = function (e, t, n) {
		if (null == e) throw Error("The argument must be a React element, but you passed " + e + ".");
		var r = m({}, e.props),
			i = e.key;
		if (null != t)
			for (a in void 0 !== t.key && (i = "" + t.key), t) !k.call(t, a) || "key" === a || "__self" === a || "__source" === a || "ref" === a && void 0 === t.ref || (r[a] = t[a]);
		var a = arguments.length - 2;
		if (1 === a) r.children = n;
		else if (1 < a) {
			for (var o = Array(a), s = 0; s < a; s++) o[s] = arguments[s + 2];
			r.children = o
		}
		return T(e.type, i, r)
	}, dt.createContext = function (e) {
		return (e = {
			$$typeof: o,
			_currentValue: e,
			_currentValue2: e,
			_threadCount: 0,
			Provider: null,
			Consumer: null
		}).Provider = e, e.Consumer = {
			$$typeof: a,
			_context: e
		}, e
	}, dt.createElement = function (e, t, n) {
		var r, i = {},
			a = null;
		if (null != t)
			for (r in void 0 !== t.key && (a = "" + t.key), t) k.call(t, r) && "key" !== r && "__self" !== r && "__source" !== r && (i[r] = t[r]);
		var o = arguments.length - 2;
		if (1 === o) i.children = n;
		else if (1 < o) {
			for (var s = Array(o), l = 0; l < o; l++) s[l] = arguments[l + 2];
			i.children = s
		}
		if (e && e.defaultProps)
			for (r in o = e.defaultProps) void 0 === i[r] && (i[r] = o[r]);
		return T(e, a, i)
	}, dt.createRef = function () {
		return {
			current: null
		}
	}, dt.forwardRef = function (e) {
		return {
			$$typeof: s,
			render: e
		}
	}, dt.isValidElement = P, dt.lazy = function (e) {
		return {
			$$typeof: c,
			_payload: {
				_status: -1,
				_result: e
			},
			_init: _
		}
	}, dt.memo = function (e, t) {
		return {
			$$typeof: u,
			type: e,
			compare: void 0 === t ? null : t
		}
	}, dt.startTransition = D, dt.unstable_useCacheRefresh = function () {
		return E.H.useCacheRefresh()
	}, dt.use = function (e) {
		return E.H.use(e)
	}, dt.useActionState = function (e, t, n) {
		return E.H.useActionState(e, t, n)
	}, dt.useCallback = function (e, t) {
		return E.H.useCallback(e, t)
	}, dt.useContext = function (e) {
		return E.H.useContext(e)
	}, dt.useDebugValue = function () { }, dt.useDeferredValue = function (e, t) {
		return E.H.useDeferredValue(e, t)
	}, dt.useEffect = function (e, t) {
		return E.H.useEffect(e, t)
	}, dt.useEffectEvent = function (e) {
		return E.H.useEffectEvent(e)
	}, dt.useId = function () {
		return E.H.useId()
	}, dt.useImperativeHandle = function (e, t, n) {
		return E.H.useImperativeHandle(e, t, n)
	}, dt.useInsertionEffect = function (e, t) {
		return E.H.useInsertionEffect(e, t)
	}, dt.useLayoutEffect = function (e, t) {
		return E.H.useLayoutEffect(e, t)
	}, dt.useMemo = function (e, t) {
		return E.H.useMemo(e, t)
	}, dt.useOptimistic = function (e, t) {
		return E.H.useOptimistic(e, t)
	}, dt.useReducer = function (e, t, n) {
		return E.H.useReducer(e, t, n)
	}, dt.useRef = function (e) {
		return E.H.useRef(e)
	}, dt.useState = function (e) {
		return E.H.useState(e)
	}, dt.useSyncExternalStore = function (e, t, n) {
		return E.H.useSyncExternalStore(e, t, n)
	}, dt.useTransition = function () {
		return E.H.useTransition()
	}, dt.version = "19.3.0", dt
}

function xd() {
	return Ty || (Ty = 1, Mf.exports = z2()), Mf.exports
}
var Z = xd();
const co = D2(Z);
var Ey, Ay, Cf = {
	exports: {}
},
	ms = {},
	Df = {
		exports: {}
	},
	Nf = {};
/**
 * @license React
 * scheduler.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
function w2() {
	return Ey || (Ey = 1, function (e) {
		function t(e, t) {
			var n = e.length;
			e.push(t);
			e: for (; 0 < n;) {
				var r = n - 1 >>> 1,
					a = e[r];
				if (!(0 < i(a, t))) break e;
				e[r] = t, e[n] = a, n = r
			}
		}

		function n(e) {
			return 0 === e.length ? null : e[0]
		}

		function r(e) {
			if (0 === e.length) return null;
			var t = e[0],
				n = e.pop();
			if (n !== t) {
				e[0] = n;
				e: for (var r = 0, a = e.length, o = a >>> 1; r < o;) {
					var s = 2 * (r + 1) - 1,
						l = e[s],
						u = s + 1,
						c = e[u];
					if (0 > i(l, n)) u < a && 0 > i(c, l) ? (e[r] = c, e[u] = n, r = u) : (e[r] = l, e[s] = n, r = s);
					else {
						if (!(u < a && 0 > i(c, n))) break e;
						e[r] = c, e[u] = n, r = u
					}
				}
			}
			return t
		}

		function i(e, t) {
			var n = e.sortIndex - t.sortIndex;
			return 0 !== n ? n : e.id - t.id
		}
		if (e.unstable_now = void 0, "object" == typeof performance && "function" == typeof performance.now) {
			var a = performance;
			e.unstable_now = function () {
				return a.now()
			}
		} else {
			var o = Date,
				s = o.now();
			e.unstable_now = function () {
				return o.now() - s
			}
		}
		var l = [],
			u = [],
			c = 1,
			d = null,
			f = 3,
			h = !1,
			p = !1,
			m = !1,
			g = !1,
			v = "function" == typeof setTimeout ? setTimeout : null,
			y = "function" == typeof clearTimeout ? clearTimeout : null,
			b = typeof setImmediate < "u" ? setImmediate : null;

		function x(e) {
			for (var i = n(u); null !== i;) {
				if (null === i.callback) r(u);
				else {
					if (!(i.startTime <= e)) break;
					r(u), i.sortIndex = i.expirationTime, t(l, i)
				}
				i = n(u)
			}
		}

		function w(e) {
			if (m = !1, x(e), !p)
				if (null !== n(l)) p = !0, E || (E = !0, S());
				else {
					var t = n(u);
					null !== t && _(w, t.startTime - e)
				}
		}
		var S, E = !1,
			k = -1,
			T = 5,
			P = -1;

		function C() {
			return !!g || !(e.unstable_now() - P < T)
		}

		function N() {
			if (g = !1, E) {
				var t = e.unstable_now();
				P = t;
				var i = !0;
				try {
					e: {
						p = !1,
							m && (m = !1, y(k), k = -1),
							h = !0;
						var a = f;
						try {
							t: {
								for (x(t), d = n(l); null !== d && !(d.expirationTime > t && C());) {
									var o = d.callback;
									if ("function" == typeof o) {
										d.callback = null, f = d.priorityLevel;
										var s = o(d.expirationTime <= t);
										if (t = e.unstable_now(), "function" == typeof s) {
											d.callback = s, x(t), i = !0;
											break t
										}
										d === n(l) && r(l), x(t)
									} else r(l);
									d = n(l)
								}
								if (null !== d) i = !0;
								else {
									var c = n(u);
									null !== c && _(w, c.startTime - t), i = !1
								}
							}
							break e
						}
						finally {
							d = null, f = a, h = !1
						}
						i = void 0
					}
				}
				finally {
					i ? S() : E = !1
				}
			}
		}
		if ("function" == typeof b) S = function () {
			b(N)
		};
		else if (typeof MessageChannel < "u") {
			var M = new MessageChannel,
				A = M.port2;
			M.port1.onmessage = N, S = function () {
				A.postMessage(null)
			}
		} else S = function () {
			v(N, 0)
		};

		function _(t, n) {
			k = v(function () {
				t(e.unstable_now())
			}, n)
		}
		e.unstable_IdlePriority = 5, e.unstable_ImmediatePriority = 1, e.unstable_LowPriority = 4, e.unstable_NormalPriority = 3, e.unstable_Profiling = null, e.unstable_UserBlockingPriority = 2, e.unstable_cancelCallback = function (e) {
			e.callback = null
		}, e.unstable_forceFrameRate = function (e) {
			0 > e || 125 < e ? console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported") : T = 0 < e ? Math.floor(1e3 / e) : 5
		}, e.unstable_getCurrentPriorityLevel = function () {
			return f
		}, e.unstable_next = function (e) {
			switch (f) {
				case 1:
				case 2:
				case 3:
					var t = 3;
					break;
				default:
					t = f
			}
			var n = f;
			f = t;
			try {
				return e()
			} finally {
				f = n
			}
		}, e.unstable_requestPaint = function () {
			g = !0
		}, e.unstable_runWithPriority = function (e, t) {
			switch (e) {
				case 1:
				case 2:
				case 3:
				case 4:
				case 5:
					break;
				default:
					e = 3
			}
			var n = f;
			f = e;
			try {
				return t()
			} finally {
				f = n
			}
		}, e.unstable_scheduleCallback = function (r, i, a) {
			var o = e.unstable_now();
			switch ("object" == typeof a && null !== a ? a = "number" == typeof (a = a.delay) && 0 < a ? o + a : o : a = o, r) {
				case 1:
					var s = -1;
					break;
				case 2:
					s = 250;
					break;
				case 5:
					s = 1073741823;
					break;
				case 4:
					s = 1e4;
					break;
				default:
					s = 5e3
			}
			return r = {
				id: c++,
				callback: i,
				priorityLevel: r,
				startTime: a,
				expirationTime: s = a + s,
				sortIndex: -1
			}, a > o ? (r.sortIndex = a, t(u, r), null === n(l) && r === n(u) && (m ? (y(k), k = -1) : m = !0, _(w, a - o))) : (r.sortIndex = s, t(l, r), p || h || (p = !0, E || (E = !0, S()))), r
		}, e.unstable_shouldYield = C, e.unstable_wrapCallback = function (e) {
			var t = f;
			return function () {
				var n = f;
				f = t;
				try {
					return e.apply(this, arguments)
				} finally {
					f = n
				}
			}
		}
	}(Nf)), Nf
}

function _2() {
	return Ay || (Ay = 1, Df.exports = w2()), Df.exports
}
var My, Cy, Dy, Ny, Of = {
	exports: {}
},
	be = {};
/**
 * @license React
 * react-dom.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
function R2() {
	if (My) return be;
	My = 1;
	var e = xd();

	function t(e) {
		var t = "https://react.dev/errors/" + e;
		if (1 < arguments.length) {
			t += "?args[]=" + encodeURIComponent(arguments[1]);
			for (var n = 2; n < arguments.length; n++) t += "&args[]=" + encodeURIComponent(arguments[n])
		}
		return "Minified React error #" + e + "; visit " + t + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings."
	}

	function n() { }
	var r = {
		d: {
			f: n,
			r: function () {
				throw Error(t(522))
			},
			D: n,
			C: n,
			L: n,
			m: n,
			X: n,
			S: n,
			M: n
		},
		p: 0,
		findDOMNode: null
	},
		i = Symbol.for("react.portal"),
		a = Symbol.for("react.recoverable"),
		o = Symbol.for("react.optimistic_key");
	var s = e.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;

	function l(e, t) {
		return "font" === e ? "" : "string" == typeof t ? "use-credentials" === t ? t : "" : void 0
	}
	return be.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = r, be.browser = function (e) {
		return {
			$$typeof: a,
			_reason: e
		}
	}, be.createPortal = function (e, n) {
		var r = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : null;
		if (!n || 1 !== n.nodeType && 9 !== n.nodeType && 11 !== n.nodeType) throw Error(t(299));
		return function (e, t, n) {
			var r = 3 < arguments.length && void 0 !== arguments[3] ? arguments[3] : null;
			return {
				$$typeof: i,
				key: null == r ? null : r === o ? o : "" + r,
				children: e,
				containerInfo: t,
				implementation: n
			}
		}(e, n, null, r)
	}, be.flushSync = function (e) {
		var t = s.T,
			n = r.p;
		try {
			if (s.T = null, r.p = 2, e) return e()
		} finally {
			s.T = t, r.p = n, r.d.f()
		}
	}, be.preconnect = function (e, t) {
		"string" == typeof e && (t ? t = "string" == typeof (t = t.crossOrigin) ? "use-credentials" === t ? t : "" : void 0 : t = null, r.d.C(e, t))
	}, be.prefetchDNS = function (e) {
		"string" == typeof e && r.d.D(e)
	}, be.preinit = function (e, t) {
		if ("string" == typeof e && t && "string" == typeof t.as) {
			var n = t.as,
				i = l(n, t.crossOrigin),
				a = "string" == typeof t.integrity ? t.integrity : void 0,
				o = "string" == typeof t.fetchPriority ? t.fetchPriority : void 0;
			"style" === n ? r.d.S(e, "string" == typeof t.precedence ? t.precedence : void 0, {
				crossOrigin: i,
				integrity: a,
				fetchPriority: o
			}) : "script" === n && r.d.X(e, {
				crossOrigin: i,
				integrity: a,
				fetchPriority: o,
				nonce: "string" == typeof t.nonce ? t.nonce : void 0
			})
		}
	}, be.preinitModule = function (e, t) {
		if ("string" == typeof e)
			if ("object" == typeof t && null !== t) {
				if (null == t.as || "script" === t.as) {
					var n = l(t.as, t.crossOrigin);
					r.d.M(e, {
						crossOrigin: n,
						integrity: "string" == typeof t.integrity ? t.integrity : void 0,
						nonce: "string" == typeof t.nonce ? t.nonce : void 0,
						fetchPriority: "string" == typeof t.fetchPriority ? t.fetchPriority : void 0
					})
				}
			} else null == t && r.d.M(e)
	}, be.preload = function (e, t) {
		if ("string" == typeof e && "object" == typeof t && null !== t && "string" == typeof t.as) {
			var n = t.as,
				i = l(n, t.crossOrigin);
			r.d.L(e, n, {
				crossOrigin: i,
				integrity: "string" == typeof t.integrity ? t.integrity : void 0,
				nonce: "string" == typeof t.nonce ? t.nonce : void 0,
				type: "string" == typeof t.type ? t.type : void 0,
				fetchPriority: "string" == typeof t.fetchPriority ? t.fetchPriority : void 0,
				referrerPolicy: "string" == typeof t.referrerPolicy ? t.referrerPolicy : void 0,
				imageSrcSet: "string" == typeof t.imageSrcSet ? t.imageSrcSet : void 0,
				imageSizes: "string" == typeof t.imageSizes ? t.imageSizes : void 0,
				media: "string" == typeof t.media ? t.media : void 0
			})
		}
	}, be.preloadModule = function (e, t) {
		if ("string" == typeof e)
			if (t) {
				var n = l(t.as, t.crossOrigin);
				r.d.m(e, {
					as: "string" == typeof t.as && "script" !== t.as ? t.as : void 0,
					crossOrigin: n,
					integrity: "string" == typeof t.integrity ? t.integrity : void 0,
					nonce: "string" == typeof t.nonce ? t.nonce : void 0,
					fetchPriority: "string" == typeof t.fetchPriority ? t.fetchPriority : void 0
				})
			} else r.d.m(e)
	}, be.requestFormReset = function (e) {
		r.d.r(e)
	}, be.unstable_batchedUpdates = function (e, t) {
		return e(t)
	}, be.useFormState = function (e, t, n) {
		return s.H.useFormState(e, t, n)
	}, be.useFormStatus = function () {
		return s.H.useHostTransitionStatus()
	}, be.version = "19.3.0", be
}

function j2() {
	if (Cy) return Of.exports;
	return Cy = 1,
		function e() {
			if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" || "function" != typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE)) try {
				__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(e)
			} catch (e) {
				console.error(e)
			}
		}(), Of.exports = R2(), Of.exports
}
/**
 * @license React
 * react-dom-client.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
function V2() {
	if (Dy) return ms;
	Dy = 1;
	var e = _2(),
		t = xd(),
		n = j2();

	function r(e) {
		var t = "https://react.dev/errors/" + e;
		if (1 < arguments.length) {
			t += "?args[]=" + encodeURIComponent(arguments[1]);
			for (var n = 2; n < arguments.length; n++) t += "&args[]=" + encodeURIComponent(arguments[n])
		}
		return "Minified React error #" + e + "; visit " + t + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings."
	}

	function i(e) {
		return !(!e || 1 !== e.nodeType && 9 !== e.nodeType && 11 !== e.nodeType)
	}

	function a(e) {
		for (var t = e, n = t; n && !n.alternate;) !!(4098 & (t = n).flags) && (e = t.return), n = t.return;
		for (; t.return;) t = t.return;
		return 3 === t.tag ? e : null
	}

	function o(e) {
		if (13 === e.tag) {
			var t = e.memoizedState;
			if (null === t && (null !== (e = e.alternate) && (t = e.memoizedState)), null !== t) return t.dehydrated
		}
		return null
	}

	function s(e) {
		if (31 === e.tag) {
			var t = e.memoizedState;
			if (null === t && (null !== (e = e.alternate) && (t = e.memoizedState)), null !== t) return t.dehydrated
		}
		return null
	}

	function l(e) {
		if (a(e) !== e) throw Error(r(188))
	}

	function u(e) {
		var t = e.tag;
		if (5 === t || 26 === t || 27 === t || 6 === t) return e;
		for (e = e.child; null !== e;) {
			if (null !== (t = u(e))) return t;
			e = e.sibling
		}
		return null
	}

	function c(e, t, n, r, i, a) {
		for (; null !== e;) {
			if ((5 === e.tag || 27 === e.tag || 6 === e.tag) && n(e, r, i, a) || (22 !== e.tag || null === e.memoizedState) && (t || 5 !== e.tag && 27 !== e.tag) && c(e.child, t, n, r, i, a)) return !0;
			e = e.sibling
		}
		return !1
	}

	function d(e) {
		for (e = e.return; null !== e;) {
			if (3 === e.tag || 5 === e.tag || 27 === e.tag) return e;
			e = e.return
		}
		return null
	}

	function f(e) {
		var t = !1;
		for (e = e.return; null !== e && (4 === e.tag && (t = !0), 3 !== e.tag && 5 !== e.tag && 27 !== e.tag);) e = e.return;
		return t
	}

	function h(e) {
		var t = [null, null],
			n = d(e);
		return null === n || p(t, e, n.child, {
			foundSelf: !1
		}), t
	}

	function p(e, t, n, r) {
		for (; null !== n;) {
			if (n === t) r.foundSelf = !0;
			else if (5 === n.tag || 27 === n.tag || 6 === n.tag) {
				if (r.foundSelf) return e[1] = n, !0;
				e[0] = n
			} else if ((22 !== n.tag || null === n.memoizedState) && p(e, t, n.child, r)) return !0;
			n = n.sibling
		}
		return !1
	}

	function m(e) {
		switch (e.tag) {
			case 5:
			case 27:
			case 6:
				return e.stateNode;
			case 3:
				return e.stateNode.containerInfo;
			default:
				throw Error(r(559))
		}
	}
	var g = null,
		v = null;

	function y(e, t, n) {
		return e === n || e === t && (g = e, !0)
	}

	function b(e, t, n) {
		return e === n ? (v = e, !1) : e === t && (null !== v && (g = e), !0)
	}

	function x(e) {
		if (null === e) return null;
		do {
			e = null === e ? null : e.return
		} while (e && 5 !== e.tag && 27 !== e.tag && 3 !== e.tag);
		return e || null
	}

	function w(e, t, n) {
		for (var r = 0, i = e; i; i = n(i)) r++;
		i = 0;
		for (var a = t; a; a = n(a)) i++;
		for (; 0 < r - i;) e = n(e), r--;
		for (; 0 < i - r;) t = n(t), i--;
		for (; r--;) {
			if (e === t || null !== t && e === t.alternate) return e;
			e = n(e), t = n(t)
		}
		return null
	}
	var S = Object.assign,
		E = Symbol.for("react.element"),
		k = Symbol.for("react.transitional.element"),
		T = Symbol.for("react.portal"),
		P = Symbol.for("react.fragment"),
		C = Symbol.for("react.strict_mode"),
		N = Symbol.for("react.profiler"),
		M = Symbol.for("react.consumer"),
		A = Symbol.for("react.context"),
		_ = Symbol.for("react.forward_ref"),
		L = Symbol.for("react.suspense"),
		D = Symbol.for("react.suspense_list"),
		j = Symbol.for("react.memo"),
		O = Symbol.for("react.lazy"),
		z = Symbol.for("react.activity"),
		R = Symbol.for("react.legacy_hidden"),
		F = Symbol.for("react.memo_cache_sentinel"),
		I = Symbol.for("react.view_transition"),
		V = Symbol.for("react.recoverable"),
		B = Symbol.iterator;

	function U(e) {
		return null === e || "object" != typeof e ? null : "function" == typeof (e = B && e[B] || e["@@iterator"]) ? e : null
	}
	var H = Symbol.for("react.client.reference");

	function $(e) {
		if (null == e) return null;
		if ("function" == typeof e) return e.$$typeof === H ? null : e.displayName || e.name || null;
		if ("string" == typeof e) return e;
		switch (e) {
			case P:
				return "Fragment";
			case N:
				return "Profiler";
			case C:
				return "StrictMode";
			case L:
				return "Suspense";
			case D:
				return "SuspenseList";
			case z:
				return "Activity";
			case I:
				return "ViewTransition"
		}
		if ("object" == typeof e) switch (e.$$typeof) {
			case T:
				return "Portal";
			case A:
				return e.displayName || "Context";
			case M:
				return (e._context.displayName || "Context") + ".Consumer";
			case _:
				var t = e.render;
				return (e = e.displayName) || (e = "" !== (e = t.displayName || t.name || "") ? "ForwardRef(" + e + ")" : "ForwardRef"), e;
			case j:
				return null !== (t = e.displayName || null) ? t : $(e.type) || "Memo";
			case O:
				t = e._payload, e = e._init;
				try {
					return $(e(t))
				} catch { }
		}
		return null
	}
	var W = Array.isArray,
		Z = t.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,
		Y = n.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,
		q = {
			pending: !1,
			data: null,
			method: null,
			action: null
		},
		K = [],
		Q = -1;

	function X(e) {
		return {
			current: e
		}
	}

	function G(e) {
		0 > Q || (e.current = K[Q], K[Q] = null, Q--)
	}

	function J(e, t) {
		Q++, K[Q] = e.current, e.current = t
	}
	var ee, te, ne = X(null),
		re = X(null),
		ie = X(null),
		ae = X(null);

	function oe(e, t) {
		switch (J(ie, t), J(re, e), J(ne, null), t.nodeType) {
			case 9:
			case 11:
				e = (e = t.documentElement) && (e = e.namespaceURI) ? zf(e) : 0;
				break;
			default:
				if (e = t.tagName, t = t.namespaceURI) e = Rf(t = zf(t), e);
				else switch (e) {
					case "svg":
						e = 1;
						break;
					case "math":
						e = 2;
						break;
					default:
						e = 0
				}
		}
		G(ne), J(ne, e)
	}

	function se() {
		G(ne), G(re), G(ie)
	}

	function le(e) {
		var t = e.memoizedState;
		null !== t && (up._currentValue = t.memoizedState, J(ae, e));
		var n = Rf(t = ne.current, e.type);
		t !== n && (J(re, e), J(ne, n))
	}

	function ue(e) {
		re.current === e && (G(ne), G(re)), ae.current === e && (G(ae), up._currentValue = q)
	}

	function ce(e) {
		if (void 0 === ee) try {
			throw Error()
		} catch (e) {
			var t = e.stack.trim().match(/\n( *(at )?)/);
			ee = t && t[1] || "", te = -1 < e.stack.indexOf("\n    at") ? " (<anonymous>)" : -1 < e.stack.indexOf("@") ? "@unknown:0:0" : ""
		}
		return "\n" + ee + e + te
	}
	var de = !1;

	function fe(e, t) {
		if (!e || de) return "";
		de = !0;
		var n = Error.prepareStackTrace;
		Error.prepareStackTrace = void 0;
		try {
			var r = {
				DetermineComponentFrameRoot: function () {
					try {
						if (t) {
							var n = function () {
								throw Error()
							};
							if (Object.defineProperty(n.prototype, "props", {
								set: function () {
									throw Error()
								}
							}), "object" == typeof Reflect && Reflect.construct) {
								try {
									Reflect.construct(n, [])
								} catch (e) {
									var r = e
								}
								Reflect.construct(e, [], n)
							} else {
								try {
									n.call()
								} catch (e) {
									r = e
								}
								n = !1;
								try {
									var i = Object.getOwnPropertyDescriptor(e.prototype, "props");
									Object.defineProperty(e.prototype, "props", {
										configurable: !0,
										set: function () {
											throw Error()
										}
									}), n = !0, new e
								} finally {
									n && (void 0 !== i ? Object.defineProperty(e.prototype, "props", i) : delete e.prototype.props)
								}
							}
						} else {
							try {
								throw Error()
							} catch (e) {
								r = e
							} (n = e()) && "function" == typeof n.catch && n.catch(function () { })
						}
					} catch (e) {
						if (e && r && "string" == typeof e.stack) return [e.stack, r.stack]
					}
					return [null, null]
				}
			};
			r.DetermineComponentFrameRoot.displayName = "DetermineComponentFrameRoot";
			var i = Object.getOwnPropertyDescriptor(r.DetermineComponentFrameRoot, "name");
			i && i.configurable && Object.defineProperty(r.DetermineComponentFrameRoot, "name", {
				value: "DetermineComponentFrameRoot"
			});
			var a = r.DetermineComponentFrameRoot(),
				o = a[0],
				s = a[1];
			if (o && s) {
				var l = o.split("\n"),
					u = s.split("\n");
				for (i = r = 0; r < l.length && !l[r].includes("DetermineComponentFrameRoot");) r++;
				for (; i < u.length && !u[i].includes("DetermineComponentFrameRoot");) i++;
				if (r === l.length || i === u.length)
					for (r = l.length - 1, i = u.length - 1; 1 <= r && 0 <= i && l[r] !== u[i];) i--;
				for (; 1 <= r && 0 <= i; r--, i--)
					if (l[r] !== u[i]) {
						if (1 !== r || 1 !== i)
							do {
								if (r--, 0 > --i || l[r] !== u[i]) {
									var c = "\n" + l[r].replace(" at new ", " at ");
									return e.displayName && c.includes("<anonymous>") && (c = c.replace("<anonymous>", e.displayName)), c
								}
							} while (1 <= r && 0 <= i);
						break
					}
			}
		} finally {
			de = !1, Error.prepareStackTrace = n
		}
		return (n = e ? e.displayName || e.name : "") ? ce(n) : ""
	}

	function he(e, t) {
		switch (e.tag) {
			case 26:
			case 27:
			case 5:
				return ce(e.type);
			case 16:
				return ce("Lazy");
			case 13:
				return e.child !== t && null !== t ? ce("Suspense Fallback") : ce("Suspense");
			case 19:
				return ce("SuspenseList");
			case 0:
			case 15:
				return fe(e.type, !1);
			case 11:
				return fe(e.type.render, !1);
			case 1:
				return fe(e.type, !0);
			case 31:
				return ce("Activity");
			case 30:
				return ce("ViewTransition");
			default:
				return ""
		}
	}

	function pe(e) {
		try {
			var t = "",
				n = null;
			do {
				t += he(e, n), n = e, e = e.return
			} while (e);
			return t
		} catch (e) {
			return "\nError generating stack: " + e.message + "\n" + e.stack
		}
	}
	var me = Object.prototype.hasOwnProperty,
		ge = e.unstable_scheduleCallback,
		ve = e.unstable_cancelCallback,
		ye = e.unstable_shouldYield,
		be = e.unstable_requestPaint,
		xe = e.unstable_now,
		we = e.unstable_getCurrentPriorityLevel,
		Se = e.unstable_ImmediatePriority,
		Ee = e.unstable_UserBlockingPriority,
		ke = e.unstable_NormalPriority,
		Te = e.unstable_LowPriority,
		Pe = e.unstable_IdlePriority,
		Ce = e.log,
		Ne = e.unstable_setDisableYieldValue,
		Me = null,
		Ae = null;

	function _e(e) {
		if ("function" == typeof Ce && Ne(e), Ae && "function" == typeof Ae.setStrictMode) try {
			Ae.setStrictMode(Me, e)
		} catch { }
	}
	var Le = Math.clz32 ? Math.clz32 : function (e) {
		return 0 == (e >>>= 0) ? 32 : 31 - (De(e) / je | 0) | 0
	},
		De = Math.log,
		je = Math.LN2;
	var Oe = 256,
		ze = 262144,
		Re = 4194304;

	function Fe(e) {
		var t = 42 & e;
		if (0 !== t) return t;
		switch (e & -e) {
			case 1:
				return 1;
			case 2:
				return 2;
			case 4:
				return 4;
			case 8:
				return 8;
			case 16:
				return 16;
			case 32:
				return 32;
			case 64:
				return 64;
			case 128:
				return 128;
			case 256:
			case 512:
			case 1024:
			case 2048:
			case 4096:
			case 8192:
			case 16384:
			case 32768:
			case 65536:
			case 131072:
				return e & -e;
			case 262144:
			case 524288:
			case 1048576:
			case 2097152:
				return 3932160 & e;
			case 4194304:
			case 8388608:
			case 16777216:
			case 33554432:
				return 62914560 & e;
			case 67108864:
				return 67108864;
			case 134217728:
				return 134217728;
			case 268435456:
				return 268435456;
			case 536870912:
				return 536870912;
			case 1073741824:
				return 0;
			default:
				return e
		}
	}

	function Ie(e, t, n) {
		var r = e.pendingLanes;
		if (0 === r) return 0;
		var i = 0,
			a = e.suspendedLanes,
			o = e.pingedLanes;
		e = e.warmLanes;
		var s = 134217727 & r;
		return 0 !== s ? 0 !== (r = s & ~a) ? i = Fe(r) : 0 !== (o &= s) ? i = Fe(o) : n || 0 !== (n = s & ~e) && (i = Fe(n)) : 0 !== (s = r & ~a) ? i = Fe(s) : 0 !== o ? i = Fe(o) : n || 0 !== (n = r & ~e) && (i = Fe(n)), 0 === i ? 0 : 0 !== t && t !== i && 0 === (t & a) && ((a = i & -i) >= (n = t & -t) || 32 === a && 4194048 & n) ? t : i
	}

	function Ve(e, t) {
		return 0 === (e.pendingLanes & ~(e.suspendedLanes & ~e.pingedLanes) & t)
	}

	function Be(e, t) {
		8 & t && (t |= 32 & t);
		var n = e.entangledLanes;
		if (0 !== n)
			for (e = e.entanglements, n &= t; 0 < n;) {
				var r = 31 - Le(n),
					i = 1 << r;
				t |= e[r], n &= ~i
			}
		return t
	}

	function Ue(e, t) {
		switch (e) {
			case 1:
			case 2:
			case 4:
			case 8:
			case 64:
				return t + 250;
			case 16:
			case 32:
			case 128:
			case 256:
			case 512:
			case 1024:
			case 2048:
			case 4096:
			case 8192:
			case 16384:
			case 32768:
			case 65536:
			case 131072:
			case 262144:
			case 524288:
			case 1048576:
			case 2097152:
				return t + 5e3;
			default:
				return -1
		}
	}

	function He() {
		var e = Re;
		return !(62914560 & (Re <<= 1)) && (Re = 4194304), e
	}

	function $e(e) {
		for (var t = [], n = 0; 31 > n; n++) t.push(e);
		return t
	}

	function We(e, t) {
		e.pendingLanes |= t, 268435456 !== t && (e.suspendedLanes = 0, e.pingedLanes = 0, e.warmLanes = 0)
	}

	function Ze(e, t, n) {
		e.pendingLanes |= t, e.suspendedLanes &= ~t;
		var r = 31 - Le(t);
		e.entangledLanes |= t, e.entanglements[r] = 1073741824 | e.entanglements[r] | 261930 & n
	}

	function Ye(e, t) {
		var n = e.entangledLanes |= t;
		for (e = e.entanglements; n;) {
			var r = 31 - Le(n),
				i = 1 << r;
			i & t | e[r] & t && (e[r] |= t), n &= ~i
		}
	}

	function qe(e, t) {
		var n = t & -t;
		return 0 !== ((n = 42 & n ? 1 : Ke(n)) & (e.suspendedLanes | t)) ? 0 : n
	}

	function Ke(e) {
		switch (e) {
			case 2:
				e = 1;
				break;
			case 8:
				e = 4;
				break;
			case 32:
				e = 16;
				break;
			case 256:
			case 512:
			case 1024:
			case 2048:
			case 4096:
			case 8192:
			case 16384:
			case 32768:
			case 65536:
			case 131072:
			case 262144:
			case 524288:
			case 1048576:
			case 2097152:
			case 4194304:
			case 8388608:
			case 16777216:
			case 33554432:
				e = 128;
				break;
			case 268435456:
				e = 134217728;
				break;
			default:
				e = 0
		}
		return e
	}

	function Qe(e) {
		return 2 < (e &= -e) ? 8 < e ? 134217727 & e ? 32 : 268435456 : 8 : 2
	}

	function Xe() {
		var e = Y.p;
		return 0 !== e ? e : void 0 === (e = window.event) ? 32 : Tp(e.type)
	}

	function Ge(e, t) {
		var n = Y.p;
		try {
			return Y.p = e, t()
		} finally {
			Y.p = n
		}
	}
	var Je = Math.random().toString(36).slice(2),
		et = "__reactFiber$" + Je,
		tt = "__reactProps$" + Je,
		nt = "__reactContainer$" + Je,
		rt = "__reactEvents$" + Je,
		it = "__reactListeners$" + Je,
		at = "__reactHandles$" + Je,
		ot = "__reactResources$" + Je,
		st = "__reactMarker$" + Je,
		lt = "__reactLoad$" + Je;

	function ut(e) {
		delete e[et], delete e[tt], delete e[it], delete e[at]
	}

	function ct(e) {
		var t;
		if (t = e[et]) return t;
		for (var n = e.parentNode; n;) {
			if (t = n[nt] || n[et]) {
				if (n = t.alternate, null !== t.child || null !== n && null !== n.child)
					for (e = Mh(e); null !== e;) {
						if (n = e[et]) return n;
						e = Mh(e)
					}
				return t
			}
			n = (e = n).parentNode
		}
		return null
	}

	function dt(e) {
		if (e = e[et] || e[nt]) {
			var t = e.tag;
			if (5 === t || 6 === t || 13 === t || 31 === t || 26 === t || 27 === t || 3 === t) return e
		}
		return null
	}

	function ft(e) {
		var t = e.tag;
		if (5 === t || 26 === t || 27 === t || 6 === t) return e.stateNode;
		throw Error(r(33))
	}

	function ht(e) {
		var t = e[ot];
		return t || (t = e[ot] = {
			hoistableStyles: new Map,
			hoistableScripts: new Map
		}), t
	}

	function pt(e) {
		e[st] = !0
	}

	function mt(e) {
		e[lt] = void 0
	}
	var gt = new Set,
		vt = {};

	function yt(e, t) {
		bt(e, t), bt(e + "Capture", t)
	}

	function bt(e, t) {
		for (vt[e] = t, e = 0; e < t.length; e++) gt.add(t[e])
	}
	var xt = RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"),
		wt = {},
		St = {};
	var Et = !1;

	function kt() {
		var e = Et;
		return Et = !1, e
	}

	function Tt(e, t, n) {
		if (function (e) {
			return !!me.call(St, e) || !me.call(wt, e) && (xt.test(e) ? St[e] = !0 : (wt[e] = !0, !1))
		}(t))
			if (null === n) e.removeAttribute(t);
			else {
				switch (typeof n) {
					case "undefined":
					case "function":
					case "symbol":
						return void e.removeAttribute(t);
					case "boolean":
						var r = t.toLowerCase().slice(0, 5);
						if ("data-" !== r && "aria-" !== r) return void e.removeAttribute(t)
				}
				e.setAttribute(t, n)
			}
	}

	function Pt(e, t, n) {
		if (null === n) e.removeAttribute(t);
		else {
			switch (typeof n) {
				case "undefined":
				case "function":
				case "symbol":
				case "boolean":
					return void e.removeAttribute(t)
			}
			e.setAttribute(t, n)
		}
	}

	function Ct(e, t, n, r) {
		if (null === r) e.removeAttribute(n);
		else {
			switch (typeof r) {
				case "undefined":
				case "function":
				case "symbol":
				case "boolean":
					return void e.removeAttribute(n)
			}
			e.setAttributeNS(t, n, r)
		}
	}

	function Nt(e) {
		switch (typeof e) {
			case "bigint":
			case "boolean":
			case "number":
			case "string":
			case "undefined":
			case "object":
				return e;
			default:
				return ""
		}
	}

	function Mt(e) {
		var t = e.type;
		return (e = e.nodeName) && "input" === e.toLowerCase() && ("checkbox" === t || "radio" === t)
	}

	function At(e) {
		if (!e._valueTracker) {
			var t = Mt(e) ? "checked" : "value";
			e._valueTracker = function (e, t, n) {
				var r = Object.getOwnPropertyDescriptor(e.constructor.prototype, t);
				if (!e.hasOwnProperty(t) && typeof r < "u" && "function" == typeof r.get && "function" == typeof r.set) {
					var i = r.get,
						a = r.set;
					return Object.defineProperty(e, t, {
						configurable: !0,
						get: function () {
							return i.call(this)
						},
						set: function (e) {
							n = "" + e, a.call(this, e)
						}
					}), Object.defineProperty(e, t, {
						enumerable: r.enumerable
					}), {
						getValue: function () {
							return n
						},
						setValue: function (e) {
							n = "" + e
						},
						stopTracking: function () {
							e._valueTracker = null, delete e[t]
						}
					}
				}
			}(e, t, "" + e[t])
		}
	}

	function _t(e) {
		if (!e) return !1;
		var t = e._valueTracker;
		if (!t) return !0;
		var n = t.getValue(),
			r = "";
		return e && (r = Mt(e) ? e.checked ? "true" : "false" : e.value), (e = r) !== n && (t.setValue(e), !0)
	}
	var Lt = /[\n"\\]/g;

	function Dt(e) {
		return e.replace(Lt, function (e) {
			return "\\" + e.charCodeAt(0).toString(16) + " "
		})
	}

	function jt(e, t, n, r, i, a, o, s) {
		e.name = "", null != o && "function" != typeof o && "symbol" != typeof o && "boolean" != typeof o ? e.type = o : e.removeAttribute("type"), null != t ? "number" === o ? (0 === t && "" === e.value || e.value != t) && (e.value = "" + Nt(t)) : e.value !== "" + Nt(t) && (e.value = "" + Nt(t)) : "submit" !== o && "reset" !== o || e.removeAttribute("value"), null != t ? "number" === o && e.value == t ? zt(e, Nt(e.value)) : zt(e, Nt(t)) : null != n ? zt(e, Nt(n)) : null != r && e.removeAttribute("value"), null == i && null != a && (e.defaultChecked = !!a), null != i && (e.checked = i && "function" != typeof i && "symbol" != typeof i), null != s && "function" != typeof s && "symbol" != typeof s && "boolean" != typeof s ? e.name = "" + Nt(s) : e.removeAttribute("name")
	}

	function Ot(e, t, n, r, i, a, o, s) {
		if (null != a && "function" != typeof a && "symbol" != typeof a && "boolean" != typeof a && (e.type = a), null != t || null != n) {
			if (("submit" === a || "reset" === a) && null == t) return void At(e);
			n = null != n ? "" + Nt(n) : "", t = null != t ? "" + Nt(t) : n, s || t === e.value || (e.value = t), e.defaultValue = t
		}
		r = "function" != typeof (r = r ?? i) && "symbol" != typeof r && !!r, e.checked = s ? e.checked : !!r, e.defaultChecked = !!r, null != o && "function" != typeof o && "symbol" != typeof o && "boolean" != typeof o && (e.name = o), At(e)
	}

	function zt(e, t) {
		e.defaultValue !== "" + t && (e.defaultValue = "" + t)
	}

	function Rt(e, t, n, r) {
		if (e = e.options, t) {
			t = {};
			for (var i = 0; i < n.length; i++) t["$" + n[i]] = !0;
			for (n = 0; n < e.length; n++) i = t.hasOwnProperty("$" + e[n].value), e[n].selected !== i && (e[n].selected = i), i && r && (e[n].defaultSelected = !0)
		} else {
			for (n = "" + Nt(n), t = null, i = 0; i < e.length; i++) {
				if (e[i].value === n) return e[i].selected = !0, void (r && (e[i].defaultSelected = !0));
				null !== t || e[i].disabled || (t = e[i])
			}
			null !== t && (t.selected = !0)
		}
	}

	function Ft(e, t, n) {
		null == t || ((t = "" + Nt(t)) !== e.value && (e.value = t), null != n) ? e.defaultValue = null != n ? "" + Nt(n) : "" : e.defaultValue !== t && (e.defaultValue = t)
	}

	function It(e, t, n, i) {
		if (null == t) {
			if (null != i) {
				if (null != n) throw Error(r(92));
				if (W(i)) {
					if (1 < i.length) throw Error(r(93));
					i = i[0]
				}
				n = i
			}
			null == n && (n = ""), t = n
		}
		n = Nt(t), e.defaultValue = n, (i = e.textContent) === n && "" !== i && null !== i && (e.value = i), At(e)
	}

	function Vt(e, t) {
		if (t) {
			var n = e.firstChild;
			if (n && n === e.lastChild && 3 === n.nodeType) return void (n.nodeValue = t)
		}
		e.textContent = t
	}
	var Bt = new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" "));

	function Ut(e, t, n) {
		var r = 0 === t.indexOf("--");
		null == n || "boolean" == typeof n || "" === n ? r ? e.setProperty(t, "") : "float" === t ? e.cssFloat = "" : e[t] = "" : r ? e.setProperty(t, n) : "number" != typeof n || 0 === n || Bt.has(t) ? "float" === t ? e.cssFloat = n : e[t] = ("" + n).trim() : e[t] = n + "px"
	}

	function Ht(e, t, n) {
		if (null != t && "object" != typeof t) throw Error(r(62));
		if (e = e.style, null != n) {
			for (var i in n) !n.hasOwnProperty(i) || null != t && t.hasOwnProperty(i) || (0 === i.indexOf("--") ? e.setProperty(i, "") : "float" === i ? e.cssFloat = "" : e[i] = "", Et = !0);
			for (var a in t) i = t[a], t.hasOwnProperty(a) && n[a] !== i && (Ut(e, a, i), Et = !0)
		} else
			for (var o in t) t.hasOwnProperty(o) && Ut(e, o, t[o])
	}

	function $t(e) {
		if (-1 === e.indexOf("-")) return !1;
		switch (e) {
			case "annotation-xml":
			case "color-profile":
			case "font-face":
			case "font-face-src":
			case "font-face-uri":
			case "font-face-format":
			case "font-face-name":
			case "missing-glyph":
				return !1;
			default:
				return !0
		}
	}
	var Wt = new Map([
		["acceptCharset", "accept-charset"],
		["htmlFor", "for"],
		["httpEquiv", "http-equiv"],
		["crossOrigin", "crossorigin"],
		["accentHeight", "accent-height"],
		["alignmentBaseline", "alignment-baseline"],
		["arabicForm", "arabic-form"],
		["baselineShift", "baseline-shift"],
		["capHeight", "cap-height"],
		["clipPath", "clip-path"],
		["clipRule", "clip-rule"],
		["colorInterpolation", "color-interpolation"],
		["colorInterpolationFilters", "color-interpolation-filters"],
		["colorProfile", "color-profile"],
		["colorRendering", "color-rendering"],
		["dominantBaseline", "dominant-baseline"],
		["enableBackground", "enable-background"],
		["fillOpacity", "fill-opacity"],
		["fillRule", "fill-rule"],
		["floodColor", "flood-color"],
		["floodOpacity", "flood-opacity"],
		["fontFamily", "font-family"],
		["fontSize", "font-size"],
		["fontSizeAdjust", "font-size-adjust"],
		["fontStretch", "font-stretch"],
		["fontStyle", "font-style"],
		["fontVariant", "font-variant"],
		["fontWeight", "font-weight"],
		["glyphName", "glyph-name"],
		["glyphOrientationHorizontal", "glyph-orientation-horizontal"],
		["glyphOrientationVertical", "glyph-orientation-vertical"],
		["horizAdvX", "horiz-adv-x"],
		["horizOriginX", "horiz-origin-x"],
		["imageRendering", "image-rendering"],
		["letterSpacing", "letter-spacing"],
		["lightingColor", "lighting-color"],
		["markerEnd", "marker-end"],
		["markerMid", "marker-mid"],
		["markerStart", "marker-start"],
		["maskType", "mask-type"],
		["overlinePosition", "overline-position"],
		["overlineThickness", "overline-thickness"],
		["paintOrder", "paint-order"],
		["panose-1", "panose-1"],
		["pointerEvents", "pointer-events"],
		["renderingIntent", "rendering-intent"],
		["shapeRendering", "shape-rendering"],
		["stopColor", "stop-color"],
		["stopOpacity", "stop-opacity"],
		["strikethroughPosition", "strikethrough-position"],
		["strikethroughThickness", "strikethrough-thickness"],
		["strokeDasharray", "stroke-dasharray"],
		["strokeDashoffset", "stroke-dashoffset"],
		["strokeLinecap", "stroke-linecap"],
		["strokeLinejoin", "stroke-linejoin"],
		["strokeMiterlimit", "stroke-miterlimit"],
		["strokeOpacity", "stroke-opacity"],
		["strokeWidth", "stroke-width"],
		["textAnchor", "text-anchor"],
		["textDecoration", "text-decoration"],
		["textRendering", "text-rendering"],
		["transformOrigin", "transform-origin"],
		["underlinePosition", "underline-position"],
		["underlineThickness", "underline-thickness"],
		["unicodeBidi", "unicode-bidi"],
		["unicodeRange", "unicode-range"],
		["unitsPerEm", "units-per-em"],
		["vAlphabetic", "v-alphabetic"],
		["vHanging", "v-hanging"],
		["vIdeographic", "v-ideographic"],
		["vMathematical", "v-mathematical"],
		["vectorEffect", "vector-effect"],
		["vertAdvY", "vert-adv-y"],
		["vertOriginX", "vert-origin-x"],
		["vertOriginY", "vert-origin-y"],
		["wordSpacing", "word-spacing"],
		["writingMode", "writing-mode"],
		["xmlnsXlink", "xmlns:xlink"],
		["xHeight", "x-height"]
	]),
		Zt = /^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;

	function Yt(e) {
		return Zt.test("" + e) ? "javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')" : e
	}

	function qt() { }
	var Kt = null;

	function Qt(e) {
		return (e = e.target || e.srcElement || window).correspondingUseElement && (e = e.correspondingUseElement), 3 === e.nodeType ? e.parentNode : e
	}
	var Xt = null,
		Gt = null;

	function Jt(e) {
		var t = dt(e);
		if (t && (e = t.stateNode)) {
			var n = e[tt] || null;
			e: switch (e = t.stateNode, t.type) {
				case "input":
					if (jt(e, n.value, n.defaultValue, n.defaultValue, n.checked, n.defaultChecked, n.type, n.name), t = n.name, "radio" === n.type && null != t) {
						for (n = e; n.parentNode;) n = n.parentNode;
						for (n = n.querySelectorAll('input[name="' + Dt("" + t) + '"][type="radio"]'), t = 0; t < n.length; t++) {
							var i = n[t];
							if (i !== e && i.form === e.form) {
								var a = i[tt] || null;
								if (!a) throw Error(r(90));
								jt(i, a.value, a.defaultValue, a.defaultValue, a.checked, a.defaultChecked, a.type, a.name)
							}
						}
						for (t = 0; t < n.length; t++)(i = n[t]).form === e.form && _t(i)
					}
					break e;
				case "textarea":
					Ft(e, n.value, n.defaultValue);
					break e;
				case "select":
					null != (t = n.value) && Rt(e, !!n.multiple, t, !1)
			}
		}
	}
	var en = !1;

	function tn(e, t, n) {
		if (en) return e(t, n);
		en = !0;
		try {
			return e(t)
		} finally {
			if (en = !1, (null !== Xt || null !== Gt) && (pd(), Xt && (t = Xt, e = Gt, Gt = Xt = null, Jt(t), e)))
				for (t = 0; t < e.length; t++) Jt(e[t])
		}
	}

	function nn(e, t) {
		var n = e.stateNode;
		if (null === n) return null;
		var i = n[tt] || null;
		if (null === i) return null;
		n = i[t];
		e: switch (t) {
			case "onClick":
			case "onClickCapture":
			case "onDoubleClick":
			case "onDoubleClickCapture":
			case "onMouseDown":
			case "onMouseDownCapture":
			case "onMouseMove":
			case "onMouseMoveCapture":
			case "onMouseUp":
			case "onMouseUpCapture":
			case "onMouseEnter":
				(i = !i.disabled) || (i = !("button" === (e = e.type) || "input" === e || "select" === e || "textarea" === e)), e = !i;
				break e;
			default:
				e = !1
		}
		if (e) return null;
		if (n && "function" != typeof n) throw Error(r(231, t, typeof n));
		return n
	}
	var rn = !(typeof window > "u" || typeof window.document > "u" || typeof window.document.createElement > "u"),
		an = !1;
	if (rn) try {
		var on = {};
		Object.defineProperty(on, "passive", {
			get: function () {
				an = !0
			}
		}), window.addEventListener("test", on, on), window.removeEventListener("test", on, on)
	} catch {
		an = !1
	}
	var sn = null,
		ln = null,
		un = null;

	function cn() {
		if (un) return un;
		var e, t, n = ln,
			r = n.length,
			i = "value" in sn ? sn.value : sn.textContent,
			a = i.length;
		for (e = 0; e < r && n[e] === i[e]; e++);
		var o = r - e;
		for (t = 1; t <= o && n[r - t] === i[a - t]; t++);
		return un = i.slice(e, 1 < t ? 1 - t : void 0)
	}

	function dn(e) {
		var t = e.keyCode;
		return "charCode" in e ? 0 === (e = e.charCode) && 13 === t && (e = 13) : e = t, 10 === e && (e = 13), 32 <= e || 13 === e ? e : 0
	}

	function fn() {
		return !0
	}

	function hn() {
		return !1
	}

	function pn(e) {
		function t(t, n, r, i, a) {
			for (var o in this._reactName = t, this._targetInst = r, this.type = n, this.nativeEvent = i, this.target = a, this.currentTarget = null, e) e.hasOwnProperty(o) && (t = e[o], this[o] = t ? t(i) : i[o]);
			return this.isDefaultPrevented = (null != i.defaultPrevented ? i.defaultPrevented : !1 === i.returnValue) ? fn : hn, this.isPropagationStopped = hn, this
		}
		return S(t.prototype, {
			preventDefault: function () {
				this.defaultPrevented = !0;
				var e = this.nativeEvent;
				e && (e.preventDefault ? e.preventDefault() : "unknown" != typeof e.returnValue && (e.returnValue = !1), this.isDefaultPrevented = fn)
			},
			stopPropagation: function () {
				var e = this.nativeEvent;
				e && (e.stopPropagation ? e.stopPropagation() : "unknown" != typeof e.cancelBubble && (e.cancelBubble = !0), this.isPropagationStopped = fn)
			},
			persist: function () { },
			isPersistent: fn
		}), t
	}
	var mn, gn, vn, yn = {
		eventPhase: 0,
		bubbles: 0,
		cancelable: 0,
		timeStamp: function (e) {
			return e.timeStamp || Date.now()
		},
		defaultPrevented: 0,
		isTrusted: 0
	},
		bn = pn(yn),
		xn = S({}, yn, {
			view: 0,
			detail: 0
		}),
		wn = pn(xn),
		Sn = S({}, xn, {
			screenX: 0,
			screenY: 0,
			clientX: 0,
			clientY: 0,
			pageX: 0,
			pageY: 0,
			ctrlKey: 0,
			shiftKey: 0,
			altKey: 0,
			metaKey: 0,
			getModifierState: Dn,
			button: 0,
			buttons: 0,
			relatedTarget: function (e) {
				return void 0 === e.relatedTarget ? e.fromElement === e.srcElement ? e.toElement : e.fromElement : e.relatedTarget
			},
			movementX: function (e) {
				return "movementX" in e ? e.movementX : (e !== vn && (vn && "mousemove" === e.type ? (mn = e.screenX - vn.screenX, gn = e.screenY - vn.screenY) : gn = mn = 0, vn = e), mn)
			},
			movementY: function (e) {
				return "movementY" in e ? e.movementY : gn
			}
		}),
		En = pn(Sn),
		kn = pn(S({}, Sn, {
			dataTransfer: 0
		})),
		Tn = pn(S({}, xn, {
			relatedTarget: 0
		})),
		Pn = pn(S({}, yn, {
			animationName: 0,
			elapsedTime: 0,
			pseudoElement: 0
		})),
		Cn = pn(S({}, yn, {
			clipboardData: function (e) {
				return "clipboardData" in e ? e.clipboardData : window.clipboardData
			}
		})),
		Nn = pn(S({}, yn, {
			data: 0
		})),
		Mn = {
			Esc: "Escape",
			Spacebar: " ",
			Left: "ArrowLeft",
			Up: "ArrowUp",
			Right: "ArrowRight",
			Down: "ArrowDown",
			Del: "Delete",
			Win: "OS",
			Menu: "ContextMenu",
			Apps: "ContextMenu",
			Scroll: "ScrollLock",
			MozPrintableKey: "Unidentified"
		},
		An = {
			8: "Backspace",
			9: "Tab",
			12: "Clear",
			13: "Enter",
			16: "Shift",
			17: "Control",
			18: "Alt",
			19: "Pause",
			20: "CapsLock",
			27: "Escape",
			32: " ",
			33: "PageUp",
			34: "PageDown",
			35: "End",
			36: "Home",
			37: "ArrowLeft",
			38: "ArrowUp",
			39: "ArrowRight",
			40: "ArrowDown",
			45: "Insert",
			46: "Delete",
			112: "F1",
			113: "F2",
			114: "F3",
			115: "F4",
			116: "F5",
			117: "F6",
			118: "F7",
			119: "F8",
			120: "F9",
			121: "F10",
			122: "F11",
			123: "F12",
			144: "NumLock",
			145: "ScrollLock",
			224: "Meta"
		},
		_n = {
			Alt: "altKey",
			Control: "ctrlKey",
			Meta: "metaKey",
			Shift: "shiftKey"
		};

	function Ln(e) {
		var t = this.nativeEvent;
		return t.getModifierState ? t.getModifierState(e) : !!(e = _n[e]) && !!t[e]
	}

	function Dn() {
		return Ln
	}
	var jn = pn(S({}, xn, {
		key: function (e) {
			if (e.key) {
				var t = Mn[e.key] || e.key;
				if ("Unidentified" !== t) return t
			}
			return "keypress" === e.type ? 13 === (e = dn(e)) ? "Enter" : String.fromCharCode(e) : "keydown" === e.type || "keyup" === e.type ? An[e.keyCode] || "Unidentified" : ""
		},
		code: 0,
		location: 0,
		ctrlKey: 0,
		shiftKey: 0,
		altKey: 0,
		metaKey: 0,
		repeat: 0,
		locale: 0,
		getModifierState: Dn,
		charCode: function (e) {
			return "keypress" === e.type ? dn(e) : 0
		},
		keyCode: function (e) {
			return "keydown" === e.type || "keyup" === e.type ? e.keyCode : 0
		},
		which: function (e) {
			return "keypress" === e.type ? dn(e) : "keydown" === e.type || "keyup" === e.type ? e.keyCode : 0
		}
	})),
		On = pn(S({}, Sn, {
			pointerId: 0,
			width: 0,
			height: 0,
			pressure: 0,
			tangentialPressure: 0,
			tiltX: 0,
			tiltY: 0,
			twist: 0,
			pointerType: 0,
			isPrimary: 0
		})),
		zn = pn(S({}, yn, {
			submitter: 0
		})),
		Rn = pn(S({}, xn, {
			touches: 0,
			targetTouches: 0,
			changedTouches: 0,
			altKey: 0,
			metaKey: 0,
			ctrlKey: 0,
			shiftKey: 0,
			getModifierState: Dn
		})),
		Fn = pn(S({}, yn, {
			propertyName: 0,
			elapsedTime: 0,
			pseudoElement: 0
		})),
		In = pn(S({}, Sn, {
			deltaX: function (e) {
				return "deltaX" in e ? e.deltaX : "wheelDeltaX" in e ? -e.wheelDeltaX : 0
			},
			deltaY: function (e) {
				return "deltaY" in e ? e.deltaY : "wheelDeltaY" in e ? -e.wheelDeltaY : "wheelDelta" in e ? -e.wheelDelta : 0
			},
			deltaZ: 0,
			deltaMode: 0
		})),
		Vn = pn(S({}, yn, {
			newState: 0,
			oldState: 0,
			source: 0
		})),
		Bn = [9, 13, 27, 32],
		Un = rn && "CompositionEvent" in window,
		Hn = null;
	rn && "documentMode" in document && (Hn = document.documentMode);
	var $n = rn && "TextEvent" in window && !Hn,
		Wn = rn && (!Un || Hn && 8 < Hn && 11 >= Hn),
		Zn = " ",
		Yn = !1;

	function qn(e, t) {
		switch (e) {
			case "keyup":
				return -1 !== Bn.indexOf(t.keyCode);
			case "keydown":
				return 229 !== t.keyCode;
			case "keypress":
			case "mousedown":
			case "focusout":
				return !0;
			default:
				return !1
		}
	}

	function Kn(e) {
		return "object" == typeof (e = e.detail) && "data" in e ? e.data : null
	}
	var Qn = !1;
	var Xn = {
		color: !0,
		date: !0,
		datetime: !0,
		"datetime-local": !0,
		email: !0,
		month: !0,
		number: !0,
		password: !0,
		range: !0,
		search: !0,
		tel: !0,
		text: !0,
		time: !0,
		url: !0,
		week: !0
	};

	function Gn(e) {
		var t = e && e.nodeName && e.nodeName.toLowerCase();
		return "input" === t ? !!Xn[e.type] : "textarea" === t
	}

	function Jn(e, t, n, r) {
		Xt ? Gt ? Gt.push(r) : Gt = [r] : Xt = r, 0 < (t = wf(t, "onChange")).length && (n = new bn("onChange", "change", null, n, r), e.push({
			event: n,
			listeners: t
		}))
	}
	var er = null,
		tr = null;

	function nr(e) {
		hf(e, 0)
	}

	function rr(e) {
		if (_t(ft(e))) return e
	}

	function ir(e, t) {
		if ("change" === e) return t
	}
	var ar = !1;
	if (rn) {
		var or;
		if (rn) {
			var sr = "oninput" in document;
			if (!sr) {
				var lr = document.createElement("div");
				lr.setAttribute("oninput", "return;"), sr = "function" == typeof lr.oninput
			}
			or = sr
		} else or = !1;
		ar = or && (!document.documentMode || 9 < document.documentMode)
	}

	function ur() {
		er && (er.detachEvent("onpropertychange", cr), tr = er = null)
	}

	function cr(e) {
		if ("value" === e.propertyName && rr(tr)) {
			var t = [];
			Jn(t, tr, e, Qt(e)), tn(nr, t)
		}
	}

	function dr(e, t, n) {
		"focusin" === e ? (ur(), tr = n, (er = t).attachEvent("onpropertychange", cr)) : "focusout" === e && ur()
	}

	function fr(e) {
		if ("selectionchange" === e || "keyup" === e || "keydown" === e) return rr(tr)
	}

	function hr(e, t) {
		if ("click" === e) return rr(t)
	}

	function pr(e, t) {
		if ("input" === e || "change" === e) return rr(t)
	}
	var mr = "function" == typeof Object.is ? Object.is : function (e, t) {
		return e === t && (0 !== e || 1 / e == 1 / t) || e != e && t != t
	};

	function gr(e, t) {
		if (mr(e, t)) return !0;
		if ("object" != typeof e || null === e || "object" != typeof t || null === t) return !1;
		var n = Object.keys(e),
			r = Object.keys(t);
		if (n.length !== r.length) return !1;
		for (r = 0; r < n.length; r++) {
			var i = n[r];
			if (!me.call(t, i) || !mr(e[i], t[i])) return !1
		}
		return !0
	}

	function vr(e) {
		if (typeof (e = e || (typeof document < "u" ? document : void 0)) > "u") return null;
		try {
			return e.activeElement || e.body
		} catch {
			return e.body
		}
	}

	function yr(e) {
		for (; e && e.firstChild;) e = e.firstChild;
		return e
	}

	function br(e, t) {
		var n, r = yr(e);
		for (e = 0; r;) {
			if (3 === r.nodeType) {
				if (n = e + r.textContent.length, e <= t && n >= t) return {
					node: r,
					offset: t - e
				};
				e = n
			}
			e: {
				for (; r;) {
					if (r.nextSibling) {
						r = r.nextSibling;
						break e
					}
					r = r.parentNode
				}
				r = void 0
			}
			r = yr(r)
		}
	}

	function xr(e, t) {
		return !(!e || !t) && (e === t || (!e || 3 !== e.nodeType) && (t && 3 === t.nodeType ? xr(e, t.parentNode) : "contains" in e ? e.contains(t) : !!e.compareDocumentPosition && !!(16 & e.compareDocumentPosition(t))))
	}

	function wr(e) {
		for (var t = vr((e = null != e && null != e.ownerDocument && null != e.ownerDocument.defaultView ? e.ownerDocument.defaultView : window).document); t instanceof e.HTMLIFrameElement;) {
			try {
				var n = "string" == typeof t.contentWindow.location.href
			} catch {
				n = !1
			}
			if (!n) break;
			t = vr((e = t.contentWindow).document)
		}
		return t
	}

	function Sr(e) {
		var t = e && e.nodeName && e.nodeName.toLowerCase();
		return t && ("input" === t && ("text" === e.type || "search" === e.type || "tel" === e.type || "url" === e.type || "password" === e.type) || "textarea" === t || "true" === e.contentEditable)
	}
	var Er = rn && "documentMode" in document && 11 >= document.documentMode,
		kr = null,
		Tr = null,
		Pr = null,
		Cr = !1;

	function Nr(e, t, n) {
		var r = n.window === n ? n.document : 9 === n.nodeType ? n : n.ownerDocument;
		Cr || null == kr || kr !== vr(r) || ("selectionStart" in (r = kr) && Sr(r) ? r = {
			start: r.selectionStart,
			end: r.selectionEnd
		} : r = {
			anchorNode: (r = (r.ownerDocument && r.ownerDocument.defaultView || window).getSelection()).anchorNode,
			anchorOffset: r.anchorOffset,
			focusNode: r.focusNode,
			focusOffset: r.focusOffset
		}, Pr && gr(Pr, r) || (Pr = r, 0 < (r = wf(Tr, "onSelect")).length && (t = new bn("onSelect", "select", null, t, n), e.push({
			event: t,
			listeners: r
		}), t.target = kr)))
	}

	function Mr(e, t) {
		var n = {};
		return n[e.toLowerCase()] = t.toLowerCase(), n["Webkit" + e] = "webkit" + t, n["Moz" + e] = "moz" + t, n
	}
	var Ar = {
		animationend: Mr("Animation", "AnimationEnd"),
		animationiteration: Mr("Animation", "AnimationIteration"),
		animationstart: Mr("Animation", "AnimationStart"),
		transitionrun: Mr("Transition", "TransitionRun"),
		transitionstart: Mr("Transition", "TransitionStart"),
		transitioncancel: Mr("Transition", "TransitionCancel"),
		transitionend: Mr("Transition", "TransitionEnd")
	},
		_r = {},
		Lr = {};

	function Dr(e) {
		if (_r[e]) return _r[e];
		if (!Ar[e]) return e;
		var t, n = Ar[e];
		for (t in n)
			if (n.hasOwnProperty(t) && t in Lr) return _r[e] = n[t];
		return e
	}
	rn && (Lr = document.createElement("div").style, "AnimationEvent" in window || (delete Ar.animationend.animation, delete Ar.animationiteration.animation, delete Ar.animationstart.animation), "TransitionEvent" in window || delete Ar.transitionend.transition);
	var jr = Dr("animationend"),
		Or = Dr("animationiteration"),
		zr = Dr("animationstart"),
		Rr = Dr("transitionrun"),
		Fr = Dr("transitionstart"),
		Ir = Dr("transitioncancel"),
		Vr = Dr("transitionend"),
		Br = new Map,
		Ur = "abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error fullscreenChange fullscreenError gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");

	function Hr(e, t) {
		Br.set(e, t), yt(t, [e])
	}
	Ur.push("scrollEnd");
	var $r = 0;

	function Wr(e, t) {
		return null != e.name && "auto" !== e.name ? e.name : null !== t.autoName ? t.autoName : (e = "_" + (e = Kc.identifierPrefix) + "t_" + ($r++).toString(32) + "_", t.autoName = e)
	}

	function Zr(e) {
		if (null == e || "string" == typeof e) return e;
		var t = null,
			n = rd;
		if (null !== n)
			for (var r = 0; r < n.length; r++) {
				var i = e[n[r]];
				if (null != i) {
					if ("none" === i) return "none";
					t = null == t ? i : t + " " + i
				}
			}
		return t ?? e.default
	}

	function Yr(e, t) {
		return e = Zr(e), null == (t = Zr(t)) ? "auto" === e ? null : e : "auto" === t ? null : t
	}
	var qr = "function" == typeof reportError ? reportError : function (e) {
		if ("object" == typeof window && "function" == typeof window.ErrorEvent) {
			var t = new window.ErrorEvent("error", {
				bubbles: !0,
				cancelable: !0,
				message: "object" == typeof e && null !== e && "string" == typeof e.message ? String(e.message) : String(e),
				error: e
			});
			if (!window.dispatchEvent(t)) return
		} else if ("object" == typeof process && "function" == typeof process.emit) return void process.emit("uncaughtException", e);
		console.error(e)
	},
		Kr = [],
		Qr = 0,
		Xr = 0;

	function Gr() {
		for (var e = Qr, t = Xr = Qr = 0; t < e;) {
			var n = Kr[t];
			Kr[t++] = null;
			var r = Kr[t];
			Kr[t++] = null;
			var i = Kr[t];
			Kr[t++] = null;
			var a = Kr[t];
			if (Kr[t++] = null, null !== r && null !== i) {
				var o = r.pending;
				null === o ? i.next = i : (i.next = o.next, o.next = i), r.pending = i
			}
			0 !== a && ni(n, i, a)
		}
	}

	function Jr(e, t, n, r) {
		Kr[Qr++] = e, Kr[Qr++] = t, Kr[Qr++] = n, Kr[Qr++] = r, Xr |= r, e.lanes |= r, null !== (e = e.alternate) && (e.lanes |= r)
	}

	function ei(e, t, n, r) {
		return Jr(e, t, n, r), ri(e)
	}

	function ti(e, t) {
		return Jr(e, null, null, t), ri(e)
	}

	function ni(e, t, n) {
		e.lanes |= n;
		var r = e.alternate;
		null !== r && (r.lanes |= n);
		for (var i = !1, a = e.return; null !== a;) a.childLanes |= n, null !== (r = a.alternate) && (r.childLanes |= n), 22 === a.tag && (null === (e = a.stateNode) || 1 & e._visibility || (i = !0)), e = a, a = a.return;
		return 3 === e.tag ? (a = e.stateNode, i && null !== t && (i = 31 - Le(n), null === (r = (e = a.hiddenUpdates)[i]) ? e[i] = [t] : r.push(t), t.lane = 536870912 | n), a) : null
	}

	function ri(e) {
		if (50 < id) throw id = 0, ad = null, Error(r(185));
		for (var t = e.return; null !== t;) t = (e = t).return;
		return 3 === e.tag ? e.stateNode : null
	}
	var ii = {};

	function ai(e, t, n, r) {
		this.tag = e, this.key = n, this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null, this.index = 0, this.refCleanup = this.ref = null, this.pendingProps = t, this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null, this.mode = r, this.subtreeFlags = this.flags = 0, this.deletions = null, this.childLanes = this.lanes = 0, this.alternate = null
	}

	function oi(e, t, n, r) {
		return new ai(e, t, n, r)
	}

	function si(e) {
		return !(!(e = e.prototype) || !e.isReactComponent)
	}

	function li(e, t) {
		var n = e.alternate;
		return null === n ? ((n = oi(e.tag, t, e.key, e.mode)).elementType = e.elementType, n.type = e.type, n.stateNode = e.stateNode, n.alternate = e, e.alternate = n) : (n.pendingProps = t, n.type = e.type, n.flags = 0, n.subtreeFlags = 0, n.deletions = null), n.flags = 1206910976 & e.flags, n.childLanes = e.childLanes, n.lanes = e.lanes, n.child = e.child, n.memoizedProps = e.memoizedProps, n.memoizedState = e.memoizedState, n.updateQueue = e.updateQueue, t = e.dependencies, n.dependencies = null === t ? null : {
			lanes: t.lanes,
			firstContext: t.firstContext
		}, n.sibling = e.sibling, n.index = e.index, n.ref = e.ref, n.refCleanup = e.refCleanup, n
	}

	function ui(e, t) {
		e.flags &= 1206910978;
		var n = e.alternate;
		return null === n ? (e.childLanes = 0, e.lanes = t, e.child = null, e.subtreeFlags = 0, e.memoizedProps = null, e.memoizedState = null, e.updateQueue = null, e.dependencies = null, e.stateNode = null) : (e.childLanes = n.childLanes, e.lanes = n.lanes, e.child = n.child, e.subtreeFlags = 0, e.deletions = null, e.memoizedProps = n.memoizedProps, e.memoizedState = n.memoizedState, e.updateQueue = n.updateQueue, e.type = n.type, t = n.dependencies, e.dependencies = null === t ? null : {
			lanes: t.lanes,
			firstContext: t.firstContext
		}), e
	}

	function ci(e, t, n, i, a, o) {
		var s = 0;
		if ("function" == typeof (i = e)) si(i) && (s = 1);
		else if ("string" == typeof i) s = function (e, t, n) {
			if (1 === n || null != t.itemProp) return !1;
			switch (e) {
				case "meta":
				case "title":
					return !0;
				case "style":
					if ("string" != typeof t.precedence || "string" != typeof t.href || "" === t.href) break;
					return !0;
				case "link":
					if ("string" != typeof t.rel || "string" != typeof t.href || "" === t.href || t.onLoad || t.onError) break;
					return "stylesheet" !== t.rel || (e = t.disabled, "string" == typeof t.precedence && null == e);
				case "script":
					if (t.async && "function" != typeof t.async && "symbol" != typeof t.async && !t.onLoad && !t.onError && t.src && "string" == typeof t.src) return !0
			}
			return !1
		}(e, n, ne.current) ? 26 : "html" === e || "head" === e || "body" === e ? 27 : 5;
		else e: switch (i) {
			case z:
				return (e = oi(31, n, t, a)).elementType = z, e.lanes = o, e;
			case P:
				return di(n.children, a, o, t);
			case C:
				s = 8, a |= 24;
				break;
			case N:
				return (e = oi(12, n, t, 2 | a)).elementType = N, e.lanes = o, e;
			case L:
				return (e = oi(13, n, t, a)).elementType = L, e.lanes = o, e;
			case D:
				return (e = oi(19, n, t, a)).elementType = D, e.lanes = o, e;
			case R:
			case I:
				return (e = oi(30, n, t, e = 32 | a)).elementType = I, e.lanes = o, e.stateNode = {
					autoName: null,
					paired: null,
					clones: null,
					ref: null
				}, e;
			default:
				if ("object" == typeof i && null !== i) switch (i.$$typeof) {
					case A:
						s = 10;
						break e;
					case M:
						s = 9;
						break e;
					case _:
						s = 11;
						break e;
					case j:
						s = 14;
						break e;
					case O:
						s = 16, i = null;
						break e
				}
				s = 29, n = Error(r(130, null === e ? "null" : typeof e, "")), i = null
		}
		return (t = oi(s, n, t, a)).elementType = e, t.type = i, t.lanes = o, t
	}

	function di(e, t, n, r) {
		return (e = oi(7, e, r, t)).lanes = n, e
	}

	function fi(e, t, n) {
		return (e = oi(6, e, null, t)).lanes = n, e
	}

	function hi(e) {
		var t = oi(18, null, null, 0);
		return t.stateNode = e, t
	}

	function pi(e, t, n) {
		return (t = oi(4, null !== e.children ? e.children : [], e.key, t)).lanes = n, t.stateNode = {
			containerInfo: e.containerInfo,
			pendingChildren: null,
			implementation: e.implementation
		}, t
	}
	var mi = new WeakMap;

	function gi(e, t) {
		if ("object" == typeof e && null !== e) {
			var n = mi.get(e);
			return void 0 !== n ? n : (t = {
				value: e,
				source: t,
				stack: pe(t)
			}, mi.set(e, t), t)
		}
		return {
			value: e,
			source: t,
			stack: pe(t)
		}
	}
	var vi = [],
		yi = 0,
		bi = null,
		xi = 0,
		wi = [],
		Si = 0,
		Ei = null,
		ki = 1,
		Ti = "";

	function Pi(e, t) {
		vi[yi++] = xi, vi[yi++] = bi, bi = e, xi = t
	}

	function Ci(e, t, n) {
		wi[Si++] = ki, wi[Si++] = Ti, wi[Si++] = Ei, Ei = e;
		var r = ki;
		e = Ti;
		var i = 32 - Le(r) - 1;
		r &= ~(1 << i), n += 1;
		var a = 32 - Le(t) + i;
		if (30 < a) {
			var o = i - i % 5;
			a = (r & (1 << o) - 1).toString(32), r >>= o, i -= o, ki = 1 << 32 - Le(t) + i | n << i | r, Ti = a + e
		} else ki = 1 << a | n << i | r, Ti = e
	}

	function Ni(e) {
		null !== e.return && (Pi(e, 1), Ci(e, 1, 0))
	}

	function Mi(e) {
		for (; e === bi;) bi = vi[--yi], vi[yi] = null, xi = vi[--yi], vi[yi] = null;
		for (; e === Ei;) Ei = wi[--Si], wi[Si] = null, Ti = wi[--Si], wi[Si] = null, ki = wi[--Si], wi[Si] = null
	}

	function Ai(e, t) {
		wi[Si++] = ki, wi[Si++] = Ti, wi[Si++] = Ei, ki = t.id, Ti = t.overflow, Ei = e
	}
	var _i = null,
		Li = null,
		Di = !1,
		ji = null,
		Oi = !1,
		zi = Error(r(519));

	function Ri(e) {
		throw Hi(gi(Error(r(418, 1 < arguments.length && void 0 !== arguments[1] && arguments[1] ? "text" : "HTML", "")), e)), zi
	}

	function Fi(e) {
		var t = e.stateNode,
			n = e.type,
			r = e.memoizedProps;
		switch (t[et] = e, t[tt] = r, n) {
			case "dialog":
				pf("cancel", t), pf("close", t);
				break;
			case "iframe":
			case "object":
			case "embed":
				pf("load", t);
				break;
			case "video":
			case "audio":
				for (n = 0; n < df.length; n++) pf(df[n], t);
				break;
			case "source":
				pf("error", t);
				break;
			case "img":
			case "image":
			case "link":
				pf("error", t), pf("load", t);
				break;
			case "details":
				pf("toggle", t);
				break;
			case "input":
				pf("invalid", t), Ot(t, r.value, r.defaultValue, r.checked, r.defaultChecked, r.type, r.name, !0);
				break;
			case "select":
				pf("invalid", t);
				break;
			case "textarea":
				pf("invalid", t), It(t, r.value, r.defaultValue, r.children)
		}
		"string" != typeof (n = r.children) && "number" != typeof n && "bigint" != typeof n || t.textContent === "" + n || !0 === r.suppressHydrationWarning || Cf(t.textContent, n) ? (null != r.popover && (pf("beforetoggle", t), pf("toggle", t)), null != r.onScroll && pf("scroll", t), null != r.onScrollEnd && pf("scrollend", t), null != r.onClick && (t.onclick = qt), t = !0) : t = !1, t || Ri(e, !0)
	}

	function Ii(e) {
		for (_i = e.return; _i;) switch (_i.tag) {
			case 5:
			case 31:
			case 13:
				return void (Oi = !1);
			case 27:
			case 3:
				return void (Oi = !0);
			default:
				_i = _i.return
		}
	}

	function Vi(e) {
		if (e !== _i) return !1;
		if (!Di) return Ii(e), Di = !0, !1;
		var t, n = e.tag;
		if ((t = 3 !== n && 27 !== n) && ((t = 5 === n) && (t = !("form" !== (t = e.type) && "button" !== t) || If(e.type, e.memoizedProps)), t = !t), t && Li && Ri(e), Ii(e), 13 === n) {
			if (!(e = null !== (e = e.memoizedState) ? e.dehydrated : null)) throw Error(r(317));
			Li = Nh(e)
		} else if (31 === n) {
			if (!(e = null !== (e = e.memoizedState) ? e.dehydrated : null)) throw Error(r(317));
			Li = Nh(e)
		} else 27 === n ? (n = Li, Yf(e.type) ? (e = Ch, Ch = null, Li = e) : Li = n) : Li = _i ? Ph(e.stateNode.nextSibling) : null;
		return !0
	}

	function Bi() {
		Li = _i = null, Di = !1
	}

	function Ui() {
		var e = ji;
		return null !== e && (null === Bc ? Bc = e : Bc.push.apply(Bc, e), ji = null), e
	}

	function Hi(e) {
		null === ji ? ji = [e] : ji.push(e)
	}
	var $i = X(null),
		Wi = null,
		Zi = null;

	function Yi(e, t, n) {
		J($i, t._currentValue), t._currentValue = n
	}

	function qi(e) {
		e._currentValue = $i.current, G($i)
	}

	function Ki(e, t, n) {
		for (; null !== e;) {
			var r = e.alternate;
			if ((e.childLanes & t) !== t ? (e.childLanes |= t, null !== r && (r.childLanes |= t)) : null !== r && (r.childLanes & t) !== t && (r.childLanes |= t), e === n) break;
			e = e.return
		}
	}

	function Qi(e, t, n, i) {
		var a = e.child;
		for (null !== a && (a.return = e); null !== a;) {
			var o = a.dependencies;
			if (null !== o) {
				var s = a.child;
				o = o.firstContext;
				e: for (; null !== o;) {
					var l = o;
					o = a;
					for (var u = 0; u < t.length; u++)
						if (l.context === t[u]) {
							o.lanes |= n, null !== (l = o.alternate) && (l.lanes |= n), Ki(o.return, n, e), i || (s = null);
							break e
						} o = l.next
				}
			} else if (18 === a.tag) {
				if (null === (s = a.return)) throw Error(r(341));
				s.lanes |= n, null !== (o = s.alternate) && (o.lanes |= n), Ki(s, n, e), s = null
			} else 13 === a.tag && null !== a.memoizedState && null === a.memoizedState.dehydrated ? (a.lanes |= n, null !== (s = a.alternate) && (s.lanes |= n), Ki(a.return, n, e), s = null !== (s = a.child) ? s.sibling : null) : s = a.child;
			if (null !== s) s.return = a;
			else
				for (s = a; null !== s;) {
					if (s === e) {
						s = null;
						break
					}
					if (null !== (a = s.sibling)) {
						a.return = s.return, s = a;
						break
					}
					s = s.return
				}
			a = s
		}
	}

	function Xi(e, t, n, i) {
		e = null;
		for (var a = t, o = !1; null !== a;) {
			if (!o)
				if (524288 & a.flags) o = !0;
				else if (262144 & a.flags) break;
			if (10 === a.tag) {
				var s = a.alternate;
				if (null === s) throw Error(r(387));
				if (null !== (s = s.memoizedProps)) {
					var l = a.type;
					mr(a.pendingProps.value, s.value) || (null !== e ? e.push(l) : e = [l])
				}
			} else if (a === ae.current) {
				if (null === (s = a.alternate)) throw Error(r(387));
				s.memoizedState.memoizedState !== a.memoizedState.memoizedState && (null !== e ? e.push(up) : e = [up])
			}
			a = a.return
		}
		return null !== e && Qi(t, e, n, i), t.flags |= 262144, null !== e
	}

	function Gi(e) {
		for (e = e.firstContext; null !== e;) {
			if (!mr(e.context._currentValue, e.memoizedValue)) return !0;
			e = e.next
		}
		return !1
	}

	function Ji(e) {
		Wi = e, Zi = null, null !== (e = e.dependencies) && (e.firstContext = null)
	}

	function ea(e) {
		return na(Wi, e)
	}

	function ta(e, t) {
		return null === Wi && Ji(e), na(e, t)
	}

	function na(e, t) {
		var n = t._currentValue;
		if (t = {
			context: t,
			memoizedValue: n,
			next: null
		}, null === Zi) {
			if (null === e) throw Error(r(308));
			Zi = t, e.dependencies = {
				lanes: 0,
				firstContext: t
			}, e.flags |= 524288
		} else Zi = Zi.next = t;
		return n
	}
	var ra = typeof AbortController < "u" ? AbortController : function () {
		var e = [],
			t = this.signal = {
				aborted: !1,
				addEventListener: function (t, n) {
					e.push(n)
				}
			};
		this.abort = function () {
			t.aborted = !0, e.forEach(function (e) {
				return e()
			})
		}
	},
		ia = e.unstable_scheduleCallback,
		aa = e.unstable_NormalPriority,
		oa = {
			$$typeof: A,
			Consumer: null,
			Provider: null,
			_currentValue: null,
			_currentValue2: null,
			_threadCount: 0
		};

	function sa() {
		return {
			controller: new ra,
			data: new Map,
			refCount: 0
		}
	}

	function la(e) {
		e.refCount--, 0 === e.refCount && ia(aa, function () {
			e.controller.abort()
		})
	}

	function ua(e, t) {
		if (4194048 & e.pendingLanes) {
			var n = e.transitionTypes;
			for (null === n && (n = e.transitionTypes = []), e = 0; e < t.length; e++) {
				var r = t[e]; - 1 === n.indexOf(r) && n.push(r)
			}
		}
	}
	var ca = null;
	var da = null,
		fa = 0,
		ha = 0,
		pa = null;

	function ma() {
		if (0 === --fa && (ca = null, null !== da)) {
			null !== pa && (pa.status = "fulfilled");
			var e = da;
			da = null, ha = 0, pa = null;
			for (var t = 0; t < e.length; t++)(0, e[t])()
		}
	}
	var ga = Z.S;
	Z.S = function (e, t) {
		if ($c = xe(), "object" == typeof t && null !== t && "function" == typeof t.then && function (e, t) {
			if (null === da) {
				var n = da = [];
				fa = 0, ha = sf(), pa = {
					status: "pending",
					value: void 0,
					then: function (e) {
						n.push(e)
					}
				}
			}
			fa++, t.then(ma, ma)
		}(0, t), null !== ca)
			for (var n = Yd; null !== n;) ua(n, ca), n = n.next;
		if (null !== (n = e.types)) {
			for (var r = Yd; null !== r;) ua(r, n), r = r.next;
			if (0 !== ha) {
				null === (r = ca) && (r = ca = []);
				for (var i = 0; i < n.length; i++) {
					var a = n[i]; - 1 === r.indexOf(a) && r.push(a)
				}
			}
		}
		null !== ga && ga(e, t)
	};
	var va = X(null);

	function ya() {
		var e = va.current;
		return null !== e ? e : Tc.pooledCache
	}

	function ba(e, t) {
		J(va, null === t ? va.current : t.pool)
	}

	function xa() {
		var e = ya();
		return null === e ? null : {
			parent: oa._currentValue,
			pool: e
		}
	}
	var wa = Error(r(460)),
		Sa = Error(r(474)),
		Ea = Error(r(542)),
		ka = {
			then: function () { }
		};

	function Ta(e) {
		return "fulfilled" === (e = e.status) || "rejected" === e
	}

	function Pa(e, t, n) {
		switch (void 0 === (n = e[n]) ? e.push(t) : n !== t && (t.then(qt, qt), t = n), t.status) {
			case "fulfilled":
				return t.value;
			case "rejected":
				throw Aa(e = t.reason), void 0 !== e || "reason" in t ? e : Error(r(600));
			default:
				if ("string" == typeof t.status) t.then(qt, qt);
				else {
					if (null !== (e = Tc) && 100 < e.shellSuspendCounter) throw Error(r(482));
					(e = t).status = "pending", e.then(function (e) {
						if ("pending" === t.status) {
							var n = t;
							n.status = "fulfilled", n.value = e
						}
					}, function (e) {
						if ("pending" === t.status) {
							var n = t;
							n.status = "rejected", n.reason = e
						}
					})
				}
				switch (t.status) {
					case "fulfilled":
						return t.value;
					case "rejected":
						throw Aa(e = t.reason), e
				}
				throw Na = t, wa
		}
	}

	function Ca(e) {
		try {
			return (0, e._init)(e._payload)
		} catch (e) {
			throw null !== e && "object" == typeof e && "function" == typeof e.then ? (Na = e, wa) : e
		}
	}
	var Na = null;

	function Ma() {
		if (null === Na) throw Error(r(459));
		var e = Na;
		return Na = null, e
	}

	function Aa(e) {
		if (e === wa || e === Ea) throw Error(r(483))
	}
	var _a = null,
		La = 0;

	function Da(e) {
		var t = La;
		return La += 1, null === _a && (_a = []), Pa(_a, e, t)
	}

	function ja(e, t) {
		t = t.props.ref, e.ref = void 0 !== t ? t : null
	}

	function Oa(e, t) {
		throw t.$$typeof === E ? Error(r(525)) : (e = Object.prototype.toString.call(t), Error(r(31, "[object Object]" === e ? "object with keys {" + Object.keys(t).join(", ") + "}" : e)))
	}

	function za(e) {
		function t(t, n) {
			if (e) {
				var r = t.deletions;
				null === r ? (t.deletions = [n], t.flags |= 16) : r.push(n)
			}
		}

		function n(n, r) {
			if (!e) return null;
			for (; null !== r;) t(n, r), r = r.sibling;
			return null
		}

		function i(e) {
			for (var t = new Map; null !== e;) null === e.key ? t.set(e.index, e) : t.set(e.key, e), e = e.sibling;
			return t
		}

		function a(e, t) {
			return (e = li(e, t)).index = 0, e.sibling = null, e
		}

		function o(t, n, r) {
			return t.index = r, e ? null !== (r = t.alternate) ? (r = r.index) < n ? (t.flags |= 2, n) : r : (t.flags |= 134217730, n) : (t.flags |= 1048576, n)
		}

		function s(t) {
			return e && null === t.alternate && (t.flags |= 134217730), t
		}

		function l(e, t, n, r) {
			return null === t || 6 !== t.tag ? ((t = fi(n, e.mode, r)).return = e, t) : ((t = a(t, n)).return = e, t)
		}

		function u(e, t, n, r) {
			var i = n.type;
			return i === P ? (ja(e = d(e, t, n.props.children, r, n.key), n), e) : null !== t && (t.elementType === i || "object" == typeof i && null !== i && i.$$typeof === O && Ca(i) === t.type) ? (ja(t = a(t, n.props), n), t.return = e, t) : (ja(t = ci(n.type, n.key, n.props, null, e.mode, r), n), t.return = e, t)
		}

		function c(e, t, n, r) {
			return null === t || 4 !== t.tag || t.stateNode.containerInfo !== n.containerInfo || t.stateNode.implementation !== n.implementation ? ((t = pi(n, e.mode, r)).return = e, t) : ((t = a(t, n.children || [])).return = e, t)
		}

		function d(e, t, n, r, i) {
			return null === t || 7 !== t.tag ? ((t = di(n, e.mode, r, i)).return = e, t) : ((t = a(t, n)).return = e, t)
		}

		function f(e, t, n) {
			if ("string" == typeof t && "" !== t || "number" == typeof t || "bigint" == typeof t) return (t = fi("" + t, e.mode, n)).return = e, t;
			if ("object" == typeof t && null !== t) {
				switch (t.$$typeof) {
					case k:
						return ja(n = ci(t.type, t.key, t.props, null, e.mode, n), t), n.return = e, n;
					case T:
						return (t = pi(t, e.mode, n)).return = e, t;
					case O:
						return f(e, t = Ca(t), n)
				}
				if (W(t) || U(t)) return (t = di(t, e.mode, n, null)).return = e, t;
				if ("function" == typeof t.then) return f(e, Da(t), n);
				if (t.$$typeof === A) return f(e, ta(e, t), n);
				Oa(e, t)
			}
			return null
		}

		function h(e, t, n, r) {
			var i = null !== t ? t.key : null;
			if ("string" == typeof n && "" !== n || "number" == typeof n || "bigint" == typeof n) return null !== i ? null : l(e, t, "" + n, r);
			if ("object" == typeof n && null !== n) {
				switch (n.$$typeof) {
					case k:
						return n.key === i ? u(e, t, n, r) : null;
					case T:
						return n.key === i ? c(e, t, n, r) : null;
					case O:
						return h(e, t, n = Ca(n), r)
				}
				if (W(n) || U(n)) return null !== i ? null : d(e, t, n, r, null);
				if ("function" == typeof n.then) return h(e, t, Da(n), r);
				if (n.$$typeof === A) return h(e, t, ta(e, n), r);
				Oa(e, n)
			}
			return null
		}

		function p(e, t, n, r, i) {
			if ("string" == typeof r && "" !== r || "number" == typeof r || "bigint" == typeof r) return l(t, e = e.get(n) || null, "" + r, i);
			if ("object" == typeof r && null !== r) {
				switch (r.$$typeof) {
					case k:
						return u(t, e = e.get(null === r.key ? n : r.key) || null, r, i);
					case T:
						return c(t, e = e.get(null === r.key ? n : r.key) || null, r, i);
					case O:
						return p(e, t, n, r = Ca(r), i)
				}
				if (W(r) || U(r)) return d(t, e = e.get(n) || null, r, i, null);
				if ("function" == typeof r.then) return p(e, t, n, Da(r), i);
				if (r.$$typeof === A) return p(e, t, n, ta(t, r), i);
				Oa(t, r)
			}
			return null
		}

		function m(l, u, c, d) {
			if ("object" == typeof c && null !== c && c.type === P && null === c.key && void 0 === c.props.ref && (c = c.props.children), "object" == typeof c && null !== c) {
				switch (c.$$typeof) {
					case k:
						e: {
							for (var g = c.key; null !== u;) {
								if (u.key === g) {
									if ((g = c.type) === P) {
										if (7 === u.tag) {
											n(l, u.sibling), ja(d = a(u, c.props.children), c), d.return = l, l = d;
											break e
										}
									} else if (u.elementType === g || "object" == typeof g && null !== g && g.$$typeof === O && Ca(g) === u.type) {
										n(l, u.sibling), ja(d = a(u, c.props), c), d.return = l, l = d;
										break e
									}
									n(l, u);
									break
								}
								t(l, u), u = u.sibling
							}
							c.type === P ? (ja(d = di(c.props.children, l.mode, d, c.key), c), d.return = l, l = d) : (ja(d = ci(c.type, c.key, c.props, null, l.mode, d), c), d.return = l, l = d)
						}
						return s(l);
					case T:
						e: {
							for (g = c.key; null !== u;) {
								if (u.key === g) {
									if (4 === u.tag && u.stateNode.containerInfo === c.containerInfo && u.stateNode.implementation === c.implementation) {
										n(l, u.sibling), (d = a(u, c.children || [])).return = l, l = d;
										break e
									}
									n(l, u);
									break
								}
								t(l, u), u = u.sibling
							} (d = pi(c, l.mode, d)).return = l,
								l = d
						}
						return s(l);
					case O:
						return m(l, u, c = Ca(c), d)
				}
				if (W(c)) return function (r, a, s, l) {
					for (var u = null, c = null, d = a, m = a = 0, g = null; null !== d && m < s.length; m++) {
						d.index > m ? (g = d, d = null) : g = d.sibling;
						var v = h(r, d, s[m], l);
						if (null === v) {
							null === d && (d = g);
							break
						}
						e && d && null === v.alternate && t(r, d), a = o(v, a, m), null === c ? u = v : c.sibling = v, c = v, d = g
					}
					if (m === s.length) return n(r, d), Di && Pi(r, m), u;
					if (null === d) {
						for (; m < s.length; m++) null !== (d = f(r, s[m], l)) && (a = o(d, a, m), null === c ? u = d : c.sibling = d, c = d);
						return Di && Pi(r, m), u
					}
					for (d = i(d); m < s.length; m++) null !== (g = p(d, r, m, s[m], l)) && (e && null !== (v = g.alternate) && d.delete(null === v.key ? m : v.key), a = o(g, a, m), null === c ? u = g : c.sibling = g, c = g);
					return e && d.forEach(function (e) {
						return t(r, e)
					}), Di && Pi(r, m), u
				}(l, u, c, d);
				if (U(c)) {
					if ("function" != typeof (g = U(c))) throw Error(r(150));
					return function (a, s, l, u) {
						if (null == l) throw Error(r(151));
						for (var c = null, d = null, m = s, g = s = 0, v = null, y = l.next(); null !== m && !y.done; g++, y = l.next()) {
							m.index > g ? (v = m, m = null) : v = m.sibling;
							var b = h(a, m, y.value, u);
							if (null === b) {
								null === m && (m = v);
								break
							}
							e && m && null === b.alternate && t(a, m), s = o(b, s, g), null === d ? c = b : d.sibling = b, d = b, m = v
						}
						if (y.done) return n(a, m), Di && Pi(a, g), c;
						if (null === m) {
							for (; !y.done; g++, y = l.next()) null !== (y = f(a, y.value, u)) && (s = o(y, s, g), null === d ? c = y : d.sibling = y, d = y);
							return Di && Pi(a, g), c
						}
						for (m = i(m); !y.done; g++, y = l.next()) null !== (y = p(m, a, g, y.value, u)) && (e && null !== (v = y.alternate) && m.delete(null === v.key ? g : v.key), s = o(y, s, g), null === d ? c = y : d.sibling = y, d = y);
						return e && m.forEach(function (e) {
							return t(a, e)
						}), Di && Pi(a, g), c
					}(l, u, c = g.call(c), d)
				}
				if ("function" == typeof c.then) return m(l, u, Da(c), d);
				if (c.$$typeof === A) return m(l, u, ta(l, c), d);
				Oa(l, c)
			}
			return "string" == typeof c && "" !== c || "number" == typeof c || "bigint" == typeof c ? (c = "" + c, null !== u && 6 === u.tag ? (n(l, u.sibling), (d = a(u, c)).return = l, l = d) : (n(l, u), (d = fi(c, l.mode, d)).return = l, l = d), s(l)) : n(l, u)
		}
		return function (e, t, n, r) {
			try {
				La = 0;
				var i = m(e, t, n, r);
				return _a = null, i
			} catch (t) {
				if (t === wa || t === Ea) throw t;
				var a = oi(29, t, null, e.mode);
				return a.lanes = r, a.return = e, a
			}
		}
	}
	var Ra = za(!0),
		Fa = za(!1),
		Ia = !1;

	function Va(e) {
		e.updateQueue = {
			baseState: e.memoizedState,
			firstBaseUpdate: null,
			lastBaseUpdate: null,
			shared: {
				pending: null,
				lanes: 0,
				hiddenCallbacks: null
			},
			callbacks: null
		}
	}

	function Ba(e, t) {
		e = e.updateQueue, t.updateQueue === e && (t.updateQueue = {
			baseState: e.baseState,
			firstBaseUpdate: e.firstBaseUpdate,
			lastBaseUpdate: e.lastBaseUpdate,
			shared: e.shared,
			callbacks: null
		})
	}

	function Ua(e) {
		return {
			lane: e,
			tag: 0,
			payload: null,
			callback: null,
			next: null
		}
	}

	function Ha(e, t, n) {
		var r = e.updateQueue;
		if (null === r) return null;
		if (r = r.shared, 2 & kc) {
			var i = r.pending;
			return null === i ? t.next = t : (t.next = i.next, i.next = t), r.pending = t, t = ri(e), ni(e, null, n), t
		}
		return Jr(e, r, t, n), ri(e)
	}

	function $a(e, t, n) {
		if (null !== (t = t.updateQueue) && (t = t.shared, 4194048 & n)) {
			var r = t.lanes;
			n |= r &= e.pendingLanes, t.lanes = n, Ye(e, n)
		}
	}

	function Wa(e, t) {
		var n = e.updateQueue,
			r = e.alternate;
		if (null !== r && n === (r = r.updateQueue)) {
			var i = null,
				a = null;
			if (null !== (n = n.firstBaseUpdate)) {
				do {
					var o = {
						lane: n.lane,
						tag: n.tag,
						payload: n.payload,
						callback: null,
						next: null
					};
					null === a ? i = a = o : a = a.next = o, n = n.next
				} while (null !== n);
				null === a ? i = a = t : a = a.next = t
			} else i = a = t;
			return n = {
				baseState: r.baseState,
				firstBaseUpdate: i,
				lastBaseUpdate: a,
				shared: r.shared,
				callbacks: r.callbacks
			}, void (e.updateQueue = n)
		}
		null === (e = n.lastBaseUpdate) ? n.firstBaseUpdate = t : e.next = t, n.lastBaseUpdate = t
	}
	var Za = !1;

	function Ya() {
		if (Za) {
			if (null !== pa) throw pa
		}
	}

	function qa(e, t, n, r) {
		Za = !1;
		var i = e.updateQueue;
		Ia = !1;
		var a = i.firstBaseUpdate,
			o = i.lastBaseUpdate,
			s = i.shared.pending;
		if (null !== s) {
			i.shared.pending = null;
			var l = s,
				u = l.next;
			l.next = null, null === o ? a = u : o.next = u, o = l;
			var c = e.alternate;
			null !== c && ((s = (c = c.updateQueue).lastBaseUpdate) !== o && (null === s ? c.firstBaseUpdate = u : s.next = u, c.lastBaseUpdate = l))
		}
		if (null !== a) {
			var d = i.baseState;
			for (o = 0, c = u = l = null, s = a; ;) {
				var f = -536870913 & s.lane,
					h = f !== s.lane;
				if (h ? (Cc & f) === f : (r & f) === f) {
					0 !== f && f === ha && (Za = !0), null !== c && (c = c.next = {
						lane: 0,
						tag: s.tag,
						payload: s.payload,
						callback: null,
						next: null
					});
					e: {
						var p = e,
							m = s; f = t;
						var g = n;
						switch (m.tag) {
							case 1:
								if ("function" == typeof (p = m.payload)) {
									d = p.call(g, d, f);
									break e
								}
								d = p;
								break e;
							case 3:
								p.flags = -65537 & p.flags | 128;
							case 0:
								if (null == (f = "function" == typeof (p = m.payload) ? p.call(g, d, f) : p)) break e;
								d = S({}, d, f);
								break e;
							case 2:
								Ia = !0
						}
					}
					null !== (f = s.callback) && (e.flags |= 64, h && (e.flags |= 8192), null === (h = i.callbacks) ? i.callbacks = [f] : h.push(f))
				} else h = {
					lane: f,
					tag: s.tag,
					payload: s.payload,
					callback: s.callback,
					next: null
				}, null === c ? (u = c = h, l = d) : c = c.next = h, o |= f;
				if (null === (s = s.next)) {
					if (null === (s = i.shared.pending)) break;
					s = (h = s).next, h.next = null, i.lastBaseUpdate = h, i.shared.pending = null
				}
			}
			null === c && (l = d), i.baseState = l, i.firstBaseUpdate = u, i.lastBaseUpdate = c, null === a && (i.shared.lanes = 0), Oc |= o, e.lanes = o, e.memoizedState = d
		}
	}

	function Ka(e, t) {
		if ("function" != typeof e) throw Error(r(191, e));
		e.call(t)
	}

	function Qa(e, t) {
		var n = e.callbacks;
		if (null !== n)
			for (e.callbacks = null, e = 0; e < n.length; e++) Ka(n[e], t)
	}
	var Xa = X(null),
		Ga = X(0);

	function Ja(e, t) {
		J(Ga, e = Dc), J(Xa, t), Dc = e | t.baseLanes
	}

	function eo() {
		J(Ga, Dc), J(Xa, Xa.current)
	}

	function to() {
		Dc = Ga.current, G(Xa), G(Ga)
	}
	var no = X(null),
		ro = null;

	function io(e) {
		var t = e.alternate;
		J(uo, 1 & uo.current), J(no, e), null === ro && (null === t || null !== Xa.current || null !== t.memoizedState) && (ro = e)
	}

	function ao(e) {
		J(uo, uo.current), J(no, e), null === ro && (ro = e)
	}

	function oo(e) {
		22 === e.tag ? (J(uo, uo.current), J(no, e), null === ro && (ro = e)) : so()
	}

	function so() {
		J(uo, uo.current), J(no, no.current)
	}

	function lo(e) {
		G(no), ro === e && (ro = null), G(uo)
	}
	var uo = X(0);

	function co(e, t) {
		J(no, no.current), J(uo, t)
	}

	function fo(e) {
		G(uo), G(no), ro === e && (ro = null)
	}

	function ho(e) {
		for (var t = e; null !== t;) {
			if (13 === t.tag) {
				var n = t.memoizedState;
				if (null !== n && (null === (n = n.dehydrated) || kh(n) || Th(n))) return t
			} else if (19 === t.tag && "independent" !== t.memoizedProps.revealOrder) {
				if (128 & t.flags) return t
			} else if (null !== t.child) {
				t.child.return = t, t = t.child;
				continue
			}
			if (t === e) break;
			for (; null === t.sibling;) {
				if (null === t.return || t.return === e) return null;
				t = t.return
			}
			t.sibling.return = t.return, t = t.sibling
		}
		return null
	}
	var po = 0,
		mo = null,
		go = null,
		vo = null,
		yo = !1,
		bo = !1,
		xo = !1,
		wo = 0,
		So = 0,
		Eo = null,
		ko = 0;

	function To() {
		throw Error(r(321))
	}

	function Po(e, t) {
		if (null === t) return !1;
		for (var n = 0; n < t.length && n < e.length; n++)
			if (!mr(e[n], t[n])) return !1;
		return !0
	}

	function Co(e, t, n, r, i, a) {
		return po = a, mo = t, t.memoizedState = null, t.updateQueue = null, t.lanes = 0, Z.H = null === e || null === e.memoizedState ? Hs : $s, xo = !1, a = n(r, i), xo = !1, bo && (a = Mo(t, n, r, i)), No(e), a
	}

	function No(e) {
		Z.H = Us;
		var t = null !== go && null !== go.next;
		if (po = 0, vo = go = mo = null, yo = !1, So = 0, Eo = null, t) throw Error(r(300));
		null === e || ol || null !== (e = e.dependencies) && Gi(e) && (ol = !0)
	}

	function Mo(e, t, n, i) {
		mo = e;
		var a = 0;
		do {
			if (bo && (Eo = null), So = 0, bo = !1, 25 <= a) throw Error(r(301));
			if (a += 1, vo = go = null, null != e.updateQueue) {
				var o = e.updateQueue;
				o.lastEffect = null, o.events = null, o.stores = null, null != o.memoCache && (o.memoCache.index = 0)
			}
			Z.H = Ws, o = t(n, i)
		} while (bo);
		return o
	}

	function Ao() {
		var e = Z.H,
			t = e.useState()[0];
		return t = "function" == typeof t.then ? zo(t) : t, e = e.useState()[0], (null !== go ? go.memoizedState : null) !== e && (mo.flags |= 1024), t
	}

	function _o() {
		var e = 0 !== wo;
		return wo = 0, e
	}

	function Lo(e, t, n) {
		t.updateQueue = e.updateQueue, t.flags &= -2053, e.lanes &= ~n
	}

	function Do(e) {
		if (yo) {
			for (e = e.memoizedState; null !== e;) {
				var t = e.queue;
				null !== t && (t.pending = null), e = e.next
			}
			yo = !1
		}
		po = 0, vo = go = mo = null, bo = !1, So = wo = 0, Eo = null
	}

	function jo() {
		var e = {
			memoizedState: null,
			baseState: null,
			baseQueue: null,
			queue: null,
			next: null
		};
		return null === vo ? mo.memoizedState = vo = e : vo = vo.next = e, vo
	}

	function Oo() {
		if (null === go) {
			var e = mo.alternate;
			e = null !== e ? e.memoizedState : null
		} else e = go.next;
		var t = null === vo ? mo.memoizedState : vo.next;
		if (null !== t) vo = t, go = e;
		else {
			if (null === e) throw null === mo.alternate ? Error(r(467)) : Error(r(310));
			e = {
				memoizedState: (go = e).memoizedState,
				baseState: go.baseState,
				baseQueue: go.baseQueue,
				queue: go.queue,
				next: null
			}, null === vo ? mo.memoizedState = vo = e : vo = vo.next = e
		}
		return vo
	}

	function zo(e) {
		var t = So;
		return So += 1, null === Eo && (Eo = []), e = Pa(Eo, e, t), t = mo, null === (null === vo ? t.memoizedState : vo.next) && (t = t.alternate, Z.H = null === t || null === t.memoizedState ? Hs : $s), e
	}

	function Ro(e) {
		if (null !== e && "object" == typeof e) {
			if ("function" == typeof e.then) return zo(e);
			if (e.$$typeof === V) return;
			if (e.$$typeof === A) return ea(e)
		}
		throw Error(r(438, String(e)))
	}

	function Fo(e) {
		var t = null,
			n = mo.updateQueue;
		if (null !== n && (t = n.memoCache), null == t) {
			var r = mo.alternate;
			null !== r && (null !== (r = r.updateQueue) && (null != (r = r.memoCache) && (t = {
				data: r.data.map(function (e) {
					return e.slice()
				}),
				index: 0
			})))
		}
		if (null == t && (t = {
			data: [],
			index: 0
		}), null === n && (n = {
			lastEffect: null,
			events: null,
			stores: null,
			memoCache: null
		}, mo.updateQueue = n), n.memoCache = t, void 0 === (n = t.data[t.index]))
			for (n = t.data[t.index] = Array(e), r = 0; r < e; r++) n[r] = F;
		return t.index++, n
	}

	function Io(e, t) {
		return "function" == typeof t ? t(e) : t
	}

	function Vo(e) {
		return Bo(Oo(), go, e)
	}

	function Bo(e, t, n) {
		var i = e.queue;
		if (null === i) throw Error(r(311));
		i.lastRenderedReducer = n;
		var a = e.baseQueue,
			o = i.pending;
		if (null !== o) {
			if (null !== a) {
				var s = a.next;
				a.next = o.next, o.next = s
			}
			t.baseQueue = a = o, i.pending = null
		}
		if (o = e.baseState, null === a) e.memoizedState = o;
		else {
			var l = s = null,
				u = null,
				c = t = a.next,
				d = !1;
			do {
				var f = -536870913 & c.lane;
				if (f !== c.lane ? (Cc & f) === f : (po & f) === f) {
					var h = c.revertLane;
					if (0 === h) null !== u && (u = u.next = {
						lane: 0,
						revertLane: 0,
						gesture: null,
						action: c.action,
						hasEagerState: c.hasEagerState,
						eagerState: c.eagerState,
						next: null
					}), f === ha && (d = !0);
					else {
						if ((po & h) === h) {
							c = c.next, h === ha && (d = !0);
							continue
						}
						f = {
							lane: 0,
							revertLane: c.revertLane,
							gesture: null,
							action: c.action,
							hasEagerState: c.hasEagerState,
							eagerState: c.eagerState,
							next: null
						}, null === u ? (l = u = f, s = o) : u = u.next = f, mo.lanes |= h, Oc |= h
					}
					f = c.action, xo && n(o, f), o = c.hasEagerState ? c.eagerState : n(o, f)
				} else h = {
					lane: f,
					revertLane: c.revertLane,
					gesture: c.gesture,
					action: c.action,
					hasEagerState: c.hasEagerState,
					eagerState: c.eagerState,
					next: null
				}, null === u ? (l = u = h, s = o) : u = u.next = h, mo.lanes |= f, Oc |= f;
				c = c.next
			} while (null !== c && c !== t);
			if (null === u ? s = o : u.next = l, !mr(o, e.memoizedState) && (ol = !0, d && null !== (n = pa))) throw n;
			e.memoizedState = o, e.baseState = s, e.baseQueue = u, i.lastRenderedState = o
		}
		return null === a && (i.lanes = 0), [e.memoizedState, i.dispatch]
	}

	function Uo(e) {
		var t = Oo(),
			n = t.queue;
		if (null === n) throw Error(r(311));
		n.lastRenderedReducer = e;
		var i = n.dispatch,
			a = n.pending,
			o = t.memoizedState;
		if (null !== a) {
			n.pending = null;
			var s = a = a.next;
			do {
				o = e(o, s.action), s = s.next
			} while (s !== a);
			mr(o, t.memoizedState) || (ol = !0), t.memoizedState = o, null === t.baseQueue && (t.baseState = o), n.lastRenderedState = o
		}
		return [o, i]
	}

	function Ho(e, t, n) {
		var i = mo,
			a = Oo(),
			o = Di;
		if (o) {
			if (void 0 === n) throw Error(r(407));
			n = n()
		} else n = t();
		var s = !mr((go || a).memoizedState, n);
		if (s && (a.memoizedState = n, ol = !0), a = a.queue, ps(Zo.bind(null, i, a, e), [e]), us((e = a.getSnapshot !== t || s || null !== vo && !!(1 & vo.memoizedState.tag)) ? 9 : 8, {
			destroy: void 0
		}, Wo.bind(null, i, a, n, t), null), e) {
			if (i.flags |= 2048, null === Tc) throw Error(r(349));
			o || 127 & po || $o(i, t, n)
		}
		return n
	}

	function $o(e, t, n) {
		e.flags |= 16384, e = {
			getSnapshot: t,
			value: n
		}, null === (t = mo.updateQueue) ? (t = {
			lastEffect: null,
			events: null,
			stores: null,
			memoCache: null
		}, mo.updateQueue = t, t.stores = [e]) : null === (n = t.stores) ? t.stores = [e] : n.push(e)
	}

	function Wo(e, t, n, r) {
		t.value = n, t.getSnapshot = r, Yo(t) && qo(e)
	}

	function Zo(e, t, n) {
		return n(function () {
			Yo(t) && qo(e)
		})
	}

	function Yo(e) {
		var t = e.getSnapshot;
		e = e.value;
		try {
			var n = t();
			return !mr(e, n)
		} catch {
			return !0
		}
	}

	function qo(e) {
		var t = ti(e, 2);
		null !== t && ud(t, e, 2)
	}

	function Ko(e) {
		var t = jo();
		if ("function" == typeof e) {
			var n = e;
			if (e = n(), xo) {
				_e(!0);
				try {
					n()
				} finally {
					_e(!1)
				}
			}
		}
		return t.memoizedState = t.baseState = e, t.queue = {
			pending: null,
			lanes: 0,
			dispatch: null,
			lastRenderedReducer: Io,
			lastRenderedState: e
		}, t
	}

	function Qo(e, t, n, r) {
		return e.baseState = n, Bo(e, go, "function" == typeof r ? r : Io)
	}

	function Xo(e, t, n, i, a) {
		if (Is(e)) throw Error(r(485));
		if (null !== (e = t.action)) {
			var o = {
				payload: a,
				action: e,
				next: null,
				isTransition: !0,
				status: "pending",
				value: null,
				reason: null,
				listeners: [],
				then: function (e) {
					o.listeners.push(e)
				}
			};
			null !== Z.T ? n(!0) : o.isTransition = !1, i(o), null === (n = t.pending) ? (o.next = t.pending = o, Go(t, o)) : (o.next = n.next, t.pending = n.next = o)
		}
	}

	function Go(e, t) {
		var n = t.action,
			r = t.payload,
			i = e.state;
		if (t.isTransition) {
			var a = Z.T,
				o = {};
			o.types = null !== a ? a.types : null, Z.T = o;
			try {
				var s = n(i, r),
					l = Z.S;
				null !== l && l(o, s), Jo(e, t, s)
			} catch (n) {
				ts(e, t, n)
			} finally {
				null !== a && null !== o.types && (a.types = o.types), Z.T = a
			}
		} else try {
			Jo(e, t, a = n(i, r))
		} catch (n) {
			ts(e, t, n)
		}
	}

	function Jo(e, t, n) {
		null !== n && "object" == typeof n && "function" == typeof n.then ? n.then(function (n) {
			es(e, t, n)
		}, function (n) {
			return ts(e, t, n)
		}) : es(e, t, n)
	}

	function es(e, t, n) {
		t.status = "fulfilled", t.value = n, ns(t), e.state = n, null !== (t = e.pending) && ((n = t.next) === t ? e.pending = null : (n = n.next, t.next = n, Go(e, n)))
	}

	function ts(e, t, n) {
		var r = e.pending;
		if (e.pending = null, null !== r) {
			r = r.next;
			do {
				t.status = "rejected", t.reason = n, ns(t), t = t.next
			} while (t !== r)
		}
		e.action = null
	}

	function ns(e) {
		e = e.listeners;
		for (var t = 0; t < e.length; t++)(0, e[t])()
	}

	function rs(e, t) {
		return t
	}

	function is(e, t) {
		if (Di) {
			var n = Tc.formState;
			if (null !== n) {
				e: {
					var r = mo;
					if (Di) {
						if (Li) {
							t: {
								for (var i = Li, a = Oi; 8 !== i.nodeType;) {
									if (!a) {
										i = null;
										break t
									}
									if (null === (i = Ph(i.nextSibling))) {
										i = null;
										break t
									}
								}
								i = "F!" === (a = i.data) || "F" === a ? i : null
							}
							if (i) {
								Li = Ph(i.nextSibling), r = "F!" === i.data;
								break e
							}
						}
						Ri(r)
					}
					r = !1
				}
				r && (t = n[0])
			}
		}
		return (n = jo()).memoizedState = n.baseState = t, r = {
			pending: null,
			lanes: 0,
			dispatch: null,
			lastRenderedReducer: rs,
			lastRenderedState: t
		}, n.queue = r, n = zs.bind(null, mo, r), r.dispatch = n, r = Ko(!1), a = Fs.bind(null, mo, !1, r.queue), i = {
			state: t,
			dispatch: null,
			action: e,
			pending: null
		}, (r = jo()).queue = i, n = Xo.bind(null, mo, i, a, n), i.dispatch = n, r.memoizedState = e, [t, n, !1]
	}

	function as(e) {
		return os(Oo(), go, e)
	}

	function os(e, t, n) {
		if (t = Bo(e, t, rs)[0], e = Vo(Io)[0], "object" == typeof t && null !== t && "function" == typeof t.then) try {
			var r = zo(t)
		} catch (e) {
			throw e === wa ? Ea : e
		} else r = t;
		var i = (t = Oo()).queue,
			a = i.dispatch;
		return n !== t.memoizedState && (mo.flags |= 2048, us(9, {
			destroy: void 0
		}, ss.bind(null, i, n), null)), [r, a, e]
	}

	function ss(e, t) {
		e.action = t
	}

	function ls(e) {
		var t = Oo(),
			n = go;
		if (null !== n) return os(t, n, e);
		Oo(), t = t.memoizedState;
		var r = (n = Oo()).queue.dispatch;
		return n.memoizedState = e, [t, r, !1]
	}

	function us(e, t, n, r) {
		return e = {
			tag: e,
			create: n,
			deps: r,
			inst: t,
			next: null
		}, null === (t = mo.updateQueue) && (t = {
			lastEffect: null,
			events: null,
			stores: null,
			memoCache: null
		}, mo.updateQueue = t), null === (n = t.lastEffect) ? t.lastEffect = e.next = e : (r = n.next, n.next = e, e.next = r, t.lastEffect = e), e
	}

	function cs() {
		return Oo().memoizedState
	}

	function ds(e, t, n, r) {
		var i = jo();
		mo.flags |= e, i.memoizedState = us(1 | t, {
			destroy: void 0
		}, n, void 0 === r ? null : r)
	}

	function fs(e, t, n, r) {
		var i = Oo();
		r = void 0 === r ? null : r;
		var a = i.memoizedState.inst;
		null !== go && null !== r && Po(r, go.memoizedState.deps) ? i.memoizedState = us(t, a, n, r) : (mo.flags |= e, i.memoizedState = us(1 | t, a, n, r))
	}

	function hs(e, t) {
		ds(8390656, 8, e, t)
	}

	function ps(e, t) {
		fs(2048, 8, e, t)
	}

	function gs(e) {
		var t = Oo().memoizedState;
		return function (e) {
			mo.flags |= 4;
			var t = mo.updateQueue;
			if (null === t) t = {
				lastEffect: null,
				events: null,
				stores: null,
				memoCache: null
			}, mo.updateQueue = t, t.events = [e];
			else {
				var n = t.events;
				null === n ? t.events = [e] : n.push(e)
			}
		}({
			ref: t,
			nextImpl: e
		}),
			function () {
				if (2 & kc) throw Error(r(440));
				return t.impl.apply(void 0, arguments)
			}
	}

	function vs(e, t) {
		return fs(4, 2, e, t)
	}

	function ys(e, t) {
		return fs(4, 4, e, t)
	}

	function bs(e, t) {
		if ("function" == typeof t) {
			e = e();
			var n = t(e);
			return function () {
				"function" == typeof n ? n() : t(null)
			}
		}
		if (null != t) return e = e(), t.current = e,
			function () {
				t.current = null
			}
	}

	function xs(e, t, n) {
		n = null != n ? n.concat([e]) : null, fs(4, 4, bs.bind(null, t, e), n)
	}

	function ws() { }

	function Ss(e, t) {
		var n = Oo();
		t = void 0 === t ? null : t;
		var r = n.memoizedState;
		return null !== t && Po(t, r[1]) ? r[0] : (n.memoizedState = [e, t], e)
	}

	function Es(e, t) {
		var n = Oo();
		t = void 0 === t ? null : t;
		var r = n.memoizedState;
		if (null !== t && Po(t, r[1])) return r[0];
		if (r = e(), xo) {
			_e(!0);
			try {
				e()
			} finally {
				_e(!1)
			}
		}
		return n.memoizedState = [r, t], r
	}

	function ks(e, t, n) {
		return void 0 === n || 1073741824 & po && !(261930 & Cc) ? e.memoizedState = t : (e.memoizedState = n, e = sd(), mo.lanes |= e, Oc |= e, n)
	}

	function Ts(e, t, n, r) {
		return mr(n, t) ? n : null !== Xa.current ? (e = ks(e, n, r), mr(e, t) || (ol = !0), e) : 106 & po && (!(1073741824 & po) || 261930 & Cc) ? (e = sd(), mo.lanes |= e, Oc |= e, t) : (ol = !0, e.memoizedState = n)
	}

	function Ps(e, t, n, r, i) {
		var a = Y.p;
		Y.p = 0 !== a && 8 > a ? a : 8;
		var o = Z.T,
			s = {};
		s.types = null !== o ? o.types : null, Z.T = s, Fs(e, !1, t, n);
		try {
			var l = i(),
				u = Z.S;
			if (null !== u && u(s, l), null !== l && "object" == typeof l && "function" == typeof l.then) {
				var c = function (e, t) {
					var n = [],
						r = {
							status: "pending",
							value: null,
							reason: null,
							then: function (e) {
								n.push(e)
							}
						};
					return e.then(function () {
						r.status = "fulfilled", r.value = t;
						for (var e = 0; e < n.length; e++)(0, n[e])(t)
					}, function (e) {
						for (r.status = "rejected", r.reason = e, e = 0; e < n.length; e++)(0, n[e])(void 0)
					}), r
				}(l, r);
				Rs(e, t, c, od())
			} else Rs(e, t, r, od())
		} catch (n) {
			Rs(e, t, {
				then: function () { },
				status: "rejected",
				reason: n
			}, od())
		} finally {
			Y.p = a, null !== o && null !== s.types && (o.types = s.types), Z.T = o
		}
	}

	function Cs() { }

	function Ns(e, t, n, i) {
		if (5 !== e.tag) throw Error(r(476));
		var a = Ms(e).queue;
		Ps(e, a, t, q, null === n ? Cs : function () {
			return As(e), n(i)
		})
	}

	function Ms(e) {
		var t = e.memoizedState;
		if (null !== t) return t;
		var n = {};
		return (t = {
			memoizedState: q,
			baseState: q,
			baseQueue: null,
			queue: {
				pending: null,
				lanes: 0,
				dispatch: null,
				lastRenderedReducer: Io,
				lastRenderedState: q
			},
			next: null
		}).next = {
			memoizedState: n,
			baseState: n,
			baseQueue: null,
			queue: {
				pending: null,
				lanes: 0,
				dispatch: null,
				lastRenderedReducer: Io,
				lastRenderedState: n
			},
			next: null
		}, e.memoizedState = t, null !== (e = e.alternate) && (e.memoizedState = t), t
	}

	function As(e) {
		var t = Ms(e);
		null === t.next && (t = e.alternate.memoizedState), Rs(e, t.next.queue, {}, od())
	}

	function _s() {
		return ea(up)
	}

	function Ls() {
		return Oo().memoizedState
	}

	function Ds() {
		return Oo().memoizedState
	}

	function js(e) {
		for (var t = e.return; null !== t;) {
			switch (t.tag) {
				case 24:
				case 3:
					var n = od(),
						r = Ha(t, e = Ua(n), n);
					return null !== r && (ud(r, t, n), $a(r, t, n)), t = {
						cache: sa()
					}, void (e.payload = t)
			}
			t = t.return
		}
	}

	function Os(e, t, n) {
		var r = od();
		n = {
			lane: r,
			revertLane: 0,
			gesture: null,
			action: n,
			hasEagerState: !1,
			eagerState: null,
			next: null
		}, Is(e) ? Vs(t, n) : null !== (n = ei(e, t, n, r)) && (ud(n, e, r), Bs(n, t, r))
	}

	function zs(e, t, n) {
		Rs(e, t, n, od())
	}

	function Rs(e, t, n, r) {
		var i = {
			lane: r,
			revertLane: 0,
			gesture: null,
			action: n,
			hasEagerState: !1,
			eagerState: null,
			next: null
		};
		if (Is(e)) Vs(t, i);
		else {
			var a = e.alternate;
			if (0 === e.lanes && (null === a || 0 === a.lanes) && null !== (a = t.lastRenderedReducer)) try {
				var o = t.lastRenderedState,
					s = a(o, n);
				if (i.hasEagerState = !0, i.eagerState = s, mr(s, o)) return Jr(e, t, i, 0), null === Tc && Gr(), !1
			} catch { }
			if (null !== (n = ei(e, t, i, r))) return ud(n, e, r), Bs(n, t, r), !0
		}
		return !1
	}

	function Fs(e, t, n, i) {
		if (i = {
			lane: 2,
			revertLane: sf(),
			gesture: null,
			action: i,
			hasEagerState: !1,
			eagerState: null,
			next: null
		}, Is(e)) {
			if (t) throw Error(r(479))
		} else null !== (t = ei(e, n, i, 2)) && ud(t, e, 2)
	}

	function Is(e) {
		var t = e.alternate;
		return e === mo || null !== t && t === mo
	}

	function Vs(e, t) {
		bo = yo = !0;
		var n = e.pending;
		null === n ? t.next = t : (t.next = n.next, n.next = t), e.pending = t
	}

	function Bs(e, t, n) {
		if (4194048 & n) {
			var r = t.lanes;
			n |= r &= e.pendingLanes, t.lanes = n, Ye(e, n)
		}
	}
	var Us = {
		readContext: ea,
		use: Ro,
		useCallback: To,
		useContext: To,
		useEffect: To,
		useImperativeHandle: To,
		useLayoutEffect: To,
		useInsertionEffect: To,
		useMemo: To,
		useReducer: To,
		useRef: To,
		useState: To,
		useDebugValue: To,
		useDeferredValue: To,
		useTransition: To,
		useSyncExternalStore: To,
		useId: To,
		useHostTransitionStatus: To,
		useFormState: To,
		useActionState: To,
		useOptimistic: To,
		useMemoCache: To,
		useCacheRefresh: To,
		useEffectEvent: To
	},
		Hs = {
			readContext: ea,
			use: Ro,
			useCallback: function (e, t) {
				return jo().memoizedState = [e, void 0 === t ? null : t], e
			},
			useContext: ea,
			useEffect: hs,
			useImperativeHandle: function (e, t, n) {
				n = null != n ? n.concat([e]) : null, ds(4194308, 4, bs.bind(null, t, e), n)
			},
			useLayoutEffect: function (e, t) {
				return ds(4194308, 4, e, t)
			},
			useInsertionEffect: function (e, t) {
				ds(4, 2, e, t)
			},
			useMemo: function (e, t) {
				var n = jo();
				t = void 0 === t ? null : t;
				var r = e();
				if (xo) {
					_e(!0);
					try {
						e()
					} finally {
						_e(!1)
					}
				}
				return n.memoizedState = [r, t], r
			},
			useReducer: function (e, t, n) {
				var r = jo();
				if (void 0 !== n) {
					var i = n(t);
					if (xo) {
						_e(!0);
						try {
							n(t)
						} finally {
							_e(!1)
						}
					}
				} else i = t;
				return r.memoizedState = r.baseState = i, e = {
					pending: null,
					lanes: 0,
					dispatch: null,
					lastRenderedReducer: e,
					lastRenderedState: i
				}, r.queue = e, e = e.dispatch = Os.bind(null, mo, e), [r.memoizedState, e]
			},
			useRef: function (e) {
				return e = {
					current: e
				}, jo().memoizedState = e
			},
			useState: function (e) {
				var t = (e = Ko(e)).queue,
					n = zs.bind(null, mo, t);
				return t.dispatch = n, [e.memoizedState, n]
			},
			useDebugValue: ws,
			useDeferredValue: function (e, t) {
				return ks(jo(), e, t)
			},
			useTransition: function () {
				var e = Ko(!1);
				return e = Ps.bind(null, mo, e.queue, !0, !1), jo().memoizedState = e, [!1, e]
			},
			useSyncExternalStore: function (e, t, n) {
				var i = mo,
					a = jo();
				if (Di) {
					if (void 0 === n) throw Error(r(407));
					n = n()
				} else {
					if (n = t(), null === Tc) throw Error(r(349));
					127 & Cc || $o(i, t, n)
				}
				a.memoizedState = n;
				var o = {
					value: n,
					getSnapshot: t
				};
				return a.queue = o, hs(Zo.bind(null, i, o, e), [e]), i.flags |= 2048, us(9, {
					destroy: void 0
				}, Wo.bind(null, i, o, n, t), null), n
			},
			useId: function () {
				var e = jo(),
					t = Tc.identifierPrefix;
				if (Di) {
					var n = Ti;
					t = "_" + t + "R_" + (n = (ki & ~(1 << 32 - Le(ki) - 1)).toString(32) + n), 0 < (n = wo++) && (t += "H" + n.toString(32)), t += "_"
				} else t = "_" + t + "r_" + (n = ko++).toString(32) + "_";
				return e.memoizedState = t
			},
			useHostTransitionStatus: _s,
			useFormState: is,
			useActionState: is,
			useOptimistic: function (e) {
				var t = jo();
				t.memoizedState = t.baseState = e;
				var n = {
					pending: null,
					lanes: 0,
					dispatch: null,
					lastRenderedReducer: null,
					lastRenderedState: null
				};
				return t.queue = n, t = Fs.bind(null, mo, !0, n), n.dispatch = t, [e, t]
			},
			useMemoCache: Fo,
			useCacheRefresh: function () {
				return jo().memoizedState = js.bind(null, mo)
			},
			useEffectEvent: function (e) {
				var t = jo(),
					n = {
						impl: e
					};
				return t.memoizedState = n,
					function () {
						if (2 & kc) throw Error(r(440));
						return n.impl.apply(void 0, arguments)
					}
			}
		},
		$s = {
			readContext: ea,
			use: Ro,
			useCallback: Ss,
			useContext: ea,
			useEffect: ps,
			useImperativeHandle: xs,
			useInsertionEffect: vs,
			useLayoutEffect: ys,
			useMemo: Es,
			useReducer: Vo,
			useRef: cs,
			useState: function () {
				return Vo(Io)
			},
			useDebugValue: ws,
			useDeferredValue: function (e, t) {
				return Ts(Oo(), go.memoizedState, e, t)
			},
			useTransition: function () {
				var e = Vo(Io)[0],
					t = Oo().memoizedState;
				return ["boolean" == typeof e ? e : zo(e), t]
			},
			useSyncExternalStore: Ho,
			useId: Ls,
			useHostTransitionStatus: _s,
			useFormState: as,
			useActionState: as,
			useOptimistic: function (e, t) {
				return Qo(Oo(), 0, e, t)
			},
			useMemoCache: Fo,
			useCacheRefresh: Ds,
			useEffectEvent: gs
		},
		Ws = {
			readContext: ea,
			use: Ro,
			useCallback: Ss,
			useContext: ea,
			useEffect: ps,
			useImperativeHandle: xs,
			useInsertionEffect: vs,
			useLayoutEffect: ys,
			useMemo: Es,
			useReducer: Uo,
			useRef: cs,
			useState: function () {
				return Uo(Io)
			},
			useDebugValue: ws,
			useDeferredValue: function (e, t) {
				var n = Oo();
				return null === go ? ks(n, e, t) : Ts(n, go.memoizedState, e, t)
			},
			useTransition: function () {
				var e = Uo(Io)[0],
					t = Oo().memoizedState;
				return ["boolean" == typeof e ? e : zo(e), t]
			},
			useSyncExternalStore: Ho,
			useId: Ls,
			useHostTransitionStatus: _s,
			useFormState: ls,
			useActionState: ls,
			useOptimistic: function (e, t) {
				var n = Oo();
				return null !== go ? Qo(n, 0, e, t) : (n.baseState = e, [e, n.queue.dispatch])
			},
			useMemoCache: Fo,
			useCacheRefresh: Ds,
			useEffectEvent: gs
		};

	function Zs(e, t, n, r) {
		n = null == (n = n(r, t = e.memoizedState)) ? t : S({}, t, n), e.memoizedState = n, 0 === e.lanes && (e.updateQueue.baseState = n)
	}
	var Ys = {
		enqueueSetState: function (e, t, n) {
			e = e._reactInternals;
			var r = od(),
				i = Ua(r);
			i.payload = t, null != n && (i.callback = n), null !== (t = Ha(e, i, r)) && (ud(t, e, r), $a(t, e, r))
		},
		enqueueReplaceState: function (e, t, n) {
			e = e._reactInternals;
			var r = od(),
				i = Ua(r);
			i.tag = 1, i.payload = t, null != n && (i.callback = n), null !== (t = Ha(e, i, r)) && (ud(t, e, r), $a(t, e, r))
		},
		enqueueForceUpdate: function (e, t) {
			e = e._reactInternals;
			var n = od(),
				r = Ua(n);
			r.tag = 2, null != t && (r.callback = t), null !== (t = Ha(e, r, n)) && (ud(t, e, n), $a(t, e, n))
		}
	};

	function qs(e, t, n, r, i, a, o) {
		return "function" == typeof (e = e.stateNode).shouldComponentUpdate ? e.shouldComponentUpdate(r, a, o) : !t.prototype || !t.prototype.isPureReactComponent || (!gr(n, r) || !gr(i, a))
	}

	function Ks(e, t, n, r) {
		e = t.state, "function" == typeof t.componentWillReceiveProps && t.componentWillReceiveProps(n, r), "function" == typeof t.UNSAFE_componentWillReceiveProps && t.UNSAFE_componentWillReceiveProps(n, r), t.state !== e && Ys.enqueueReplaceState(t, t.state, null)
	}

	function Qs(e, t) {
		var n = t;
		if ("ref" in t)
			for (var r in n = {}, t) "ref" !== r && (n[r] = t[r]);
		if (e = e.defaultProps)
			for (var i in n === t && (n = S({}, n)), e) void 0 === n[i] && (n[i] = e[i]);
		return n
	}

	function Xs(e) {
		qr(e)
	}

	function Gs(e) {
		console.error(e)
	}

	function Js(e) {
		qr(e)
	}

	function el(e, t) {
		try {
			(0, e.onUncaughtError)(t.value, {
				componentStack: t.stack
			})
		} catch (e) {
			setTimeout(function () {
				throw e
			})
		}
	}

	function tl(e, t, n) {
		try {
			(0, e.onCaughtError)(n.value, {
				componentStack: n.stack,
				errorBoundary: 1 === t.tag ? t.stateNode : null
			})
		} catch (e) {
			setTimeout(function () {
				throw e
			})
		}
	}

	function nl(e, t, n) {
		return (n = Ua(n)).tag = 3, n.payload = {
			element: null
		}, n.callback = function () {
			el(e, t)
		}, n
	}

	function rl(e) {
		return (e = Ua(e)).tag = 3, e
	}

	function il(e, t, n, r) {
		var i = n.type.getDerivedStateFromError;
		if ("function" == typeof i) {
			var a = r.value;
			e.payload = function () {
				return i(a)
			}, e.callback = function () {
				tl(t, n, r)
			}
		}
		var o = n.stateNode;
		null !== o && "function" == typeof o.componentDidCatch && (e.callback = function () {
			tl(t, n, r), "function" != typeof i && (null === Yc ? Yc = new Set([this]) : Yc.add(this));
			var e = r.stack;
			this.componentDidCatch(r.value, {
				componentStack: null !== e ? e : ""
			})
		})
	}
	var al = Error(r(461)),
		ol = !1;

	function sl(e, t, n, r) {
		t.child = null === e ? Fa(t, null, n, r) : Ra(t, e.child, n, r)
	}

	function ll(e, t, n, r, i) {
		n = n.render;
		var a = t.ref;
		if ("ref" in r) {
			var o = {};
			for (var s in r) "ref" !== s && (o[s] = r[s])
		} else o = r;
		return Ji(t), r = Co(e, t, n, o, a, i), s = _o(), null === e || ol ? (Di && s && Ni(t), t.flags |= 1, sl(e, t, r, i), t.child) : (Lo(e, t, i), jl(e, t, i))
	}

	function ul(e, t, n, r, i) {
		if (null === e) {
			var a = n.type;
			return "function" != typeof a || si(a) || void 0 !== a.defaultProps || null !== n.compare ? ((e = ci(n.type, null, r, t, t.mode, i)).ref = t.ref, e.return = t, t.child = e) : (t.tag = 15, t.type = a, cl(e, t, a, r, i))
		}
		if (a = e.child, !Ol(e, i)) {
			var o = a.memoizedProps;
			if ((n = null !== (n = n.compare) ? n : gr)(o, r) && e.ref === t.ref) return jl(e, t, i)
		}
		return t.flags |= 1, (e = li(a, r)).ref = t.ref, e.return = t, t.child = e
	}

	function cl(e, t, n, r, i) {
		if (null !== e) {
			var a = e.memoizedProps;
			if (gr(a, r) && e.ref === t.ref) {
				if (ol = !1, t.pendingProps = r = a, !Ol(e, i)) return t.lanes = e.lanes, jl(e, t, i);
				131072 & e.flags && (ol = !0)
			}
		}
		return vl(e, t, n, r, i)
	}

	function dl(e, t, n, r) {
		var i = r.children,
			a = null !== e ? e.memoizedState : null;
		if (null === e && null === t.stateNode && (t.stateNode = {
			_visibility: 1,
			_pendingMarkers: null,
			_retryCache: null,
			_transitions: null
		}), "hidden" === r.mode) {
			if (128 & t.flags) {
				if (a = null !== a ? a.baseLanes | n : n, null !== e) {
					for (r = t.child = e.child, i = 0; null !== r;) i = i | r.lanes | r.childLanes, r = r.sibling;
					r = i & ~a
				} else r = 0, t.child = null;
				return hl(e, t, a, n, r)
			}
			if (!(536870912 & n)) return r = t.lanes = 536870912, hl(e, t, null !== a ? a.baseLanes | n : n, n, r);
			t.memoizedState = {
				baseLanes: 0,
				cachePool: null
			}, null !== e && ba(0, null !== a ? a.cachePool : null), null !== a ? Ja(t, a) : eo(), oo(t)
		} else null !== a ? (ba(0, a.cachePool), Ja(t, a), so(), t.memoizedState = null) : (null !== e && ba(0, null), eo(), so());
		return sl(e, t, i, n), t.child
	}

	function fl(e, t) {
		return null !== e && 22 === e.tag || null !== t.stateNode || (t.stateNode = {
			_visibility: 1,
			_pendingMarkers: null,
			_retryCache: null,
			_transitions: null
		}), t.sibling
	}

	function hl(e, t, n, r, i) {
		var a = ya();
		return a = null === a ? null : {
			parent: oa._currentValue,
			pool: a
		}, t.memoizedState = {
			baseLanes: n,
			cachePool: a
		}, null !== e && ba(0, null), eo(), oo(t), null !== e && Xi(e, t, r, !0), t.childLanes = i, null
	}

	function pl(e, t) {
		return (t = Pl({
			mode: t.mode,
			children: t.children
		}, e.mode)).ref = e.ref, e.child = t, t.return = e, t
	}

	function ml(e, t, n) {
		return Ra(t, e.child, null, n), (e = pl(t, t.pendingProps)).flags |= 2, lo(t), t.memoizedState = null, e
	}

	function gl(e, t) {
		var n = t.ref;
		if (null === n) null !== e && null !== e.ref && (t.flags |= 4194816);
		else {
			if ("function" != typeof n && "object" != typeof n) throw Error(r(284));
			(null === e || e.ref !== n) && (t.flags |= 4194816)
		}
	}

	function vl(e, t, n, r, i) {
		return Ji(t), n = Co(e, t, n, r, void 0, i), r = _o(), null === e || ol ? (Di && r && Ni(t), t.flags |= 1, sl(e, t, n, i), t.child) : (Lo(e, t, i), jl(e, t, i))
	}

	function yl(e, t, n, r, i, a) {
		return Ji(t), t.updateQueue = null, n = Mo(t, r, n, i), No(e), r = _o(), null === e || ol ? (Di && r && Ni(t), t.flags |= 1, sl(e, t, n, a), t.child) : (Lo(e, t, a), jl(e, t, a))
	}

	function bl(e, t, n, r, i) {
		if (Ji(t), null === t.stateNode) {
			var a = ii,
				o = n.contextType;
			"object" == typeof o && null !== o && (a = ea(o)), a = new n(r, a), t.memoizedState = null !== a.state && void 0 !== a.state ? a.state : null, a.updater = Ys, t.stateNode = a, a._reactInternals = t, (a = t.stateNode).props = r, a.state = t.memoizedState, a.refs = {}, Va(t), o = n.contextType, a.context = "object" == typeof o && null !== o ? ea(o) : ii, a.state = t.memoizedState, "function" == typeof (o = n.getDerivedStateFromProps) && (Zs(t, n, o, r), a.state = t.memoizedState), "function" == typeof n.getDerivedStateFromProps || "function" == typeof a.getSnapshotBeforeUpdate || "function" != typeof a.UNSAFE_componentWillMount && "function" != typeof a.componentWillMount || (o = a.state, "function" == typeof a.componentWillMount && a.componentWillMount(), "function" == typeof a.UNSAFE_componentWillMount && a.UNSAFE_componentWillMount(), o !== a.state && Ys.enqueueReplaceState(a, a.state, null), qa(t, r, a, i), Ya(), a.state = t.memoizedState), "function" == typeof a.componentDidMount && (t.flags |= 4194308), r = !0
		} else if (null === e) {
			a = t.stateNode;
			var s = t.memoizedProps,
				l = Qs(n, s);
			a.props = l;
			var u = a.context,
				c = n.contextType;
			o = ii, "object" == typeof c && null !== c && (o = ea(c));
			var d = n.getDerivedStateFromProps;
			c = "function" == typeof d || "function" == typeof a.getSnapshotBeforeUpdate, s = t.pendingProps !== s, c || "function" != typeof a.UNSAFE_componentWillReceiveProps && "function" != typeof a.componentWillReceiveProps || (s || u !== o) && Ks(t, a, r, o), Ia = !1;
			var f = t.memoizedState;
			a.state = f, qa(t, r, a, i), Ya(), u = t.memoizedState, s || f !== u || Ia ? ("function" == typeof d && (Zs(t, n, d, r), u = t.memoizedState), (l = Ia || qs(t, n, l, r, f, u, o)) ? (c || "function" != typeof a.UNSAFE_componentWillMount && "function" != typeof a.componentWillMount || ("function" == typeof a.componentWillMount && a.componentWillMount(), "function" == typeof a.UNSAFE_componentWillMount && a.UNSAFE_componentWillMount()), "function" == typeof a.componentDidMount && (t.flags |= 4194308)) : ("function" == typeof a.componentDidMount && (t.flags |= 4194308), t.memoizedProps = r, t.memoizedState = u), a.props = r, a.state = u, a.context = o, r = l) : ("function" == typeof a.componentDidMount && (t.flags |= 4194308), r = !1)
		} else {
			a = t.stateNode, Ba(e, t), c = Qs(n, o = t.memoizedProps), a.props = c, d = t.pendingProps, f = a.context, u = n.contextType, l = ii, "object" == typeof u && null !== u && (l = ea(u)), (u = "function" == typeof (s = n.getDerivedStateFromProps) || "function" == typeof a.getSnapshotBeforeUpdate) || "function" != typeof a.UNSAFE_componentWillReceiveProps && "function" != typeof a.componentWillReceiveProps || (o !== d || f !== l) && Ks(t, a, r, l), Ia = !1, f = t.memoizedState, a.state = f, qa(t, r, a, i), Ya();
			var h = t.memoizedState;
			o !== d || f !== h || Ia || null !== e && null !== e.dependencies && Gi(e.dependencies) ? ("function" == typeof s && (Zs(t, n, s, r), h = t.memoizedState), (c = Ia || qs(t, n, c, r, f, h, l) || null !== e && null !== e.dependencies && Gi(e.dependencies)) ? (u || "function" != typeof a.UNSAFE_componentWillUpdate && "function" != typeof a.componentWillUpdate || ("function" == typeof a.componentWillUpdate && a.componentWillUpdate(r, h, l), "function" == typeof a.UNSAFE_componentWillUpdate && a.UNSAFE_componentWillUpdate(r, h, l)), "function" == typeof a.componentDidUpdate && (t.flags |= 4), "function" == typeof a.getSnapshotBeforeUpdate && (t.flags |= 1024)) : ("function" != typeof a.componentDidUpdate || o === e.memoizedProps && f === e.memoizedState || (t.flags |= 4), "function" != typeof a.getSnapshotBeforeUpdate || o === e.memoizedProps && f === e.memoizedState || (t.flags |= 1024), t.memoizedProps = r, t.memoizedState = h), a.props = r, a.state = h, a.context = l, r = c) : ("function" != typeof a.componentDidUpdate || o === e.memoizedProps && f === e.memoizedState || (t.flags |= 4), "function" != typeof a.getSnapshotBeforeUpdate || o === e.memoizedProps && f === e.memoizedState || (t.flags |= 1024), r = !1)
		}
		return a = r, gl(e, t), r = !!(128 & t.flags), a || r ? (a = t.stateNode, n = r && "function" != typeof n.getDerivedStateFromError ? null : a.render(), t.flags |= 1, null !== e && r ? (t.child = Ra(t, e.child, null, i), t.child = Ra(t, null, n, i)) : sl(e, t, n, i), t.memoizedState = a.state, e = t.child) : e = jl(e, t, i), e
	}

	function xl(e, t, n, r) {
		return Bi(), t.flags |= 256, sl(e, t, n, r), t.child
	}
	var wl = {
		dehydrated: null,
		treeContext: null,
		retryLane: 0,
		hydrationErrors: null
	};

	function Sl(e) {
		return {
			baseLanes: e,
			cachePool: xa()
		}
	}

	function El(e, t, n) {
		return e = null !== e ? e.childLanes & ~n : 0, t && (e |= Fc), e
	}

	function kl(e, t, n) {
		var i, a = t.pendingProps,
			o = !1,
			s = !!(128 & t.flags);
		if ((i = s) || (i = (null === e || null !== e.memoizedState) && !!(2 & uo.current)), i && (o = !0, t.flags &= -129), i = !!(32 & t.flags), t.flags &= -33, null === e) {
			if (Di) {
				if (o ? io(t) : so(), (e = Li) ? null !== (e = null !== (e = Eh(e, Oi)) && "&" !== e.data ? e : null) && (t.memoizedState = {
					dehydrated: e,
					treeContext: null !== Ei ? {
						id: ki,
						overflow: Ti
					} : null,
					retryLane: 536870912,
					hydrationErrors: null
				}, (n = hi(e)).return = t, t.child = n, _i = t, Li = null) : e = null, null === e) throw Ri(t);
				return Th(e) ? t.lanes = 32 : t.lanes = 536870912, null
			}
			return s = a.children, a = a.fallback, o ? (so(), s = Pl({
				mode: "hidden",
				children: s
			}, o = t.mode), a = di(a, o, n, null), s.return = t, a.return = t, s.sibling = a, t.child = s, (a = t.child).memoizedState = Sl(n), a.childLanes = El(e, i, n), t.memoizedState = wl, fl(null, a)) : (io(t), Tl(t, s))
		}
		var l = e.memoizedState;
		if (null !== l) {
			var u = l.dehydrated;
			if (null !== u) return function (e, t, n, i, a, o, s, l) {
				if (n) return 256 & t.flags ? (io(t), t.flags &= -257, Cl(e, t, l)) : null !== t.memoizedState ? (so(), t.child = e.child, t.flags |= 128, null) : (so(), o = a.fallback, s = t.mode, a = Pl({
					mode: "visible",
					children: a.children
				}, s), o = di(o, s, l, null), o.flags |= 2, a.return = t, o.return = t, a.sibling = o, t.child = a, Ra(t, e.child, null, l), a = t.child, a.memoizedState = Sl(l), a.childLanes = El(e, i, l), t.memoizedState = wl, fl(null, a));
				if (io(t), Th(o)) {
					if (i = o.nextSibling && o.nextSibling.dataset) var u = i.dgst;
					return "" !== (i = u) && ((a = Error(r(419))).stack = "", a.digest = i, Hi({
						value: a,
						source: null,
						stack: null
					})), Cl(e, t, l)
				}
				if (ol || Xi(e, t, l, !1), i = 0 !== (l & e.childLanes), ol || i) {
					if (null !== Xa.current) return Cl(e, t, l);
					if (null !== (i = Tc) && (0 !== (a = qe(i, l)) && a !== s.retryLane)) throw s.retryLane = a, ti(e, a), ud(i, e, a), al;
					return kh(o) || Sd(), Cl(e, t, l)
				}
				return kh(o) ? (t.flags |= 192, t.child = e.child, null) : (e = s.treeContext, Li = Ph(o.nextSibling), _i = t, Di = !0, ji = null, Oi = !1, null !== e && Ai(t, e), t = Tl(t, a.children), t.flags |= 134221824, t)
			}(e, t, s, i, a, u, l, n)
		}
		return o ? (so(), o = a.fallback, s = t.mode, u = (l = e.child).sibling, (a = li(l, {
			mode: "hidden",
			children: a.children
		})).subtreeFlags = 1206910976 & l.subtreeFlags, null !== u ? o = li(u, o) : (o = di(o, s, n, null)).flags |= 2, o.return = t, a.return = t, a.sibling = o, t.child = a, fl(null, a), a = t.child, null === (o = e.child.memoizedState) ? o = Sl(n) : (null !== (s = o.cachePool) ? (l = oa._currentValue, s = s.parent !== l ? {
			parent: l,
			pool: l
		} : s) : s = xa(), o = {
			baseLanes: o.baseLanes | n,
			cachePool: s
		}), a.memoizedState = o, a.childLanes = El(e, i, n), t.memoizedState = wl, fl(e.child, a)) : (io(t), e = (n = e.child).sibling, (n = li(n, {
			mode: "visible",
			children: a.children
		})).return = t, n.sibling = null, null !== e && (null === (i = t.deletions) ? (t.deletions = [e], t.flags |= 16) : i.push(e)), t.child = n, t.memoizedState = null, n)
	}

	function Tl(e, t) {
		return (t = Pl({
			mode: "visible",
			children: t
		}, e.mode)).return = e, e.child = t
	}

	function Pl(e, t) {
		return (e = oi(22, e, null, t)).lanes = 0, e
	}

	function Cl(e, t, n) {
		return Ra(t, e.child, null, n), (e = Tl(t, t.pendingProps.children)).flags |= 2, t.memoizedState = null, e
	}

	function Nl(e, t, n) {
		e.lanes |= t;
		var r = e.alternate;
		null !== r && (r.lanes |= t), Ki(e.return, t, n)
	}

	function Ml(e) {
		for (var t = null; null !== e;) {
			var n = e.alternate;
			null !== n && null === ho(n) && (t = e), e = e.sibling
		}
		return t
	}

	function Al(e, t, n, r, i, a) {
		var o = e.memoizedState;
		null === o ? e.memoizedState = {
			isBackwards: t,
			rendering: null,
			renderingStartTime: 0,
			last: r,
			tail: n,
			tailMode: i,
			treeForkCount: a
		} : (o.isBackwards = t, o.rendering = null, o.renderingStartTime = 0, o.last = r, o.tail = n, o.tailMode = i, o.treeForkCount = a)
	}

	function _l(e) {
		var t = e.child;
		for (e.child = null; null !== t;) {
			var n = t.sibling;
			t.sibling = e.child, e.child = t, t = n
		}
	}

	function Ll(e, t, n) {
		var r = t.pendingProps,
			i = r.revealOrder,
			a = r.tail;
		r = r.children;
		var o = uo.current;
		if (128 & t.flags) return co(0, o), null;
		var s = !!(2 & o);
		if (s ? (o = 1 & o | 2, t.flags |= 128) : o &= 1, co(0, o), "backwards" === i && null !== e ? (_l(e), sl(e, t, r, n), _l(e)) : sl(e, t, r, n), r = Di ? xi : 0, !s && null !== e && 128 & e.flags) e: for (e = t.child; null !== e;) {
			if (13 === e.tag) null !== e.memoizedState && Nl(e, n, t);
			else if (19 === e.tag) Nl(e, n, t);
			else if (null !== e.child) {
				e.child.return = e, e = e.child;
				continue
			}
			if (e === t) break e;
			for (; null === e.sibling;) {
				if (null === e.return || e.return === t) break e;
				e = e.return
			}
			e.sibling.return = e.return, e = e.sibling
		}
		switch (i) {
			case "backwards":
				null === (n = Ml(t.child)) ? (i = t.child, t.child = null) : (i = n.sibling, n.sibling = null, _l(t)), Al(t, !0, i, null, a, r);
				break;
			case "unstable_legacy-backwards":
				for (n = null, i = t.child, t.child = null; null !== i;) {
					if (null !== (e = i.alternate) && null === ho(e)) {
						t.child = i;
						break
					}
					e = i.sibling, i.sibling = n, n = i, i = e
				}
				Al(t, !0, n, null, a, r);
				break;
			case "together":
				Al(t, !1, null, null, void 0, r);
				break;
			case "independent":
				t.memoizedState = null;
				break;
			default:
				null === (n = Ml(t.child)) ? (i = t.child, t.child = null) : (i = n.sibling, n.sibling = null), Al(t, !1, i, n, a, r)
		}
		return t.child
	}

	function Dl(e, t, n) {
		var r = t.pendingProps;
		return Yi(0, t.type, r.value), sl(e, t, r.children, n), t.child
	}

	function jl(e, t, n) {
		if (null !== e && (t.dependencies = e.dependencies), Oc |= t.lanes, 0 === (n & t.childLanes)) {
			if (null === e) return null;
			if (Xi(e, t, n, !1), 0 === (n & t.childLanes)) return null
		}
		if (null !== e && t.child !== e.child) throw Error(r(153));
		if (null !== t.child) {
			for (n = li(e = t.child, e.pendingProps), t.child = n, n.return = t; null !== e.sibling;) e = e.sibling, (n = n.sibling = li(e, e.pendingProps)).return = t;
			n.sibling = null
		}
		return t.child
	}

	function Ol(e, t) {
		return 0 !== (e.lanes & t) || !(null === (e = e.dependencies) || !Gi(e))
	}

	function zl(e, t, n) {
		if (null !== e)
			if (e.memoizedProps !== t.pendingProps) ol = !0;
			else {
				if (!(Ol(e, n) || 128 & t.flags)) return ol = !1,
					function (e, t, n) {
						switch (t.tag) {
							case 3:
								oe(t, t.stateNode.containerInfo), Yi(0, oa, e.memoizedState.cache), Bi();
								break;
							case 27:
							case 5:
								le(t);
								break;
							case 4:
								oe(t, t.stateNode.containerInfo);
								break;
							case 10:
								Yi(0, t.type, t.memoizedProps.value);
								break;
							case 31:
								if (null !== t.memoizedState) return t.flags |= 128, ao(t), null;
								break;
							case 13:
								var r = t.memoizedState;
								if (null !== r) {
									if (null !== r.dehydrated) return io(t), t.flags |= 128, null;
									r = Xi(e, t, n, !1);
									var i = t.child.childLanes;
									return r || 0 !== (n & i) ? kl(e, t, n) : (io(t), null !== (e = jl(e, t, n)) ? e.sibling : null)
								}
								io(t);
								break;
							case 19:
								if (128 & t.flags) return Ll(e, t, n);
								if (i = !!(128 & e.flags), (r = 0 !== (n & t.childLanes)) || (Xi(e, t, n, !1), r = 0 !== (n & t.childLanes)), i) {
									if (r) return Ll(e, t, n);
									t.flags |= 128
								}
								if (null !== (i = t.memoizedState) && (i.rendering = null, i.tail = null, i.lastEffect = null), co(0, uo.current), r) break;
								return null;
							case 22:
								return t.lanes = 0, dl(e, t, n, t.pendingProps);
							case 24:
								Yi(0, oa, e.memoizedState.cache)
						}
						return jl(e, t, n)
					}(e, t, n);
				ol = !!(131072 & e.flags)
			}
		else ol = !1, Di && 1048576 & t.flags && Ci(t, xi, t.index);
		switch (t.lanes = 0, t.tag) {
			case 16:
				e: {
					var i = t.pendingProps;
					if (e = Ca(t.elementType), t.type = e, "function" != typeof e) {
						if (null != e) {
							var a = e.$$typeof;
							if (a === _) {
								t.tag = 11, t = ll(null, t, e, i, n);
								break e
							}
							if (a === j) {
								t.tag = 14, t = ul(null, t, e, i, n);
								break e
							}
							if (a === A) {
								t.tag = 10, t.type = e, t = Dl(null, t, n);
								break e
							}
						}
						throw t = $(e) || e, Error(r(306, t, ""))
					}
					si(e) ? (i = Qs(e, i), t.tag = 1, t = bl(null, t, e, i, n)) : (t.tag = 0, t = vl(null, t, e, i, n))
				}
				return t;
			case 0:
				return vl(e, t, t.type, t.pendingProps, n);
			case 1:
				return bl(e, t, i = t.type, a = Qs(i, t.pendingProps), n);
			case 3:
				e: {
					if (oe(t, t.stateNode.containerInfo), null === e) throw Error(r(387)); i = t.pendingProps;
					var o = t.memoizedState; a = o.element,
						Ba(e, t),
						qa(t, i, null, n);
					var s = t.memoizedState;
					if (i = s.cache, Yi(0, oa, i), i !== o.cache && Qi(t, [oa], n, !0), Ya(), i = s.element, o.isDehydrated) {
						if (o = {
							element: i,
							isDehydrated: !1,
							cache: s.cache
						}, t.updateQueue.baseState = o, t.memoizedState = o, 256 & t.flags) {
							t = xl(e, t, i, n);
							break e
						}
						if (i !== a) {
							Hi(a = gi(Error(r(424)), t)), t = xl(e, t, i, n);
							break e
						}
						if (9 === (e = t.stateNode.containerInfo).nodeType) e = e.body;
						else e = "HTML" === e.nodeName ? e.ownerDocument.body : e;
						for (Li = Ph(e.firstChild), _i = t, Di = !0, ji = null, Oi = !0, n = Fa(t, null, i, n), t.child = n; n;) n.flags = -3 & n.flags | 134221824, n = n.sibling
					} else {
						if (Bi(), i === a) {
							t = jl(e, t, n);
							break e
						}
						sl(e, t, i, n)
					}
					t = t.child
				}
				return t;
			case 26:
				return gl(e, t), null === e ? (n = Ih(t.type, null, t.pendingProps, null)) ? t.memoizedState = n : Di || (t.stateNode = Ff(t.type, t.pendingProps, ie.current, t)) : t.memoizedState = Ih(t.type, e.memoizedProps, t.pendingProps, e.memoizedState), null;
			case 27:
				return le(t), null === e && Di && (i = t.stateNode = Ah(t.type, t.pendingProps, ie.current), _i = t, Oi = !0, a = Li, Yf(t.type) ? (Ch = a, Li = Ph(i.firstChild)) : Li = a), sl(e, t, t.pendingProps.children, n), gl(e, t), null === e && (t.flags |= 4194304), t.child;
			case 5:
				return null === e && Di && ((a = i = Li) && (i = function (e, t, n, r) {
					for (; 1 === e.nodeType;) {
						var i = n;
						if (e.nodeName.toLowerCase() !== t.toLowerCase()) {
							if (!r && ("INPUT" !== e.nodeName || "hidden" !== e.type)) break
						} else if (r) {
							if (!e[st]) switch (t) {
								case "meta":
									if (!e.hasAttribute("itemprop")) break;
									return e;
								case "link":
									if ("stylesheet" === (a = e.getAttribute("rel")) && e.hasAttribute("data-precedence")) break;
									if (a !== i.rel || e.getAttribute("href") !== (null == i.href || "" === i.href ? null : i.href) || e.getAttribute("crossorigin") !== (null == i.crossOrigin ? null : i.crossOrigin) || e.getAttribute("title") !== (null == i.title ? null : i.title)) break;
									return e;
								case "style":
									if (e.hasAttribute("data-precedence")) break;
									return e;
								case "script":
									if (((a = e.getAttribute("src")) !== (null == i.src ? null : i.src) || e.getAttribute("type") !== (null == i.type ? null : i.type) || e.getAttribute("crossorigin") !== (null == i.crossOrigin ? null : i.crossOrigin)) && a && e.hasAttribute("async") && !e.hasAttribute("itemprop")) break;
									return e;
								default:
									return e
							}
						} else {
							if ("input" !== t || "hidden" !== e.type) return e;
							var a = null == i.name ? null : "" + i.name;
							if ("hidden" === i.type && e.getAttribute("name") === a) return e
						}
						if (null === (e = Ph(e.nextSibling))) break
					}
					return null
				}(i, t.type, t.pendingProps, Oi), null !== i ? (t.stateNode = i, _i = t, Li = Ph(i.firstChild), Oi = !1, a = !0) : a = !1), a || Ri(t)), le(t), a = t.type, o = t.pendingProps, s = null !== e ? e.memoizedProps : null, i = o.children, If(a, o) ? i = null : null !== s && If(a, s) && (t.flags |= 32), null !== t.memoizedState && (a = Co(e, t, Ao, null, null, n), up._currentValue = a), gl(e, t), sl(e, t, i, n), t.child;
			case 6:
				return null === e && Di && ((e = n = Li) && (n = function (e, t, n) {
					if ("" === t) return null;
					for (; 3 !== e.nodeType;)
						if ((1 !== e.nodeType || "INPUT" !== e.nodeName || "hidden" !== e.type) && !n || null === (e = Ph(e.nextSibling))) return null;
					return e
				}(n, t.pendingProps, Oi), null !== n ? (t.stateNode = n, _i = t, Li = null, e = !0) : e = !1), e || Ri(t)), null;
			case 13:
				return kl(e, t, n);
			case 4:
				return oe(t, t.stateNode.containerInfo), i = t.pendingProps, null === e ? t.child = Ra(t, null, i, n) : sl(e, t, i, n), t.child;
			case 11:
				return ll(e, t, t.type, t.pendingProps, n);
			case 7:
				return i = t.pendingProps, gl(e, t), sl(e, t, i, n), t.child;
			case 8:
			case 12:
				return sl(e, t, t.pendingProps.children, n), t.child;
			case 10:
				return Dl(e, t, n);
			case 9:
				return a = t.type._context, i = t.pendingProps.children, Ji(t), i = i(a = ea(a)), t.flags |= 1, sl(e, t, i, n), t.child;
			case 14:
				return ul(e, t, t.type, t.pendingProps, n);
			case 15:
				return cl(e, t, t.type, t.pendingProps, n);
			case 19:
				return Ll(e, t, n);
			case 31:
				return function (e, t, n) {
					var i = t.pendingProps,
						a = !!(128 & t.flags);
					if (t.flags &= -129, null === e) {
						if (Di) {
							if ("hidden" === i.mode) return e = pl(t, i), t.lanes = 536870912, e.memoizedState = {
								baseLanes: 0,
								cachePool: null
							}, fl(null, e);
							if (ao(t), (e = Li) ? null !== (e = null !== (e = Eh(e, Oi)) && "&" === e.data ? e : null) && (t.memoizedState = {
								dehydrated: e,
								treeContext: null !== Ei ? {
									id: ki,
									overflow: Ti
								} : null,
								retryLane: 536870912,
								hydrationErrors: null
							}, (n = hi(e)).return = t, t.child = n, _i = t, Li = null) : e = null, null === e) throw Ri(t);
							return t.lanes = 536870912, null
						}
						return pl(t, i)
					}
					var o = e.memoizedState;
					if (null !== o) {
						var s = o.dehydrated;
						if (ao(t), a)
							if (256 & t.flags) t.flags &= -257, t = ml(e, t, n);
							else {
								if (null === t.memoizedState) throw Error(r(558));
								t.child = e.child, t.flags |= 128, t = null
							}
						else if (ol || Xi(e, t, n, !1), a = 0 !== (n & e.childLanes), ol || a) {
							if (null === Xa.current) {
								if (null !== (i = Tc) && 0 !== (s = qe(i, n)) && s !== o.retryLane) throw o.retryLane = s, ti(e, s), ud(i, e, s), al;
								Sd()
							}
							t = ml(e, t, n)
						} else e = o.treeContext, Li = Ph(s.nextSibling), _i = t, Di = !0, ji = null, Oi = !1, null !== e && Ai(t, e), (t = pl(t, i)).flags |= 134221824;
						return t
					}
					return (e = li(e.child, {
						mode: i.mode,
						children: i.children
					})).ref = t.ref, t.child = e, e.return = t, e
				}(e, t, n);
			case 22:
				return dl(e, t, n, t.pendingProps);
			case 24:
				return Ji(t), i = ea(oa), null === e ? (null === (a = ya()) && (a = Tc, o = sa(), a.pooledCache = o, o.refCount++, null !== o && (a.pooledCacheLanes |= n), a = o), t.memoizedState = {
					parent: i,
					cache: a
				}, Va(t), Yi(0, oa, a)) : (0 !== (e.lanes & n) && (Ba(e, t), qa(t, null, null, n), Ya()), a = e.memoizedState, o = t.memoizedState, a.parent !== i ? (a = {
					parent: i,
					cache: i
				}, t.memoizedState = a, 0 === t.lanes && (t.memoizedState = t.updateQueue.baseState = a), Yi(0, oa, i)) : (i = o.cache, Yi(0, oa, i), i !== a.cache && Qi(t, [oa], n, !0))), sl(e, t, t.pendingProps.children, n), t.child;
			case 30:
				return null === t.stateNode && (t.stateNode = {
					autoName: null,
					paired: null,
					clones: null,
					ref: null
				}), null != (i = t.pendingProps).name && "auto" !== i.name ? t.flags |= null === e ? 18882560 : 18874368 : Di && Ni(t), null !== e && e.memoizedProps.name !== i.name ? t.flags |= 4194816 : gl(e, t), sl(e, t, i.children, n), t.child;
			case 29:
				throw t.pendingProps
		}
		throw Error(r(156, t.tag))
	}

	function Rl(e) {
		e.flags |= 4
	}

	function Fl(e, t, n, r, i) {
		var a;
		if ((a = !!(32 & e.mode)) && (a = null === n ? Gh(t, r) : Gh(t, r) && (r.src !== n.src || r.srcSet !== n.srcSet)), a) {
			if (e.flags |= 16777216, (335544128 & i) === i)
				if (e.stateNode.complete) e.flags |= 8192;
				else {
					if (!yd()) throw Na = ka, Sa;
					e.flags |= 8192
				}
		} else e.flags &= -16777217
	}

	function Il(e, t) {
		if ("stylesheet" !== t.type || 4 & t.state.loading) e.flags &= -16777217;
		else if (e.flags |= 16777216, !Jh(t)) {
			if (!yd()) throw Na = ka, Sa;
			e.flags |= 8192
		}
	}

	function Vl(e, t) {
		null !== t && (e.flags |= 4), 16384 & e.flags && (t = 22 !== e.tag ? He() : 536870912, e.lanes |= t, Ic |= t)
	}

	function Bl(e, t) {
		if (!Di) switch (e.tailMode) {
			case "visible":
				break;
			case "collapsed":
				for (var n = e.tail, r = null; null !== n;) null !== n.alternate && (r = n), n = n.sibling;
				null === r ? t || null === e.tail ? e.tail = null : e.tail.sibling = null : r.sibling = null;
				break;
			default:
				for (t = e.tail, n = null; null !== t;) null !== t.alternate && (n = t), t = t.sibling;
				null === n ? e.tail = null : n.sibling = null
		}
	}

	function Ul(e) {
		var t = null !== e.alternate && e.alternate.child === e.child,
			n = 0,
			r = 0;
		if (t)
			for (var i = e.child; null !== i;) n |= i.lanes | i.childLanes, r |= 1206910976 & i.subtreeFlags, r |= 1206910976 & i.flags, i.return = e, i = i.sibling;
		else
			for (i = e.child; null !== i;) n |= i.lanes | i.childLanes, r |= i.subtreeFlags, r |= i.flags, i.return = e, i = i.sibling;
		return e.subtreeFlags |= r, e.childLanes = n, t
	}

	function Hl(e, t, n) {
		var i = t.pendingProps;
		switch (Mi(t), t.tag) {
			case 16:
			case 15:
			case 0:
			case 11:
			case 7:
			case 8:
			case 12:
			case 9:
			case 14:
			case 1:
				return Ul(t), null;
			case 3:
				return n = t.stateNode, i = null, null !== e && (i = e.memoizedState.cache), t.memoizedState.cache !== i && (t.flags |= 2048), qi(oa), se(), n.pendingContext && (n.context = n.pendingContext, n.pendingContext = null), (null === e || null === e.child) && (Vi(t) ? Rl(t) : null === e || e.memoizedState.isDehydrated && !(256 & t.flags) || (t.flags |= 1024, Ui())), Ul(t), null;
			case 26:
				var a = t.type,
					o = t.memoizedState;
				return null === e ? (Rl(t), null !== o ? (Ul(t), Il(t, o)) : (Ul(t), Fl(t, a, null, i, n))) : o ? o !== e.memoizedState ? (Rl(t), Ul(t), Il(t, o)) : (Ul(t), t.flags &= -16777217) : ((e = e.memoizedProps) !== i && Rl(t), Ul(t), Fl(t, a, e, i, n)), null;
			case 27:
				if (ue(t), n = ie.current, a = t.type, null !== e && null != t.stateNode) e.memoizedProps !== i && Rl(t);
				else {
					if (!i) {
						if (null === t.stateNode) throw Error(r(166));
						return Ul(t), t.subtreeFlags &= -33554433, null
					}
					e = ne.current, Vi(t) ? Fi(t) : (e = Ah(a, i, n), t.stateNode = e, Rl(t))
				}
				return Ul(t), t.subtreeFlags &= -33554433, null;
			case 5:
				if (ue(t), a = t.type, null !== e && null != t.stateNode) e.memoizedProps !== i && Rl(t);
				else {
					if (!i) {
						if (null === t.stateNode) throw Error(r(166));
						return Ul(t), t.subtreeFlags &= -33554433, null
					}
					if (o = ne.current, Vi(t)) Fi(t);
					else {
						var s = Of(ie.current);
						switch (o) {
							case 1:
								o = s.createElementNS("http://www.w3.org/2000/svg", a);
								break;
							case 2:
								o = s.createElementNS("http://www.w3.org/1998/Math/MathML", a);
								break;
							default:
								switch (a) {
									case "svg":
										o = s.createElementNS("http://www.w3.org/2000/svg", a);
										break;
									case "math":
										o = s.createElementNS("http://www.w3.org/1998/Math/MathML", a);
										break;
									case "script":
										(o = s.createElement("div")).innerHTML = "<script><\/script>", o = o.removeChild(o.firstChild);
										break;
									case "select":
										o = "string" == typeof i.is ? s.createElement("select", {
											is: i.is
										}) : s.createElement("select"), i.multiple ? o.multiple = !0 : i.size && (o.size = i.size);
										break;
									default:
										o = "string" == typeof i.is ? s.createElement(a, {
											is: i.is
										}) : s.createElement(a)
								}
						}
						o[et] = t, o[tt] = i;
						e: for (s = t.child; null !== s;) {
							if (5 === s.tag || 6 === s.tag) o.appendChild(s.stateNode);
							else if (4 !== s.tag && 27 !== s.tag && null !== s.child) {
								s.child.return = s, s = s.child;
								continue
							}
							if (s === t) break e;
							for (; null === s.sibling;) {
								if (null === s.return || s.return === t) break e;
								s = s.return
							}
							s.sibling.return = s.return, s = s.sibling
						}
						t.stateNode = o;
						e: switch (Af(o, a, i), a) {
							case "button":
							case "input":
							case "select":
							case "textarea":
								i = !!i.autoFocus;
								break e;
							case "img":
								i = !0;
								break e;
							default:
								i = !1
						}
						i && Rl(t)
					}
				}
				return Ul(t), t.subtreeFlags &= -33554433, Fl(t, t.type, null === e ? null : e.memoizedProps, t.pendingProps, n), null;
			case 6:
				if (e && null != t.stateNode) e.memoizedProps !== i && Rl(t);
				else {
					if ("string" != typeof i && null === t.stateNode) throw Error(r(166));
					if (e = ie.current, Vi(t)) {
						if (e = t.stateNode, n = t.memoizedProps, i = null, null !== (a = _i)) switch (a.tag) {
							case 27:
							case 5:
								i = a.memoizedProps
						}
						e[et] = t, (e = !!(e.nodeValue === n || null !== i && !0 === i.suppressHydrationWarning || Cf(e.nodeValue, n))) || Ri(t, !0)
					} else (e = Of(e).createTextNode(i))[et] = t, t.stateNode = e
				}
				return Ul(t), null;
			case 31:
				if (n = t.memoizedState, null === e || null !== e.memoizedState) {
					if (i = Vi(t), null !== n) {
						if (null === e) {
							if (!i) throw Error(r(318));
							if (!(e = null !== (e = t.memoizedState) ? e.dehydrated : null)) throw Error(r(557));
							e[et] = t
						} else Bi(), !(128 & t.flags) && (t.memoizedState = null), t.flags |= 4;
						Ul(t), e = !1
					} else n = Ui(), null !== e && null !== e.memoizedState && (e.memoizedState.hydrationErrors = n), e = !0;
					if (!e) return 256 & t.flags ? (lo(t), t) : (lo(t), null);
					if (128 & t.flags) throw Error(r(558))
				}
				return Ul(t), null;
			case 13:
				if (i = t.memoizedState, null === e || null !== e.memoizedState && null !== e.memoizedState.dehydrated) {
					if (a = Vi(t), null !== i && null !== i.dehydrated) {
						if (null === e) {
							if (!a) throw Error(r(318));
							if (!(a = null !== (a = t.memoizedState) ? a.dehydrated : null)) throw Error(r(317));
							a[et] = t
						} else Bi(), !(128 & t.flags) && (t.memoizedState = null), t.flags |= 4;
						Ul(t), a = !1
					} else a = Ui(), null !== e && null !== e.memoizedState && (e.memoizedState.hydrationErrors = a), a = !0;
					if (!a) return 256 & t.flags ? (lo(t), t) : (lo(t), null)
				}
				return lo(t), 128 & t.flags ? (t.lanes = n, t) : (n = null !== i, e = null !== e && null !== e.memoizedState, n && (a = null, null !== (i = t.child).alternate && null !== i.alternate.memoizedState && null !== i.alternate.memoizedState.cachePool && (a = i.alternate.memoizedState.cachePool.pool), o = null, null !== i.memoizedState && null !== i.memoizedState.cachePool && (o = i.memoizedState.cachePool.pool), o !== a && (i.flags |= 2048)), n !== e && n && (t.child.flags |= 8192), Vl(t, t.updateQueue), Ul(t), null);
			case 4:
				return se(), null === e && vf(t.stateNode.containerInfo), t.flags |= 67108864, Ul(t), null;
			case 10:
				return qi(t.type), Ul(t), null;
			case 19:
				if (fo(t), null === (i = t.memoizedState)) return Ul(t), null;
				if (a = !!(128 & t.flags), null === (o = i.rendering))
					if (a) Bl(i, !1);
					else {
						if (0 !== jc || null !== e && 128 & e.flags)
							for (e = t.child; null !== e;) {
								if (null !== (o = ho(e))) {
									for (t.flags |= 128, Bl(i, !1), e = o.updateQueue, t.updateQueue = e, Vl(t, e), t.subtreeFlags = 0, e = n, n = t.child; null !== n;) ui(n, e), n = n.sibling;
									return co(0, 1 & uo.current | 2), Di && Pi(t, i.treeForkCount), t.child
								}
								e = e.sibling
							}
						null !== i.tail && xe() > Wc && (t.flags |= 128, a = !0, Bl(i, !1), t.lanes = 4194304)
					}
				else {
					if (!a)
						if (null !== (e = ho(o))) {
							if (t.flags |= 128, a = !0, e = e.updateQueue, t.updateQueue = e, Vl(t, e), Bl(i, !0), null === i.tail && "collapsed" !== i.tailMode && "visible" !== i.tailMode && !o.alternate && !Di) return Ul(t), null
						} else 2 * xe() - i.renderingStartTime > Wc && 536870912 !== n && (t.flags |= 128, a = !0, Bl(i, !1), t.lanes = 4194304);
					i.isBackwards ? (o.sibling = t.child, t.child = o) : (null !== (e = i.last) ? e.sibling = o : t.child = o, i.last = o)
				}
				if (null !== i.tail) {
					e: {
						for (n = e = i.tail; null !== n;) {
							if (null !== n.alternate) {
								n = !1;
								break e
							}
							n = n.sibling
						}
						n = !0
					}
					return i.rendering = e, i.tail = e.sibling, i.renderingStartTime = xe(), e.sibling = null, o = uo.current, o = a ? 1 & o | 2 : 1 & o, "visible" === i.tailMode || "collapsed" === i.tailMode || !n || Di ? co(0, o) : (n = o, J(no, t), J(uo, n), null === ro && (ro = t)), Di && Pi(t, i.treeForkCount), e
				}
				return Ul(t), null;
			case 22:
			case 23:
				return lo(t), to(), i = null !== t.memoizedState, null !== e ? null !== e.memoizedState !== i && (t.flags |= 8192) : i && (t.flags |= 8192), i ? !!(536870912 & n) && !(128 & t.flags) && (Ul(t), 6 & t.subtreeFlags && (t.flags |= 8192)) : Ul(t), null !== (n = t.updateQueue) && Vl(t, n.retryQueue), n = null, null !== e && null !== e.memoizedState && null !== e.memoizedState.cachePool && (n = e.memoizedState.cachePool.pool), i = null, null !== t.memoizedState && null !== t.memoizedState.cachePool && (i = t.memoizedState.cachePool.pool), i !== n && (t.flags |= 2048), null !== e && G(va), null;
			case 24:
				return n = null, null !== e && (n = e.memoizedState.cache), t.memoizedState.cache !== n && (t.flags |= 2048), qi(oa), Ul(t), null;
			case 25:
				return null;
			case 30:
				return t.flags |= 33554432, Ul(t), null
		}
		throw Error(r(156, t.tag))
	}

	function $l(e, t) {
		switch (Mi(t), t.tag) {
			case 1:
				return 65536 & (e = t.flags) ? (t.flags = -65537 & e | 128, t) : null;
			case 3:
				return qi(oa), se(), 65536 & (e = t.flags) && !(128 & e) ? (t.flags = -65537 & e | 128, t) : null;
			case 26:
			case 27:
			case 5:
				return ue(t), null;
			case 31:
				if (null !== t.memoizedState) {
					if (lo(t), null === t.alternate) throw Error(r(340));
					Bi()
				}
				return 65536 & (e = t.flags) ? (t.flags = -65537 & e | 128, t) : null;
			case 13:
				if (lo(t), null !== (e = t.memoizedState) && null !== e.dehydrated) {
					if (null === t.alternate) throw Error(r(340));
					Bi()
				}
				return 65536 & (e = t.flags) ? (t.flags = -65537 & e | 128, t) : null;
			case 19:
				return fo(t), 65536 & (e = t.flags) ? (t.flags = -65537 & e | 128, null !== (e = t.memoizedState) && (e.rendering = null, e.tail = null), t.flags |= 4, t) : null;
			case 4:
				return se(), null;
			case 10:
				return qi(t.type), null;
			case 22:
			case 23:
				return lo(t), to(), null !== e && G(va), 65536 & (e = t.flags) ? (t.flags = -65537 & e | 128, t) : null;
			case 24:
				return qi(oa), null;
			default:
				return null
		}
	}

	function Wl(e, t) {
		switch (Mi(t), t.tag) {
			case 3:
				qi(oa), se();
				break;
			case 26:
			case 27:
			case 5:
				ue(t);
				break;
			case 4:
				se();
				break;
			case 31:
				null !== t.memoizedState && lo(t);
				break;
			case 13:
				lo(t);
				break;
			case 19:
				fo(t);
				break;
			case 10:
				qi(t.type);
				break;
			case 22:
			case 23:
				lo(t), to(), null !== e && G(va);
				break;
			case 24:
				qi(oa)
		}
	}

	function Zl(e, t) {
		try {
			var n = t.updateQueue,
				r = null !== n ? n.lastEffect : null;
			if (null !== r) {
				var i = r.next;
				n = i;
				do {
					if ((n.tag & e) === e) {
						r = void 0;
						var a = n.create,
							o = n.inst;
						r = a(), o.destroy = r
					}
					n = n.next
				} while (n !== i)
			}
		} catch (e) {
			Bd(t, t.return, e)
		}
	}

	function Yl(e, t, n) {
		try {
			var r = t.updateQueue,
				i = null !== r ? r.lastEffect : null;
			if (null !== i) {
				var a = i.next;
				r = a;
				do {
					if ((r.tag & e) === e) {
						var o = r.inst,
							s = o.destroy;
						if (void 0 !== s) {
							o.destroy = void 0, i = t;
							var l = n,
								u = s;
							try {
								u()
							} catch (e) {
								Bd(i, l, e)
							}
						}
					}
					r = r.next
				} while (r !== a)
			}
		} catch (e) {
			Bd(t, t.return, e)
		}
	}

	function ql(e) {
		var t = e.updateQueue;
		if (null !== t) {
			var n = e.stateNode;
			try {
				Qa(t, n)
			} catch (t) {
				Bd(e, e.return, t)
			}
		}
	}

	function Kl(e, t, n) {
		n.props = Qs(e.type, e.memoizedProps), n.state = e.memoizedState;
		try {
			n.componentWillUnmount()
		} catch (n) {
			Bd(e, t, n)
		}
	}

	function Ql(e, t) {
		try {
			var n = e.ref;
			if (null !== n) {
				switch (e.tag) {
					case 26:
					case 27:
					case 5:
						var r = e.stateNode;
						break;
					case 30:
						var i = e.stateNode,
							a = Wr(e.memoizedProps, i);
						(null === i.ref || i.ref.name !== a) && (i.ref = th(a)), r = i.ref;
						break;
					case 7:
						if (null === e.stateNode) {
							var o = new nh(e);
							c(e.child, !1, yh, o, void 0, void 0), e.stateNode = o
						}
						r = e.stateNode;
						break;
					default:
						r = e.stateNode
				}
				"function" == typeof n ? e.refCleanup = n(r) : n.current = r
			}
		} catch (n) {
			Bd(e, t, n)
		}
	}

	function Xl(e, t) {
		var n = e.ref,
			r = e.refCleanup;
		if (null !== n)
			if ("function" == typeof r) try {
				r()
			} catch (n) {
				Bd(e, t, n)
			} finally {
				e.refCleanup = null, null != (e = e.alternate) && (e.refCleanup = null)
			} else if ("function" == typeof n) try {
				n(null)
			} catch (n) {
				Bd(e, t, n)
			} else n.current = null
	}

	function Gl(e, t) {
		if ((5 === e.tag || 27 === e.tag || 6 === e.tag) && null === e.alternate && null !== t)
			for (var n = 0; n < t.length; n++) xh(e.stateNode, t[n])
	}

	function Jl(e) {
		for (var t = e.return; null !== t && (nu(t) && xh(e.stateNode, t.stateNode), !tu(t));) t = t.return
	}

	function eu(e) {
		for (var t = e.return; null !== t && (nu(t) && wh(e.stateNode, t.stateNode), !tu(t));) t = t.return
	}

	function tu(e) {
		return 5 === e.tag || 3 === e.tag || 27 === e.tag
	}

	function nu(e) {
		return e && 7 === e.tag && null !== e.stateNode
	}

	function ru(e) {
		var t = e.type,
			n = e.memoizedProps,
			r = e.stateNode;
		try {
			e: switch (t) {
				case "button":
				case "input":
				case "select":
				case "textarea":
					n.autoFocus && r.focus();
					break e;
				case "img":
					n.src ? r.src = n.src : n.srcSet && (r.srcset = n.srcSet)
			}
		}
		catch (t) {
			Bd(e, e.return, t)
		}
	}

	function iu(e, t, n) {
		try {
			var i = e.stateNode;
			(function (e, t, n, i) {
				switch (t) {
					case "div":
					case "span":
					case "svg":
					case "path":
					case "a":
					case "g":
					case "p":
					case "li":
						break;
					case "input":
						var a = null,
							o = null,
							s = null,
							l = null,
							u = null,
							c = null,
							d = null;
						for (p in n) {
							var f = n[p];
							if (n.hasOwnProperty(p) && null != f) switch (p) {
								case "checked":
								case "value":
									break;
								case "defaultValue":
									u = f;
								default:
									i.hasOwnProperty(p) || Nf(e, t, p, null, i, f)
							}
						}
						for (var h in i) {
							var p = i[h];
							if (f = n[h], i.hasOwnProperty(h) && (null != p || null != f)) switch (h) {
								case "type":
									p !== f && (Et = !0), o = p;
									break;
								case "name":
									p !== f && (Et = !0), a = p;
									break;
								case "checked":
									p !== f && (Et = !0), c = p;
									break;
								case "defaultChecked":
									p !== f && (Et = !0), d = p;
									break;
								case "value":
									p !== f && (Et = !0), s = p;
									break;
								case "defaultValue":
									p !== f && (Et = !0), l = p;
									break;
								case "children":
								case "dangerouslySetInnerHTML":
									if (null != p) throw Error(r(137, t));
									break;
								default:
									p !== f && Nf(e, t, h, p, i, f)
							}
						}
						return void jt(e, s, l, u, c, d, o, a);
					case "select":
						for (o in p = s = l = h = null, n)
							if (u = n[o], n.hasOwnProperty(o) && null != u) switch (o) {
								case "value":
									break;
								case "multiple":
									p = u;
								default:
									i.hasOwnProperty(o) || Nf(e, t, o, null, i, u)
							}
						for (a in i)
							if (o = i[a], u = n[a], i.hasOwnProperty(a) && (null != o || null != u)) switch (a) {
								case "value":
									o !== u && (Et = !0), h = o;
									break;
								case "defaultValue":
									o !== u && (Et = !0), l = o;
									break;
								case "multiple":
									o !== u && (Et = !0), s = o;
								default:
									o !== u && Nf(e, t, a, o, i, u)
							}
						return t = l, n = s, i = p, void (null != h ? Rt(e, !!n, h, !1) : !!i != !!n && (null != t ? Rt(e, !!n, t, !0) : Rt(e, !!n, n ? [] : "", !1)));
					case "textarea":
						for (l in p = h = null, n)
							if (a = n[l], n.hasOwnProperty(l) && null != a && !i.hasOwnProperty(l)) switch (l) {
								case "value":
								case "children":
									break;
								default:
									Nf(e, t, l, null, i, a)
							}
						for (s in i)
							if (a = i[s], o = n[s], i.hasOwnProperty(s) && (null != a || null != o)) switch (s) {
								case "value":
									a !== o && (Et = !0), h = a;
									break;
								case "defaultValue":
									a !== o && (Et = !0), p = a;
									break;
								case "children":
									break;
								case "dangerouslySetInnerHTML":
									if (null != a) throw Error(r(91));
									break;
								default:
									a !== o && Nf(e, t, s, a, i, o)
							}
						return void Ft(e, h, p);
					case "option":
						for (var m in n)
							if (h = n[m], n.hasOwnProperty(m) && null != h && !i.hasOwnProperty(m))
								if ("selected" === m) e.selected = !1;
								else Nf(e, t, m, null, i, h);
						for (u in i)
							if (h = i[u], p = n[u], i.hasOwnProperty(u) && h !== p && (null != h || null != p))
								if ("selected" === u) h !== p && (Et = !0), e.selected = h && "function" != typeof h && "symbol" != typeof h;
								else Nf(e, t, u, h, i, p);
						return;
					case "img":
					case "link":
					case "area":
					case "base":
					case "br":
					case "col":
					case "embed":
					case "hr":
					case "keygen":
					case "meta":
					case "param":
					case "source":
					case "track":
					case "wbr":
					case "menuitem":
						for (var g in n) h = n[g], n.hasOwnProperty(g) && null != h && !i.hasOwnProperty(g) && Nf(e, t, g, null, i, h);
						for (c in i)
							if (h = i[c], p = n[c], i.hasOwnProperty(c) && h !== p && (null != h || null != p)) switch (c) {
								case "children":
								case "dangerouslySetInnerHTML":
									if (null != h) throw Error(r(137, t));
									break;
								default:
									Nf(e, t, c, h, i, p)
							}
						return;
					default:
						if ($t(t)) {
							for (var v in n) h = n[v], n.hasOwnProperty(v) && void 0 !== h && !i.hasOwnProperty(v) && Mf(e, t, v, void 0, i, h);
							for (d in i) h = i[d], p = n[d], !i.hasOwnProperty(d) || h === p || void 0 === h && void 0 === p || Mf(e, t, d, h, i, p);
							return
						}
				}
				for (var y in n) h = n[y], n.hasOwnProperty(y) && null != h && !i.hasOwnProperty(y) && Nf(e, t, y, null, i, h);
				for (f in i) h = i[f], p = n[f], !i.hasOwnProperty(f) || h === p || null == h && null == p || Nf(e, t, f, h, i, p)
			})(i, e.type, n, t), i[tt] = t
		} catch (t) {
			Bd(e, e.return, t)
		}
	}

	function au(e) {
		return 5 === e.tag || 3 === e.tag || 26 === e.tag || 27 === e.tag && Yf(e.type) || 4 === e.tag
	}

	function ou(e) {
		e: for (; ;) {
			for (; null === e.sibling;) {
				if (null === e.return || au(e.return)) return null;
				e = e.return
			}
			for (e.sibling.return = e.return, e = e.sibling; 5 !== e.tag && 6 !== e.tag && 18 !== e.tag;) {
				if (27 === e.tag && Yf(e.type) || 2 & e.flags || null === e.child || 4 === e.tag) continue e;
				e.child.return = e, e = e.child
			}
			if (!(2 & e.flags)) return e.stateNode
		}
	}

	function su(e, t, n, r) {
		var i = e.tag;
		if (5 === i || 6 === i) i = e.stateNode, t ? (9 === n.nodeType ? n.body : "HTML" === n.nodeName ? n.ownerDocument.body : n).insertBefore(i, t) : ((t = 9 === n.nodeType ? n.body : "HTML" === n.nodeName ? n.ownerDocument.body : n).appendChild(i), null != (n = n._reactRootContainer) || null !== t.onclick || (t.onclick = qt)), Gl(e, r), Et = !0;
		else if (4 !== i && (27 === i && (Gl(e, r), r = null, Yf(e.type) && (n = e.stateNode, t = null)), null !== (e = e.child)))
			for (su(e, t, n, r), e = e.sibling; null !== e;) su(e, t, n, r), e = e.sibling
	}

	function lu(e, t, n, r) {
		var i = e.tag;
		if (5 === i || 6 === i) i = e.stateNode, t ? n.insertBefore(i, t) : n.appendChild(i), Gl(e, r), Et = !0;
		else if (4 !== i && (27 === i && (Gl(e, r), r = null, Yf(e.type) && (n = e.stateNode)), null !== (e = e.child)))
			for (lu(e, t, n, r), e = e.sibling; null !== e;) lu(e, t, n, r), e = e.sibling
	}

	function uu(e) {
		var t = e.stateNode,
			n = e.memoizedProps;
		try {
			for (var r = e.type, i = t.attributes; i.length;) t.removeAttributeNode(i[0]);
			Af(t, r, n), t[et] = e, t[tt] = n
		} catch (t) {
			Bd(e, e.return, t)
		}
	}
	var cu = !1,
		du = null;

	function fu(e) {
		(30 === e.tag || 33554432 & e.subtreeFlags) && (cu = !0)
	}
	var hu = null;

	function pu() {
		var e = hu;
		return hu = null, e
	}
	var mu = 0;

	function gu(e, t, n, r, i) {
		return mu = 0, vu(e.child, t, n, r, i)
	}

	function vu(e, t, n, r, i) {
		for (var a = !1; null !== e;) {
			if (5 === e.tag) {
				var o = e.stateNode;
				if (null !== r) {
					var s = Gf(o);
					r.push(s), s.view && (a = !0)
				} else a || Gf(o).view && (a = !0);
				cu = !0, Qf(o, 0 === mu ? t : t + "_" + mu, n), mu++
			} else (22 !== e.tag || null === e.memoizedState) && (30 === e.tag && i || vu(e.child, t, n, r, i) && (a = !0));
			e = e.sibling
		}
		return a
	}

	function yu(e, t) {
		for (; null !== e;) 5 === e.tag ? Xf(e.stateNode, e.memoizedProps) : (22 !== e.tag || null === e.memoizedState) && (30 === e.tag && t || yu(e.child, t)), e = e.sibling
	}

	function bu(e) {
		if (18874368 & e.subtreeFlags)
			for (e = e.child; null !== e;) {
				if ((22 !== e.tag || null === e.memoizedState) && (bu(e), 30 === e.tag && 18874368 & e.flags && e.stateNode.paired)) {
					var t = e.memoizedProps;
					if (null == t.name || "auto" === t.name) throw Error(r(544));
					var n = t.name;
					"none" !== (t = Yr(t.default, t.share)) && (gu(e, n, t, null, !1) || yu(e.child, !1))
				}
				e = e.sibling
			}
	}

	function xu(e, t) {
		if (30 === e.tag) {
			var n = e.stateNode,
				r = e.memoizedProps,
				i = Wr(r, n),
				a = Yr(r.default, n.paired ? r.share : r.enter);
			"none" !== a ? gu(e, i, a, null, !1) ? (bu(e), n.paired || t || ld(e, r.onEnter)) : yu(e.child, !1) : bu(e)
		} else if (33554432 & e.subtreeFlags)
			for (e = e.child; null !== e;) xu(e, t), e = e.sibling;
		else bu(e)
	}

	function wu(e) {
		if (null !== du && 0 !== du.size) {
			var t = du;
			if (18874368 & e.subtreeFlags)
				for (e = e.child; null !== e;) {
					if (22 !== e.tag || null === e.memoizedState) {
						if (30 === e.tag && 18874368 & e.flags) {
							var n = e.memoizedProps,
								r = n.name;
							if (null != r && "auto" !== r) {
								var i = t.get(r);
								if (void 0 !== i) {
									var a = Yr(n.default, n.share);
									if ("none" !== a && (gu(e, r, a, null, !1) ? (a = e.stateNode, i.paired = a, a.paired = i, ld(e, n.onShare)) : yu(e.child, !1)), t.delete(r), 0 === t.size) break
								}
							}
						}
						wu(e)
					}
					e = e.sibling
				}
		}
	}

	function Su(e) {
		if (30 === e.tag) {
			var t = e.memoizedProps,
				n = Wr(t, e.stateNode),
				r = null !== du ? du.get(n) : void 0,
				i = Yr(t.default, void 0 !== r ? t.share : t.exit);
			"none" !== i && (gu(e, n, i, null, !1) ? void 0 !== r ? (i = e.stateNode, r.paired = i, i.paired = r, du.delete(n), ld(e, t.onShare)) : ld(e, t.onExit) : yu(e.child, !1)), null !== du && wu(e)
		} else if (33554432 & e.subtreeFlags)
			for (e = e.child; null !== e;) Su(e), e = e.sibling;
		else null !== du && wu(e)
	}

	function Eu(e) {
		for (e = e.child; null !== e;) {
			if (30 === e.tag) {
				var t = e.memoizedProps,
					n = Wr(t, e.stateNode);
				t = Yr(t.default, t.update), e.flags &= -5, "none" !== t && gu(e, n, t, e.memoizedState = [], !1)
			} else 33554432 & e.subtreeFlags && Eu(e);
			e = e.sibling
		}
	}

	function ku(e) {
		if (18874368 & e.subtreeFlags)
			for (e = e.child; null !== e;) {
				if (22 !== e.tag || null === e.memoizedState) {
					if (30 === e.tag && 18874368 & e.flags) {
						var t = e.stateNode;
						null !== t.paired && (t.paired = null, yu(e.child, !1))
					}
					ku(e)
				}
				e = e.sibling
			}
	}

	function Tu(e) {
		if (30 === e.tag) e.stateNode.paired = null, yu(e.child, !1), ku(e);
		else if (33554432 & e.subtreeFlags)
			for (e = e.child; null !== e;) Tu(e), e = e.sibling;
		else ku(e)
	}

	function Pu(e) {
		for (e = e.child; null !== e;) 30 === e.tag ? yu(e.child, !1) : !!(33554432 & e.subtreeFlags) && Pu(e), e = e.sibling
	}

	function Cu(e, t, n, r, i, a, o) {
		for (var s = !1; null !== t;) {
			if (5 === t.tag) {
				var l = t.stateNode;
				if (null !== a && mu < a.length) {
					var u, c = a[mu],
						d = Gf(l);
					if ((c.view || d.view) && (s = !0), u = !(4 & e.flags))
						if (d.clip) u = !0;
						else {
							u = c.rect;
							var f = d.rect;
							u = u.y !== f.y || u.x !== f.x || u.height !== f.height || u.width !== f.width
						} u && (e.flags |= 4), d.abs ? d = !c.abs : (c = c.rect, d = d.rect, d = c.height !== d.height || c.width !== d.width), d && (e.flags |= 32)
				} else e.flags |= 32;
				!!(4 & e.flags) && Qf(l, 0 === mu ? n : n + "_" + mu, i), s && !!(4 & e.flags) || (null === hu && (hu = []), hu.push(l, 0 === mu ? r : r + "_" + mu, t.memoizedProps)), mu++
			} else (22 !== t.tag || null === t.memoizedState) && (30 === t.tag && o ? e.flags |= 32 & t.flags : Cu(e, t.child, n, r, i, a, o) && (s = !0));
			t = t.sibling
		}
		return s
	}

	function Nu(e, t) {
		for (e = e.child; null !== e;) {
			if (30 === e.tag) {
				var n, r = e.memoizedProps,
					i = e.stateNode,
					a = Wr(r, i),
					o = Yr(r.default, r.update);
				n = e.memoizedState, e.memoizedState = null, i = e;
				var s = e.child;
				mu = 0, a = Cu(i, s, a, a, o, n, !1), 4 & e.flags && a && ld(e, r.onUpdate)
			} else 33554432 & e.subtreeFlags && Nu(e);
			e = e.sibling
		}
	}
	var Mu = !1,
		Au = !1,
		_u = !1,
		Lu = !1,
		Du = "function" == typeof WeakSet ? WeakSet : Set,
		ju = null,
		Ou = !1,
		zu = !1,
		Ru = !1,
		Fu = !1;

	function Iu(e) {
		for (; null !== ju;) {
			var t = ju,
				n = e,
				i = t.alternate,
				a = t.flags;
			switch (t.tag) {
				case 0:
				case 11:
				case 15:
				case 5:
				case 26:
				case 27:
				case 6:
				case 4:
				case 17:
					break;
				case 1:
					if (1024 & a && null !== i) {
						n = void 0, a = i.memoizedProps, i = i.memoizedState;
						var o = t.stateNode;
						try {
							var s = Qs(t.type, a);
							n = o.getSnapshotBeforeUpdate(s, i), o.__reactInternalSnapshotBeforeUpdate = n
						} catch (e) {
							Bd(t, t.return, e)
						}
					}
					break;
				case 3:
					if (1024 & a)
						if (9 === (n = (i = t.stateNode.containerInfo).nodeType)) Sh(i);
						else if (1 === n) switch (i.nodeName) {
							case "HEAD":
							case "HTML":
							case "BODY":
								Sh(i);
								break;
							default:
								i.textContent = ""
						}
					break;
				case 30:
					n && null !== i && (n = Wr(i.memoizedProps, i.stateNode), "none" !== (a = Yr((a = t.memoizedProps).default, a.update)) && gu(i, n, a, i.memoizedState = [], !0));
					break;
				default:
					if (1024 & a) throw Error(r(163))
			}
			if (null !== (i = t.sibling)) {
				i.return = t.return, ju = i;
				break
			}
			ju = t.return
		}
	}

	function Vu(e, t, n) {
		var r = n.flags;
		switch (n.tag) {
			case 0:
			case 11:
			case 15:
				ac(e, n), 4 & r && Zl(5, n);
				break;
			case 1:
				if (ac(e, n), 4 & r)
					if (e = n.stateNode, null === t) try {
						e.componentDidMount()
					} catch (e) {
						Bd(n, n.return, e)
					} else {
						var i = Qs(n.type, t.memoizedProps);
						t = t.memoizedState;
						try {
							e.componentDidUpdate(i, t, e.__reactInternalSnapshotBeforeUpdate)
						} catch (e) {
							Bd(n, n.return, e)
						}
					}
				64 & r && ql(n), 512 & r && Ql(n, n.return);
				break;
			case 3:
				if (ac(e, n), 64 & r && null !== (e = n.updateQueue)) {
					if (t = null, null !== n.child) switch (n.child.tag) {
						case 27:
						case 5:
						case 1:
							t = n.child.stateNode
					}
					try {
						Qa(e, t)
					} catch (e) {
						Bd(n, n.return, e)
					}
				}
				break;
			case 27:
				null === t && 4 & r && uu(n);
			case 26:
			case 5:
				ac(e, n), null === t && 4 & r && ru(n), 512 & r && Ql(n, n.return);
				break;
			case 12:
				ac(e, n);
				break;
			case 31:
				ac(e, n), 4 & r && Ku(e, n);
				break;
			case 13:
				ac(e, n), 4 & r && Qu(e, n), 64 & r && (null !== (e = n.memoizedState) && (null !== (e = e.dehydrated) && function (e, t) {
					var n = e.ownerDocument;
					if ("$~" === e.data) e._reactRetry = t;
					else if ("$?" !== e.data || "loading" !== n.readyState) t();
					else {
						var r = function () {
							t(), n.removeEventListener("DOMContentLoaded", r)
						};
						n.addEventListener("DOMContentLoaded", r), e._reactRetry = r
					}
				}(e, n = Wd.bind(null, n))));
				break;
			case 22:
				if (!(r = null !== n.memoizedState || Mu)) {
					var a = null !== t && null !== t.memoizedState || Au;
					t = Mu, i = Au, Mu = r, (Au = a) && !i ? (r = 2, !!(8772 & n.subtreeFlags) && (r |= 1), sc(e, n, r)) : ac(e, n), Mu = t, Au = i
				}
				break;
			case 30:
				ac(e, n), 512 & r && Ql(n, n.return);
				break;
			case 7:
				512 & r && Ql(n, n.return);
			default:
				ac(e, n)
		}
	}

	function Bu(e, t) {
		for (e = e.child; null !== e;) Uu(e, t), e = e.sibling
	}

	function Uu(e, t) {
		switch (e.tag) {
			case 5:
			case 26:
				try {
					var n = e.stateNode;
					if (t) {
						var r = n.style;
						"function" == typeof r.setProperty ? r.setProperty("display", "none", "important") : r.display = "none"
					} else {
						var i = e.stateNode,
							a = e.memoizedProps.style,
							o = null != a && a.hasOwnProperty("display") ? a.display : null;
						i.style.display = null == o || "boolean" == typeof o ? "" : ("" + o).trim()
					}
				} catch (t) {
					Bd(e, e.return, t)
				}
				Hu(e, t);
				break;
			case 6:
				try {
					e.stateNode.nodeValue = t ? "" : e.memoizedProps, Et = !0
				} catch (t) {
					Bd(e, e.return, t)
				}
				break;
			case 18:
				try {
					var s = e.stateNode;
					t ? Kf(s, !0) : Kf(e.stateNode, !1)
				} catch (t) {
					Bd(e, e.return, t)
				}
				break;
			case 22:
			case 23:
				null === e.memoizedState && Bu(e, t);
				break;
			default:
				Bu(e, t)
		}
	}

	function Hu(e, t) {
		if (67108864 & e.subtreeFlags)
			for (e = e.child; null !== e;) {
				e: {
					var n = e,
						r = t;
					switch (n.tag) {
						case 4:
							Uu(n, r);
							break e;
						case 22:
							null === n.memoizedState && Hu(n, r);
							break e;
						default:
							Hu(n, r)
					}
				}
				e = e.sibling
			}
	}

	function $u(e) {
		var t = e.alternate;
		null !== t && (e.alternate = null, $u(t)), e.child = null, e.deletions = null, e.sibling = null, 5 === e.tag && (null !== (t = e.stateNode) && ut(t)), e.stateNode = null, e.return = null, e.dependencies = null, e.memoizedProps = null, e.memoizedState = null, e.pendingProps = null, e.stateNode = null, e.updateQueue = null
	}
	var Wu = null,
		Zu = !1;

	function Yu(e, t, n) {
		for (n = n.child; null !== n;) qu(e, t, n), n = n.sibling
	}

	function qu(e, t, n) {
		if (Ae && "function" == typeof Ae.onCommitFiberUnmount) try {
			Ae.onCommitFiberUnmount(Me, n)
		} catch { }
		switch (n.tag) {
			case 26:
				Au || Xl(n, t), Yu(e, t, n), n.memoizedState ? n.memoizedState.count-- : n.stateNode && !Au && (n = n.stateNode).parentNode.removeChild(n);
				break;
			case 27:
				Au || Xl(n, t), eu(n);
				var r = Wu,
					i = Zu;
				Yf(n.type) && (Wu = n.stateNode, Zu = !1), Yu(e, t, n), _h(n.stateNode, n.type, n.memoizedProps), Wu = r, Zu = i;
				break;
			case 5:
				Au || Xl(n, t), eu(n);
			case 6:
				if (6 === n.tag && eu(n), r = Wu, i = Zu, Wu = null, Yu(e, t, n), Zu = i, null !== (Wu = r))
					if (Zu) try {
						(9 === Wu.nodeType ? Wu.body : "HTML" === Wu.nodeName ? Wu.ownerDocument.body : Wu).removeChild(n.stateNode), Et = !0
					} catch (e) {
						Bd(n, t, e)
					} else try {
						Wu.removeChild(n.stateNode), Et = !0
					} catch (e) {
						Bd(n, t, e)
					}
				break;
			case 18:
				null !== Wu && (Zu ? (qf(9 === (e = Wu).nodeType ? e.body : "HTML" === e.nodeName ? e.ownerDocument.body : e, n.stateNode), Hp(e)) : qf(Wu, n.stateNode));
				break;
			case 4:
				r = Wu, i = Zu, Wu = n.stateNode.containerInfo, Zu = !0, Yu(e, t, n), Wu = r, Zu = i;
				break;
			case 0:
			case 11:
			case 14:
			case 15:
				Yl(2, n, t), Au || Yl(4, n, t), Yu(e, t, n);
				break;
			case 1:
				Au || (Xl(n, t), "function" == typeof (r = n.stateNode).componentWillUnmount && Kl(n, t, r)), Yu(e, t, n);
				break;
			case 21:
				Yu(e, t, n);
				break;
			case 22:
				Au = (r = Au) || null !== n.memoizedState, Yu(e, t, n), Au = r;
				break;
			case 30:
				Xl(n, t), Yu(e, t, n);
				break;
			case 7:
				Au || Xl(n, t), Yu(e, t, n);
				break;
			default:
				Yu(e, t, n)
		}
	}

	function Ku(e, t) {
		if (null === t.memoizedState && (null !== (e = t.alternate) && null !== (e = e.memoizedState))) {
			e = e.dehydrated;
			try {
				Hp(e)
			} catch (e) {
				Bd(t, t.return, e)
			}
		}
	}

	function Qu(e, t) {
		if (null === t.memoizedState && (null !== (e = t.alternate) && (null !== (e = e.memoizedState) && null !== (e = e.dehydrated)))) try {
			Hp(e)
		} catch (e) {
			Bd(t, t.return, e)
		}
	}

	function Xu(e, t) {
		var n = function (e) {
			switch (e.tag) {
				case 31:
				case 13:
				case 19:
					var t = e.stateNode;
					return null === t && (t = e.stateNode = new Du), t;
				case 22:
					return null === (t = (e = e.stateNode)._retryCache) && (t = e._retryCache = new Du), t;
				default:
					throw Error(r(435, e.tag))
			}
		}(e);
		t.forEach(function (t) {
			if (!n.has(t)) {
				n.add(t);
				var r = Zd.bind(null, e, t);
				t.then(r, r)
			}
		})
	}

	function Gu(e, t, n) {
		var i = t.deletions;
		if (null !== i)
			for (var a = 0; a < i.length; a++) {
				var o = i[a],
					s = e,
					l = t,
					u = l;
				e: for (; null !== u;) {
					switch (u.tag) {
						case 27:
							if (Yf(u.type)) {
								Wu = u.stateNode, Zu = !1;
								break e
							}
							break;
						case 5:
							Wu = u.stateNode, Zu = !1;
							break e;
						case 3:
						case 4:
							Wu = u.stateNode.containerInfo, Zu = !0;
							break e
					}
					u = u.return
				}
				if (null === Wu) throw Error(r(160));
				qu(s, l, o), Wu = null, Zu = !1, null !== (s = o.alternate) && (s.return = null), o.return = null
			}
		if (13886 & t.subtreeFlags)
			for (t = t.child; null !== t;) ec(t, e, n), t = t.sibling
	}
	var Ju = null;

	function ec(e, t, n) {
		var i = e.alternate,
			a = e.flags;
		switch (e.tag) {
			case 0:
			case 11:
			case 14:
			case 15:
				if (4 & a && null !== (i = null !== (i = e.updateQueue) ? i.events : null))
					for (var o = 0; o < i.length; o++) {
						var s = i[o];
						s.ref.impl = s.nextImpl
					}
				Gu(t, e, n), tc(e), 4 & a && (Yl(3, e, e.return), Zl(3, e), Yl(5, e, e.return));
				break;
			case 1:
				Gu(t, e, n), tc(e), 512 & a && (Au || null === i || Xl(i, i.return)), 64 & a && Mu && (null !== (e = e.updateQueue) && (null !== (t = e.callbacks) && (n = e.shared.hiddenCallbacks, e.shared.hiddenCallbacks = null === n ? t : n.concat(t))));
				break;
			case 26:
				if (o = Ju, Gu(t, e, n), tc(e), 512 & a && (Au || null === i || Xl(i, i.return)), 4 & a)
					if (a = null !== i ? i.memoizedState : null, n = e.memoizedState, null === i)
						if (null === n)
							if (null === e.stateNode)
								if (Mu) e.stateNode = Ff(e.type, e.memoizedProps, t.containerInfo, e);
								else {
									e: {
										t = e.type,
											n = e.memoizedProps,
											a = o.ownerDocument || o; t: switch (t) {
												case "title":
													(!(i = a.getElementsByTagName("title")[0]) || i[st] || i[et] || "http://www.w3.org/2000/svg" === i.namespaceURI || i.hasAttribute("itemprop")) && (i = a.createElement(t), a.head.insertBefore(i, a.querySelector("head > title"))), Af(i, t, n), i[et] = e, pt(i), t = i;
													break e;
												case "link":
													if (o = Qh("link", "href", a).get(t + (n.href || "")))
														for (s = 0; s < o.length; s++)
															if ((i = o[s]).getAttribute("href") === (null == n.href || "" === n.href ? null : n.href) && i.getAttribute("rel") === (null == n.rel ? null : n.rel) && i.getAttribute("title") === (null == n.title ? null : n.title) && i.getAttribute("crossorigin") === (null == n.crossOrigin ? null : n.crossOrigin)) {
																o.splice(s, 1);
																break t
															} Af(i = a.createElement(t), t, n), a.head.appendChild(i);
													break;
												case "meta":
													if (o = Qh("meta", "content", a).get(t + (n.content || "")))
														for (s = 0; s < o.length; s++)
															if ((i = o[s]).getAttribute("content") === (null == n.content ? null : "" + n.content) && i.getAttribute("name") === (null == n.name ? null : n.name) && i.getAttribute("property") === (null == n.property ? null : n.property) && i.getAttribute("http-equiv") === (null == n.httpEquiv ? null : n.httpEquiv) && i.getAttribute("charset") === (null == n.charSet ? null : n.charSet)) {
																o.splice(s, 1);
																break t
															} Af(i = a.createElement(t), t, n), a.head.appendChild(i);
													break;
												default:
													throw Error(r(468, t))
											}
										i[et] = e,
											pt(i),
											t = i
									}
									e.stateNode = t
								}
							else Mu || Xh(o, e.type, e.stateNode);
						else e.stateNode = Wh(o, n, e.memoizedProps);
					else a !== n ? (null === a ? null === (t = i.stateNode) || Au || t.parentNode.removeChild(t) : a.count--, null === n ? Mu || Xh(o, e.type, e.stateNode) : Wh(o, n, e.memoizedProps)) : null === n && null !== e.stateNode && iu(e, e.memoizedProps, i.memoizedProps);
				break;
			case 27:
				Gu(t, e, n), tc(e), 512 & a && (Au || null === i || Xl(i, i.return)), null !== i && 4 & a && iu(e, e.memoizedProps, i.memoizedProps);
				break;
			case 5:
				if (o = _u, _u = !1, Gu(t, e, n), _u = o, tc(e), 512 & a && (Au || null === i || Xl(i, i.return)), 32 & e.flags) {
					t = e.stateNode;
					try {
						Vt(t, ""), Et = !0
					} catch (t) {
						Bd(e, e.return, t)
					}
				}
				4 & a && null != e.stateNode && iu(e, t = e.memoizedProps, null !== i ? i.memoizedProps : t), 1024 & a && (Lu = !0);
				break;
			case 6:
				if (Gu(t, e, n), tc(e), 4 & a) {
					if (null === e.stateNode) throw Error(r(162));
					t = e.memoizedProps, n = e.stateNode;
					try {
						n.nodeValue = t, Et = !0
					} catch (t) {
						Bd(e, e.return, t)
					}
				}
				break;
			case 3:
				if (Et = !1, Kh = null, o = Ju, Ju = Oh(t.containerInfo), Gu(t, e, n), Ju = o, tc(e), 4 & a && null !== i && i.memoizedState.isDehydrated) try {
					Hp(t.containerInfo)
				} catch (t) {
					Bd(e, e.return, t)
				}
				Lu && (Lu = !1, nc(e)), Et = !1;
				break;
			case 4:
				a = _u, _u = Mu, i = kt(), o = Ju, Ju = Oh(e.stateNode.containerInfo), Gu(t, e, n), tc(e), Ju = o, Et && zu && (Ru = !0), Et = i, _u = a;
				break;
			case 12:
				Gu(t, e, n), tc(e);
				break;
			case 31:
				Gu(t, e, n), tc(e), 4 & a && (null !== (t = e.updateQueue) && (e.updateQueue = null, Xu(e, t)));
				break;
			case 13:
				Gu(t, e, n), tc(e), 8192 & e.child.flags && null !== e.memoizedState != (null !== i && null !== i.memoizedState) && (Hc = xe()), 4 & a && (null !== (t = e.updateQueue) && (e.updateQueue = null, Xu(e, t)));
				break;
			case 22:
				o = null !== e.memoizedState, s = null !== i && null !== i.memoizedState;
				var l = Mu,
					u = Au,
					c = _u;
				Mu = l || o, _u = c || o, Au = u || s, Gu(t, e, n), Au = u, _u = c, Mu = l, tc(e), 8192 & a && ((t = e.stateNode)._visibility = o ? -2 & t._visibility : 1 | t._visibility, !o || null === i || s || Mu || Au || (n = Mu, i = Au, Mu = o || Mu, Au = t = s || Au, oc(e, 2), Mu = n, Au = i), !o && _u || Bu(e, o)), 4 & a && (null !== (t = e.updateQueue) && (null !== (n = t.retryQueue) && (t.retryQueue = null, Xu(e, n))));
				break;
			case 19:
				Gu(t, e, n), tc(e), 4 & a && (null !== (t = e.updateQueue) && (e.updateQueue = null, Xu(e, t)));
				break;
			case 30:
				512 & a && (Au || null === i || Xl(i, i.return)), a = kt(), o = zu, s = (335544064 & n) === n, l = e.memoizedProps, zu = s && "none" !== Yr(l.default, l.update), Gu(t, e, n), tc(e), s && null !== i && Et && (e.flags |= 4), zu = o, Et = a;
				break;
			case 21:
				break;
			case 7:
				512 & a && (Au || null === i || Xl(i, i.return)), i && null !== i.stateNode && (i.stateNode._fragmentFiber = e);
			default:
				Gu(t, e, n), tc(e)
		}
	}

	function tc(e) {
		var t = e.flags;
		if (2 & t) {
			try {
				for (var n, i = e.return; null !== i;) {
					if (au(i)) {
						n = i;
						break
					}
					i = i.return
				}
				i = null;
				for (var a = e.return; null !== a;) {
					if (nu(a)) {
						var o = a.stateNode;
						null === i ? i = [o] : i.push(o)
					}
					if (tu(a)) break;
					a = a.return
				}
				var s = i;
				if (null == n) throw Error(r(160));
				switch (n.tag) {
					case 27:
						var l = n.stateNode;
						lu(e, ou(e), l, s);
						break;
					case 5:
						var u = n.stateNode;
						32 & n.flags && (Vt(u, ""), n.flags &= -33), lu(e, ou(e), u, s);
						break;
					case 3:
					case 4:
						var c = n.stateNode.containerInfo;
						su(e, ou(e), c, s);
						break;
					default:
						throw Error(r(161))
				}
			} catch (t) {
				Bd(e, e.return, t)
			}
			e.flags &= -3
		}
		4096 & t && (e.flags &= -4097)
	}

	function nc(e) {
		if (1024 & e.subtreeFlags)
			for (e = e.child; null !== e;) {
				var t = e;
				nc(t), 5 === t.tag && 1024 & t.flags && (t = t.stateNode, yp = !0, t.reset(), yp = !1), e = e.sibling
			}
	}

	function rc(e, t) {
		if (9270 & t.subtreeFlags)
			for (t = t.child; null !== t;) ic(t, e), t = t.sibling;
		else Nu(t)
	}

	function ic(e, t) {
		var n = e.alternate;
		if (null === n) xu(e, !1);
		else switch (e.tag) {
			case 3:
				if (Fu = Ou = !1, pu(), rc(t, e), !Ou && !Ru) {
					if (null !== (e = hu))
						for (var r = 0; r < e.length; r += 3) {
							n = e[r];
							var i = e[r + 1];
							Xf(n, e[r + 2]), null !== (n = n.ownerDocument.documentElement) && n.animate({
								opacity: [0, 0],
								pointerEvents: ["none", "none"]
							}, {
								duration: 0,
								fill: "forwards",
								pseudoElement: "::view-transition-group(" + i + ")"
							})
						}
					null !== (e = 9 === (e = t.containerInfo).nodeType ? e.documentElement : e.ownerDocument.documentElement) && "" === e.style.viewTransitionName && (e.style.viewTransitionName = "none", e.animate({
						opacity: [0, 0],
						pointerEvents: ["none", "none"]
					}, {
						duration: 0,
						fill: "forwards",
						pseudoElement: "::view-transition-group(root)"
					}), e.animate({
						width: [0, 0],
						height: [0, 0]
					}, {
						duration: 0,
						fill: "forwards",
						pseudoElement: "::view-transition"
					})), Fu = !0
				}
				hu = null;
				break;
			case 5:
			default:
				rc(t, e);
				break;
			case 4:
				r = Ou, Ou = !1, rc(t, e), Ou && (Ru = !0), Ou = r;
				break;
			case 22:
				null === e.memoizedState && (null !== n.memoizedState ? xu(e, !1) : rc(t, e));
				break;
			case 30:
				r = Ou, i = pu(), Ou = !1, rc(t, e), Ou && (e.flags |= 4);
				var a = e.memoizedProps,
					o = e.stateNode;
				t = Wr(a, o), o = Wr(n.memoizedProps, o);
				var s = Yr(a.default, a.update);
				"none" === s ? t = !1 : (a = n.memoizedState, n.memoizedState = null, n = e.child, mu = 0, t = Cu(e, n, t, o, s, a, !0), mu !== (null === a ? 0 : a.length) && (e.flags |= 32)), 4 & e.flags && t ? (ld(e, e.memoizedProps.onUpdate), hu = i) : null !== i && (i.push.apply(i, hu), hu = i), Ou = !!(32 & e.flags) || r
		}
	}

	function ac(e, t) {
		if (8772 & t.subtreeFlags)
			for (t = t.child; null !== t;) Vu(e, t.alternate, t), t = t.sibling
	}

	function oc(e, t) {
		for (e = e.child; null !== e;) {
			var n = e,
				r = t;
			switch (n.tag) {
				case 0:
				case 11:
				case 14:
				case 15:
					Yl(4, n, n.return), oc(n, r);
					break;
				case 1:
					Xl(n, n.return);
					var i = n.stateNode;
					"function" == typeof i.componentWillUnmount && Kl(n, n.return, i), oc(n, r);
					break;
				case 27:
					2 & r && _h(n.stateNode, n.type, n.memoizedProps);
				case 5:
					Xl(n, n.return), 5 !== n.tag && 27 !== n.tag || eu(n), oc(n, r);
					break;
				case 6:
					eu(n);
					break;
				case 26:
					Xl(n, n.return), i = n.stateNode, null !== n.memoizedState || null === i || Au || i.parentNode.removeChild(i), oc(n, r);
					break;
				case 22:
					null === n.memoizedState && oc(n, r);
					break;
				case 30:
					Xl(n, n.return), oc(n, r);
					break;
				case 7:
					Xl(n, n.return);
				default:
					oc(n, r)
			}
			e = e.sibling
		}
	}

	function sc(e, t, n) {
		for (n = 8772 & t.subtreeFlags ? n : -2 & n, t = t.child; null !== t;) {
			var r = t.alternate,
				i = e,
				a = t,
				o = a.flags,
				s = !!(1 & n);
			switch (a.tag) {
				case 0:
				case 11:
				case 15:
					sc(i, a, n), Zl(4, a);
					break;
				case 1:
					if (sc(i, a, n), "function" == typeof (i = (r = a).stateNode).componentDidMount) try {
						i.componentDidMount()
					} catch (e) {
						Bd(r, r.return, e)
					}
					if (null !== (i = (r = a).updateQueue)) {
						var l = r.stateNode;
						try {
							var u = i.shared.hiddenCallbacks;
							if (null !== u)
								for (i.shared.hiddenCallbacks = null, i = 0; i < u.length; i++) Ka(u[i], l)
						} catch (e) {
							Bd(r, r.return, e)
						}
					}
					s && 64 & o && ql(a), Ql(a, a.return);
					break;
				case 27:
					2 & n && uu(a);
				case 5:
					5 !== a.tag && 27 !== a.tag || Jl(a), sc(i, a, n), s && null === r && 4 & o && ru(a), Ql(a, a.return);
					break;
				case 6:
					Jl(a);
					break;
				case 26:
					l = a.stateNode, null !== a.memoizedState || null === l || Mu || Xh(Oh(l.ownerDocument), a.type, l), sc(i, a, n), s && null === r && 4 & o && ru(a), Ql(a, a.return);
					break;
				case 12:
					sc(i, a, n);
					break;
				case 31:
					sc(i, a, n), s && 4 & o && Ku(i, a);
					break;
				case 13:
					sc(i, a, n), s && 4 & o && Qu(i, a);
					break;
				case 22:
					null === a.memoizedState && sc(i, a, n), Ql(a, a.return);
					break;
				case 30:
					sc(i, a, n), Ql(a, a.return);
					break;
				case 7:
					Ql(a, a.return);
				default:
					sc(i, a, n)
			}
			t = t.sibling
		}
	}

	function lc(e, t) {
		var n = null;
		null !== e && null !== e.memoizedState && null !== e.memoizedState.cachePool && (n = e.memoizedState.cachePool.pool), e = null, null !== t.memoizedState && null !== t.memoizedState.cachePool && (e = t.memoizedState.cachePool.pool), e !== n && (null != e && e.refCount++, null != n && la(n))
	}

	function uc(e, t) {
		e = null, null !== t.alternate && (e = t.alternate.memoizedState.cache), (t = t.memoizedState.cache) !== e && (t.refCount++, null != e && la(e))
	}

	function cc(e, t, n, r) {
		var i = (335544064 & n) === n;
		if (t.subtreeFlags & (i ? 10262 : 10256))
			for (t = t.child; null !== t;) dc(e, t, n, r), t = t.sibling;
		else i && Pu(t)
	}

	function dc(e, t, n, r) {
		var i = (335544064 & n) === n;
		i && null === t.alternate && null !== t.return && null !== t.return.alternate && Tu(t);
		var a = t.flags;
		switch (t.tag) {
			case 0:
			case 11:
			case 15:
				cc(e, t, n, r), 2048 & a && Zl(9, t);
				break;
			case 1:
			case 31:
			case 13:
			default:
				cc(e, t, n, r);
				break;
			case 3:
				cc(e, t, n, r), i && Fu && ("root" === (e = 9 === (e = e.containerInfo).nodeType ? e.body : "HTML" === e.nodeName ? e.ownerDocument.body : e).style.viewTransitionName && (e.style.viewTransitionName = ""), null !== (e = e.ownerDocument.documentElement) && "none" === e.style.viewTransitionName && (e.style.viewTransitionName = "")), 2048 & a && (a = null, null !== t.alternate && (a = t.alternate.memoizedState.cache), (t = t.memoizedState.cache) !== a && (t.refCount++, null != a && la(a)));
				break;
			case 12:
				if (2048 & a) {
					cc(e, t, n, r), a = t.stateNode;
					try {
						var o = t.memoizedProps,
							s = o.id,
							l = o.onPostCommit;
						"function" == typeof l && l(s, null === t.alternate ? "mount" : "update", a.passiveEffectDuration, -0)
					} catch (e) {
						Bd(t, t.return, e)
					}
				} else cc(e, t, n, r);
				break;
			case 23:
				break;
			case 22:
				o = t.stateNode, s = t.alternate, null !== t.memoizedState ? (i && null !== s && null === s.memoizedState && Tu(s), 2 & o._visibility ? cc(e, t, n, r) : hc(e, t)) : (i && null !== s && null !== s.memoizedState && Tu(t), 2 & o._visibility ? cc(e, t, n, r) : (o._visibility |= 2, fc(e, t, n, r, !!(10256 & t.subtreeFlags) || !1))), 2048 & a && lc(s, t);
				break;
			case 24:
				cc(e, t, n, r), 2048 & a && uc(t.alternate, t);
				break;
			case 30:
				i && (null !== (a = t.alternate) && (yu(a.child, !0), yu(t.child, !0))), cc(e, t, n, r)
		}
	}

	function fc(e, t, n, r, i) {
		for (i = i && (!!(10256 & t.subtreeFlags) || !1), t = t.child; null !== t;) {
			var a = e,
				o = t,
				s = n,
				l = r,
				u = o.flags;
			switch (o.tag) {
				case 0:
				case 11:
				case 15:
					fc(a, o, s, l, i), Zl(8, o);
					break;
				case 23:
					break;
				case 22:
					var c = o.stateNode;
					null !== o.memoizedState ? 2 & c._visibility ? fc(a, o, s, l, i) : hc(a, o) : (c._visibility |= 2, fc(a, o, s, l, i)), i && 2048 & u && lc(o.alternate, o);
					break;
				case 24:
					fc(a, o, s, l, i), i && 2048 & u && uc(o.alternate, o);
					break;
				default:
					fc(a, o, s, l, i)
			}
			t = t.sibling
		}
	}

	function hc(e, t) {
		if (10256 & t.subtreeFlags)
			for (t = t.child; null !== t;) {
				var n = e,
					r = t,
					i = r.flags;
				switch (r.tag) {
					case 22:
						hc(n, r), 2048 & i && lc(r.alternate, r);
						break;
					case 24:
						hc(n, r), 2048 & i && uc(r.alternate, r);
						break;
					default:
						hc(n, r)
				}
				t = t.sibling
			}
	}
	var pc = 8192;

	function mc(e, t, n) {
		if (e.subtreeFlags & pc)
			for (e = e.child; null !== e;) gc(e, t, n), e = e.sibling
	}

	function gc(e, t, n) {
		switch (e.tag) {
			case 26:
				mc(e, t, n), e.flags & pc && (null !== e.memoizedState ? function (e, t, n, r) {
					if (!("stylesheet" !== n.type || "string" == typeof r.media && !1 === matchMedia(r.media).matches || 4 & n.state.loading)) {
						if (null === n.instance) {
							var i = Vh(r.href),
								a = t.querySelector(Bh(i));
							if (a) return null !== (t = a._p) && "object" == typeof t && "function" == typeof t.then && (e.count++, e = ip.bind(e), t.then(e, e)), n.state.loading |= 4, n.instance = a, void pt(a);
							a = t.ownerDocument || t, r = Uh(r), (i = Dh.get(i)) && Yh(r, i), pt(a = a.createElement("link"));
							var o = a;
							o._p = new Promise(function (e, t) {
								o.onload = e, o.onerror = t
							}), Af(a, "link", r), n.instance = a
						}
						null === e.stylesheets && (e.stylesheets = new Map), e.stylesheets.set(n, t), (t = n.state.preload) && !(3 & n.state.loading) && (e.count++, n = ip.bind(e), t.addEventListener("load", n), t.addEventListener("error", n))
					}
				}(n, Ju, e.memoizedState, e.memoizedProps) : (e = e.stateNode, (335544128 & t) === t && tp(n, e)));
				break;
			case 5:
				mc(e, t, n), e.flags & pc && (e = e.stateNode, (335544128 & t) === t && tp(n, e));
				break;
			case 3:
			case 4:
				var r = Ju;
				Ju = Oh(e.stateNode.containerInfo), mc(e, t, n), Ju = r;
				break;
			case 22:
				null === e.memoizedState && (null !== (r = e.alternate) && null !== r.memoizedState ? (r = pc, pc = 16777216, mc(e, t, n), pc = r) : mc(e, t, n));
				break;
			case 30:
				if (0 !== (e.flags & pc) && (null != (r = e.memoizedProps.name) && "auto" !== r)) {
					var i = e.stateNode;
					i.paired = null, null === du && (du = new Map), du.set(r, i)
				}
				mc(e, t, n);
				break;
			default:
				mc(e, t, n)
		}
	}

	function vc(e) {
		var t = e.alternate;
		if (null !== t && null !== (e = t.child)) {
			t.child = null;
			do {
				t = e.sibling, e.sibling = null, e = t
			} while (null !== e)
		}
	}

	function yc(e) {
		var t = e.deletions;
		if (16 & e.flags) {
			if (null !== t)
				for (var n = 0; n < t.length; n++) {
					var r = t[n];
					ju = r, wc(r, e)
				}
			vc(e)
		}
		if (10256 & e.subtreeFlags)
			for (e = e.child; null !== e;) bc(e), e = e.sibling
	}

	function bc(e) {
		switch (e.tag) {
			case 0:
			case 11:
			case 15:
				yc(e), 2048 & e.flags && Yl(9, e, e.return);
				break;
			case 3:
			case 12:
			default:
				yc(e);
				break;
			case 22:
				var t = e.stateNode;
				null !== e.memoizedState && 2 & t._visibility && (null === e.return || 13 !== e.return.tag) ? (t._visibility &= -3, xc(e)) : yc(e)
		}
	}

	function xc(e) {
		var t = e.deletions;
		if (16 & e.flags) {
			if (null !== t)
				for (var n = 0; n < t.length; n++) {
					var r = t[n];
					ju = r, wc(r, e)
				}
			vc(e)
		}
		for (e = e.child; null !== e;) {
			switch ((t = e).tag) {
				case 0:
				case 11:
				case 15:
					Yl(8, t, t.return), xc(t);
					break;
				case 22:
					2 & (n = t.stateNode)._visibility && (n._visibility &= -3, xc(t));
					break;
				default:
					xc(t)
			}
			e = e.sibling
		}
	}

	function wc(e, t) {
		for (; null !== ju;) {
			var n = ju;
			switch (n.tag) {
				case 0:
				case 11:
				case 15:
					Yl(8, n, t);
					break;
				case 23:
				case 22:
					if (null !== n.memoizedState && null !== n.memoizedState.cachePool) {
						var r = n.memoizedState.cachePool.pool;
						null != r && r.refCount++
					}
					break;
				case 24:
					la(n.memoizedState.cache)
			}
			if (null !== (r = n.child)) r.return = n, ju = r;
			else e: for (n = e; null !== ju;) {
				var i = (r = ju).sibling,
					a = r.return;
				if ($u(r), r === n) {
					ju = null;
					break e
				}
				if (null !== i) {
					i.return = a, ju = i;
					break e
				}
				ju = a
			}
		}
	}
	var Sc = {
		getCacheForType: function (e) {
			var t = ea(oa),
				n = t.data.get(e);
			return void 0 === n && (n = e(), t.data.set(e, n)), n
		},
		cacheSignal: function () {
			return ea(oa).controller.signal
		}
	},
		Ec = "function" == typeof WeakMap ? WeakMap : Map,
		kc = 0,
		Tc = null,
		Pc = null,
		Cc = 0,
		Nc = 0,
		Mc = null,
		Ac = !1,
		_c = !1,
		Lc = !1,
		Dc = 0,
		jc = 0,
		Oc = 0,
		zc = 0,
		Rc = 0,
		Fc = 0,
		Ic = 0,
		Vc = null,
		Bc = null,
		Uc = !1,
		Hc = 0,
		$c = 0,
		Wc = 1 / 0,
		Zc = null,
		Yc = null,
		qc = 0,
		Kc = null,
		Qc = null,
		Xc = 0,
		Gc = 0,
		Jc = null,
		ed = null,
		td = null,
		nd = null,
		rd = null,
		id = 0,
		ad = null;

	function od() {
		return 2 & kc && 0 !== Cc ? Cc & -Cc : null !== Z.T ? sf() : Xe()
	}

	function sd() {
		if (0 === Fc)
			if (536870912 & Cc && !Di) Fc = 536870912;
			else {
				var e = ze;
				!(3932160 & (ze <<= 1)) && (ze = 262144), Fc = e
			} return null !== (e = no.current) && (e.flags |= 32), Fc
	}

	function ld(e, t) {
		if (null != t) {
			var n = e.stateNode,
				r = n.ref;
			null === r && (r = n.ref = th(Wr(e.memoizedProps, n))), null === nd && (nd = []), nd.push(t.bind(null, r))
		}
	}

	function ud(e, t, n) {
		(e === Tc && (2 === Nc || 9 === Nc) || null !== e.cancelPendingCommit) && (gd(e, 0), hd(e, Cc, Fc, !1)), We(e, n), (!(2 & kc) || e !== Tc) && (e === Tc && (!(2 & kc) && (zc |= n), 4 === jc && hd(e, Cc, Fc, !1)), Jd(e))
	}

	function cd(e, t, n) {
		if (6 & kc) throw Error(r(327));
		for (var i = !n && !(127 & t) && 0 === (t & e.expiredLanes) || Ve(e, t), a = i ? function (e, t) {
			var n = kc;
			kc |= 2;
			var i = bd(),
				a = wd();
			Tc !== e || Cc !== t ? (Zc = null, Wc = xe() + 500, gd(e, t)) : _c = Ve(e, t);
			e: for (; ;) try {
				if (0 !== Nc && null !== Pc) {
					t = Pc;
					var o = Mc;
					t: switch (Nc) {
						case 1:
							Nc = 0, Mc = null, Nd(e, t, o, 1);
							break;
						case 2:
						case 9:
							if (Ta(o)) {
								Nc = 0, Mc = null, Cd(t);
								break
							}
							t = function () {
								2 !== Nc && 9 !== Nc || Tc !== e || (Nc = 7), Jd(e)
							}, o.then(t, t);
							break e;
						case 3:
							Nc = 7;
							break e;
						case 4:
							Nc = 5;
							break e;
						case 7:
							Ta(o) ? (Nc = 0, Mc = null, Cd(t)) : (Nc = 0, Mc = null, Nd(e, t, o, 7));
							break;
						case 5:
							var s = null;
							switch (Pc.tag) {
								case 26:
									s = Pc.memoizedState;
								case 5:
								case 27:
									var l = Pc;
									if (s ? Jh(s) : l.stateNode.complete) {
										Nc = 0, Mc = null;
										var u = l.sibling;
										if (null !== u) Pc = u;
										else {
											var c = l.return;
											null !== c ? (Pc = c, Md(c)) : Pc = null
										}
										break t
									}
							}
							Nc = 0, Mc = null, Nd(e, t, o, 5);
							break;
						case 6:
							Nc = 0, Mc = null, Nd(e, t, o, 6);
							break;
						case 8:
							md(), jc = 6;
							break e;
						default:
							throw Error(r(462))
					}
				}
				Td();
				break
			} catch (t) {
				vd(e, t)
			}
			return Zi = Wi = null, Z.H = i, Z.A = a, kc = n, null !== Pc ? 0 : (Tc = null, Cc = 0, Gr(), jc)
		}(e, t) : Ed(e, t, !0), o = i; ;) {
			if (0 === a) {
				_c && !i && hd(e, t, 0, !1);
				break
			}
			if (n = e.current.alternate, !o || fd(n)) {
				if (2 === a) {
					if (o = t, e.errorRecoveryDisabledLanes & o) var s = 0;
					else s = 0 !== (s = -536870913 & e.pendingLanes) ? s : 536870912 & s ? 536870912 : 0;
					if (0 !== s) {
						t = s;
						e: {
							var l = e; a = Vc;
							var u = l.current.memoizedState.isDehydrated;
							if (u && (gd(l, s).flags |= 256), 2 !== (s = Ed(l, s, !1)) && 6 !== s) {
								if (Lc && !u) {
									l.errorRecoveryDisabledLanes |= o, zc |= o, a = 4;
									break e
								}
								o = Bc, Bc = a, null !== o && (null === Bc ? Bc = o : Bc.push.apply(Bc, o))
							}
							a = s
						}
						if (o = !1, 2 !== a) continue
					}
				}
				if (1 === a) {
					gd(e, 0), hd(e, t, 0, !0);
					break
				}
				e: {
					switch (i = e, o = a) {
						case 0:
						case 1:
							throw Error(r(345));
						case 4:
							if ((4194048 & t) !== t && (62914560 & t) !== t) break;
						case 6:
							hd(i, t, Fc, !Ac);
							break e;
						case 2:
							Bc = null;
							break;
						case 3:
						case 5:
							break;
						default:
							throw Error(r(329))
					}
					if ((62914560 & t) === t && 10 < (a = Hc + 300 - xe())) {
						if (hd(i, t, Fc, !Ac), 0 !== Ie(i, 0, !0)) break e;
						Xc = t, i.timeoutHandle = Bf(dd.bind(null, i, n, Bc, Zc, Uc, t, Fc, zc, Ic, Ac, o, "Throttled", -0, 0), a)
					} else dd(i, n, Bc, Zc, Uc, t, Fc, zc, Ic, Ac, o, null, -0, 0)
				}
				break
			}
			a = Ed(e, t, !1), o = !1
		}
		Jd(e)
	}

	function dd(e, t, n, r, i, a, o, s, l, u, c, d, f, h) {
		e.timeoutHandle = -1;
		var p = t.subtreeFlags,
			m = (335544064 & a) === a;
		if (d = null, (m || 8192 & p || !(16785408 & ~p)) && (du = null, gc(t, a, d = {
			stylesheets: null,
			count: 0,
			imgCount: 0,
			imgBytes: 0,
			suspenseyImages: [],
			waitingForImages: !0,
			waitingForViewTransition: !1,
			unsuspend: qt
		}), m && (p = d, null != (m = (9 === (m = e.containerInfo).nodeType ? m : m.ownerDocument).__reactViewTransition) && (p.count++, p.waitingForViewTransition = !0, p = ip.bind(p), m.finished.then(p, p))), p = function (e, t) {
			return e.stylesheets && 0 === e.count && sp(e, e.stylesheets), 0 < e.count || 0 < e.imgCount ? function (n) {
				var r = setTimeout(function () {
					if (e.stylesheets && sp(e, e.stylesheets), e.unsuspend) {
						var t = e.unsuspend;
						e.unsuspend = null, t()
					}
				}, 6e4 + t);
				0 < e.imgBytes && 0 === np && (np = 62500 * function () {
					if ("function" == typeof performance.getEntriesByType) {
						for (var e = 0, t = 0, n = performance.getEntriesByType("resource"), r = 0; r < n.length; r++) {
							var i = n[r],
								a = i.transferSize,
								o = i.initiatorType,
								s = i.duration;
							if (a && s && Lf(o)) {
								for (o = 0, s = i.responseEnd, r += 1; r < n.length; r++) {
									var l = n[r],
										u = l.startTime;
									if (u > s) break;
									var c = l.transferSize,
										d = l.initiatorType;
									c && Lf(d) && (o += c * ((l = l.responseEnd) < s ? 1 : (s - u) / (l - u)))
								}
								if (--r, t += 8 * (a + o) / (i.duration / 1e3), 10 < ++e) break
							}
						}
						if (0 < e) return t / e / 1e6
					}
					return navigator.connection && (e = navigator.connection.downlink, "number" == typeof e) ? e : 5
				}());
				var i = setTimeout(function () {
					if (e.waitingForImages = !1, 0 === e.count && (e.stylesheets && sp(e, e.stylesheets), e.unsuspend)) {
						var t = e.unsuspend;
						e.unsuspend = null, t()
					}
				}, (e.imgBytes > np ? 50 : 800) + t);
				return e.unsuspend = n,
					function () {
						e.unsuspend = null, clearTimeout(r), clearTimeout(i)
					}
			} : null
		}(d, p = (62914560 & a) === a ? Hc - xe() : (4194048 & a) === a ? $c - xe() : 0), null !== p)) return Xc = a, e.cancelPendingCommit = p(_d.bind(null, e, t, a, n, r, i, o, s, l, u, c, d, null, f, h)), void hd(e, a, o, !u);
		_d(e, t, a, n, r, i, o, s, l, u, c, d)
	}

	function fd(e) {
		for (var t = e; ;) {
			var n = t.tag;
			if ((0 === n || 11 === n || 15 === n) && 16384 & t.flags && (null !== (n = t.updateQueue) && null !== (n = n.stores)))
				for (var r = 0; r < n.length; r++) {
					var i = n[r],
						a = i.getSnapshot;
					i = i.value;
					try {
						if (!mr(a(), i)) return !1
					} catch {
						return !1
					}
				}
			if (n = t.child, 16384 & t.subtreeFlags && null !== n) n.return = t, t = n;
			else {
				if (t === e) break;
				for (; null === t.sibling;) {
					if (null === t.return || t.return === e) return !0;
					t = t.return
				}
				t.sibling.return = t.return, t = t.sibling
			}
		}
		return !0
	}

	function hd(e, t, n, r) {
		t = Be(e, t), t &= ~Rc, t &= ~zc, e.suspendedLanes |= t, e.pingedLanes &= ~t, r && (e.warmLanes |= t), r = e.expirationTimes;
		for (var i = t; 0 < i;) {
			var a = 31 - Le(i),
				o = 1 << a;
			r[a] = -1, i &= ~o
		}
		0 !== n && Ze(e, n, t)
	}

	function pd() {
		return !!(6 & kc) || (ef(0), !1)
	}

	function md() {
		if (null !== Pc) {
			if (0 === Nc) var e = Pc.return;
			else Zi = Wi = null, Do(e = Pc), _a = null, La = 0, e = Pc;
			for (; null !== e;) Wl(e.alternate, e), e = e.return;
			Pc = null
		}
	}

	function gd(e, t) {
		var n = e.timeoutHandle;
		return -1 !== n && (e.timeoutHandle = -1, Uf(n)), null !== (n = e.cancelPendingCommit) && (e.cancelPendingCommit = null, n()), Xc = 0, md(), Tc = e, Pc = n = li(e.current, null), Cc = t, Nc = 0, Mc = null, Ac = !1, _c = Ve(e, t), Lc = !1, Ic = Fc = Rc = zc = Oc = jc = 0, Bc = Vc = null, Uc = !1, Dc = Be(e, t), Gr(), n
	}

	function vd(e, t) {
		mo = null, Z.H = Us, t === wa || t === Ea ? (t = Ma(), Nc = 3) : t === Sa ? (t = Ma(), Nc = 4) : Nc = t === al ? 8 : null !== t && "object" == typeof t && "function" == typeof t.then ? 6 : 1, Mc = t, null === Pc && (jc = 1, el(e, gi(t, e.current)))
	}

	function yd() {
		var e = no.current;
		return null === e || ((4194048 & Cc) === Cc ? null === ro : !!((62914560 & Cc) === Cc || 536870912 & Cc) && e === ro)
	}

	function bd() {
		var e = Z.H;
		return Z.H = Us, null === e ? Us : e
	}

	function wd() {
		var e = Z.A;
		return Z.A = Sc, e
	}

	function Sd() {
		jc = 4, Ac || (4194048 & Cc) !== Cc && null !== no.current || (_c = !0), !(134217727 & Oc) && !(134217727 & zc) || null === Tc || hd(Tc, Cc, Fc, !1)
	}

	function Ed(e, t, n) {
		var r = kc;
		kc |= 2;
		var i = bd(),
			a = wd();
		(Tc !== e || Cc !== t) && (Zc = null, gd(e, t)), t = !1;
		var o = jc;
		e: for (; ;) try {
			if (0 !== Nc && null !== Pc) {
				var s = Pc,
					l = Mc;
				switch (Nc) {
					case 8:
						md(), o = 6;
						break e;
					case 3:
					case 2:
					case 9:
					case 6:
						null === no.current && (t = !0);
						var u = Nc;
						if (Nc = 0, Mc = null, Nd(e, s, l, u), n && _c) {
							o = 0;
							break e
						}
						break;
					default:
						u = Nc, Nc = 0, Mc = null, Nd(e, s, l, u)
				}
			}
			kd(), o = jc;
			break
		} catch (t) {
			vd(e, t)
		}
		return t && e.shellSuspendCounter++, Zi = Wi = null, kc = r, Z.H = i, Z.A = a, null === Pc && (Tc = null, Cc = 0, Gr()), o
	}

	function kd() {
		for (; null !== Pc;) Pd(Pc)
	}

	function Td() {
		for (; null !== Pc && !ye();) Pd(Pc)
	}

	function Pd(e) {
		var t = zl(e.alternate, e, Dc);
		e.memoizedProps = e.pendingProps, null === t ? Md(e) : Pc = t
	}

	function Cd(e) {
		var t = e,
			n = t.alternate;
		switch (t.tag) {
			case 15:
			case 0:
				t = yl(n, t, t.pendingProps, t.type, void 0, Cc);
				break;
			case 11:
				t = yl(n, t, t.pendingProps, t.type.render, t.ref, Cc);
				break;
			case 5:
				Do(t);
				var r = t;
				r === _i && (Di ? (Ii(r), 5 === r.tag && null != r.stateNode && (Li = r.stateNode)) : (Ii(r), Di = !0));
			default:
				Wl(n, t), t = zl(n, t = Pc = ui(t, Dc), Dc)
		}
		e.memoizedProps = e.pendingProps, null === t ? Md(e) : Pc = t
	}

	function Nd(e, t, n, i) {
		Zi = Wi = null, Do(t), _a = null, La = 0;
		var a = t.return;
		try {
			if (function (e, t, n, i, a) {
				if (n.flags |= 32768, null !== i && "object" == typeof i && "function" == typeof i.then) {
					if (null !== (t = n.alternate) && Xi(t, n, a, !0), null !== (n = no.current)) {
						switch (n.tag) {
							case 31:
							case 13:
							case 19:
								return null === ro ? Sd() : null === n.alternate && 0 === jc && (jc = 3), n.flags &= -257, n.flags |= 65536, n.lanes = a, i === ka ? n.flags |= 16384 : (null === (t = n.updateQueue) ? n.updateQueue = new Set([i]) : t.add(i), Ud(e, i, a)), !1;
							case 22:
								return n.flags |= 65536, i === ka ? n.flags |= 16384 : (null === (t = n.updateQueue) ? (t = {
									transitions: null,
									markerInstances: null,
									retryQueue: new Set([i])
								}, n.updateQueue = t) : null === (n = t.retryQueue) ? t.retryQueue = new Set([i]) : n.add(i), Ud(e, i, a)), !1
						}
						throw Error(r(435, n.tag))
					}
					return Ud(e, i, a), Sd(), !1
				}
				if (Di) return null !== (t = no.current) ? (!(65536 & t.flags) && (t.flags |= 256), t.flags |= 65536, t.lanes = a, i !== zi && Hi(gi(e = Error(r(422), {
					cause: i
				}), n))) : (i !== zi && Hi(gi(t = Error(r(423), {
					cause: i
				}), n)), (e = e.current.alternate).flags |= 65536, a &= -a, e.lanes |= a, i = gi(i, n), Wa(e, a = nl(e.stateNode, i, a)), 4 !== jc && (jc = 2)), !1;
				var o = Error(r(520), {
					cause: i
				});
				if (o = gi(o, n), null === Vc ? Vc = [o] : Vc.push(o), 4 !== jc && (jc = 2), null === t) return !0;
				i = gi(i, n), n = t;
				do {
					switch (n.tag) {
						case 3:
							return n.flags |= 65536, e = a & -a, n.lanes |= e, Wa(n, e = nl(n.stateNode, i, e)), !1;
						case 1:
							if (t = n.type, o = n.stateNode, !(128 & n.flags || "function" != typeof t.getDerivedStateFromError && (null === o || "function" != typeof o.componentDidCatch || null !== Yc && Yc.has(o)))) return n.flags |= 65536, a &= -a, n.lanes |= a, il(a = rl(a), e, n, i), Wa(n, a), !1;
							break;
						case 22:
							if (null !== n.memoizedState) return n.flags |= 65536, !1
					}
					n = n.return
				} while (null !== n);
				return !1
			}(e, a, t, n, Cc)) return jc = 1, el(e, gi(n, e.current)), void (Pc = null)
		} catch (t) {
			if (null !== a) throw Pc = a, t;
			return jc = 1, el(e, gi(n, e.current)), void (Pc = null)
		}
		32768 & t.flags ? (Di || 1 === i ? e = !0 : _c || 536870912 & Cc ? e = !1 : (Ac = e = !0, (2 === i || 9 === i || 3 === i || 6 === i) && (null !== (i = no.current) && 13 === i.tag && (i.flags |= 16384))), Ad(t, e)) : Md(t)
	}

	function Md(e) {
		var t = e;
		do {
			if (32768 & t.flags) return void Ad(t, Ac);
			e = t.return;
			var n = Hl(t.alternate, t, Dc);
			if (null !== n) return void (Pc = n);
			if (null !== (t = t.sibling)) return void (Pc = t);
			Pc = t = e
		} while (null !== t);
		0 === jc && (jc = 5)
	}

	function Ad(e, t) {
		do {
			var n = $l(e.alternate, e);
			if (null !== n) return n.flags &= 32767, void (Pc = n);
			if (null !== (n = e.return) && (n.flags |= 32768, n.subtreeFlags = 0, n.deletions = null), !t && null !== (e = e.sibling)) return void (Pc = e);
			Pc = e = n
		} while (null !== e);
		jc = 6, Pc = null
	}

	function _d(e, t, n, i, a, o, s, l, u, c, d, f) {
		e.cancelPendingCommit = null;
		do {
			Fd()
		} while (0 !== qc);
		if (6 & kc) throw Error(r(327));
		if (null !== t) {
			if (t === e.current) throw Error(r(177));
			e === Tc && (Pc = Tc = null, Cc = 0), Qc = t, Kc = e, Xc = n, Jc = a, ed = i,
				function (e, t, n, r, i, a, o) {
					var s = t.lanes | t.childLanes;
					if (Gc = s, s |= Xr, function (e, t, n, r, i, a) {
						var o = e.pendingLanes;
						e.pendingLanes = n, e.suspendedLanes = 0, e.pingedLanes = 0, e.warmLanes = 0, e.expiredLanes &= n, e.entangledLanes &= n, e.errorRecoveryDisabledLanes &= n, e.shellSuspendCounter = 0;
						var s = e.entanglements,
							l = e.expirationTimes,
							u = e.hiddenUpdates;
						for (n = o & ~n; 0 < n;) {
							var c = 31 - Le(n),
								d = 1 << c;
							s[c] = 0, l[c] = -1;
							var f = u[c];
							if (null !== f)
								for (u[c] = null, c = 0; c < f.length; c++) {
									var h = f[c];
									null !== h && (h.lane &= -536870913)
								}
							n &= ~d
						}
						0 !== r && Ze(e, r, 0), 0 !== a && 0 === i && 0 !== e.tag && (e.suspendedLanes |= a & ~(o & ~t))
					}(e, n, s, r, i, a), nd = null, (335544064 & n) === n ? (rd = function (e) {
						var t = e.transitionTypes;
						return e.transitionTypes = null, t
					}(e), r = 10262) : (rd = null, r = 10256), 0 !== (t.subtreeFlags & r) || 0 !== (t.flags & r) ? (e.callbackNode = null, e.callbackPriority = 0, function (e, t) {
						ge(e, t)
					}(ke, function () {
						return Id(), null
					})) : (e.callbackNode = null, e.callbackPriority = 0), cu = !1, r = !!(13878 & t.flags), 13878 & t.subtreeFlags || r) {
						r = Z.T, Z.T = null, i = Y.p, Y.p = 2, a = kc, kc |= 4;
						try {
							! function (e, t, n) {
								if (e = e.containerInfo, Df = yp, Sr(e = wr(e))) {
									if ("selectionStart" in e) var r = {
										start: e.selectionStart,
										end: e.selectionEnd
									};
									else e: {
										var i = (r = (r = e.ownerDocument) && r.defaultView || window).getSelection && r.getSelection();
										if (i && 0 !== i.rangeCount) {
											r = i.anchorNode;
											var a = i.anchorOffset,
												o = i.focusNode;
											i = i.focusOffset;
											try {
												r.nodeType, o.nodeType
											} catch {
												r = null;
												break e
											}
											var s = 0,
												l = -1,
												u = -1,
												c = 0,
												d = 0,
												f = e,
												h = null;
											t: for (; ;) {
												for (var p; f !== r || 0 !== a && 3 !== f.nodeType || (l = s + a), f !== o || 0 !== i && 3 !== f.nodeType || (u = s + i), 3 === f.nodeType && (s += f.nodeValue.length), null !== (p = f.firstChild);) h = f, f = p;
												for (; ;) {
													if (f === e) break t;
													if (h === r && ++c === a && (l = s), h === o && ++d === i && (u = s), null !== (p = f.nextSibling)) break;
													h = (f = h).parentNode
												}
												f = p
											}
											r = -1 === l || -1 === u ? null : {
												start: l,
												end: u
											}
										} else r = null
									}
									r = r || {
										start: 0,
										end: 0
									}
								} else r = null;
								for (jf = {
									focusedElem: e,
									selectionRange: r
								}, yp = !1, ju = t, t = (n = (335544064 & n) === n) ? 9270 : 1024; null !== ju;) {
									if (e = ju, n && null !== (r = e.deletions))
										for (a = 0; a < r.length; a++) n && Su(r[a]);
									if (null === e.alternate && 2 & e.flags) n && fu(e), Iu(n);
									else {
										if (22 === e.tag) {
											if (r = e.alternate, null !== e.memoizedState) {
												null !== r && null === r.memoizedState && n && Su(r), Iu(n);
												continue
											}
											if (null !== r && null !== r.memoizedState) {
												n && fu(e), Iu(n);
												continue
											}
										}
										r = e.child, 0 !== (e.subtreeFlags & t) && null !== r ? (r.return = e, ju = r) : (n && Eu(e), Iu(n))
									}
								}
								du = null
							}(e, t, n)
						} finally {
							kc = a, Y.p = i, Z.T = r
						}
					}
					qc = 1, cu ? td = function (e, t, n, r, i, a, o, s, l) {
						var u = 9 === t.nodeType ? t : t.ownerDocument;
						try {
							var c = u.startViewTransition({
								update: function () {
									var t = u.defaultView,
										n = t.navigation && t.navigation.transition,
										o = u.fonts.status;
									r();
									var s = [];
									if ("loaded" === o && (function (e) {
										e.documentElement.clientHeight
									}(u), "loading" === u.fonts.status && s.push(u.fonts.ready)), o = s.length, null !== e)
										for (var l = e.suspenseyImages, c = 0, d = 0; d < l.length; d++) {
											var f = l[d];
											if (!f.complete) {
												var h = f.getBoundingClientRect();
												if (0 < h.bottom && 0 < h.right && h.top < t.innerHeight && h.left < t.innerWidth) {
													if ((c += ep(f)) > np) {
														s.length = o;
														break
													}
													f = new Promise(Jf.bind(f)), s.push(f)
												}
											}
										}
									return 0 < s.length ? (t = Promise.race([Promise.all(s), new Promise(function (e) {
										return setTimeout(e, 500)
									})]).then(i, i), (n ? Promise.allSettled([n.finished, t]) : t).then(a, a)) : (i(), n ? n.finished.then(a, a) : void a())
								},
								types: n
							});
							u.__reactViewTransition = c;
							var d = [];
							return c.ready.then(function () {
								for (var e = u.documentElement.getAnimations({
									subtree: !0
								}), t = 0; t < e.length; t++) {
									var n = e[t],
										r = n.effect,
										i = r.pseudoElement;
									if (null != i && i.startsWith("::view-transition")) {
										d.push(n), n = r.getKeyframes();
										for (var a = i = void 0, s = !0, l = 0; l < n.length; l++) {
											var c = n[l],
												f = c.width;
											if (void 0 === i) i = f;
											else if (i !== f) {
												s = !1;
												break
											}
											if (f = c.height, void 0 === a) a = f;
											else if (a !== f) {
												s = !1;
												break
											}
											delete c.width, delete c.height, "none" === c.transform && delete c.transform
										}
										s && void 0 !== i && void 0 !== a && (r.setKeyframes(n), (s = getComputedStyle(r.target, r.pseudoElement)).width !== i || s.height !== a) && ((s = n[0]).width = i, s.height = a, (s = n[n.length - 1]).width = i, s.height = a, r.setKeyframes(n))
									}
								}
								o()
							}, function (e) {
								u.__reactViewTransition === c && (u.__reactViewTransition = null);
								try {
									if ("object" == typeof e && null !== e && "InvalidStateError" === e.name) ("View transition was skipped because document visibility state is hidden." === e.message || "Skipping view transition because document visibility state has become hidden." === e.message || "Skipping view transition because viewport size changed." === e.message || "Transition was aborted because of invalid state" === e.message) && (e = null);
									null !== e && l(e)
								} finally {
									r(), i(), o()
								}
							}), c.finished.finally(function () {
								for (var e = 0; e < d.length; e++) d[e].cancel();
								u.__reactViewTransition === c && (u.__reactViewTransition = null), s()
							}), c
						} catch {
							return r(), i(), o(), null
						}
					}(o, e.containerInfo, rd, jd, Od, Dd, zd, Id, Ld) : (jd(), Od(), zd())
				}(e, t, n, s, l, u, f)
		}
	}

	function Ld(e) {
		0 !== qc && (0, Kc.onRecoverableError)(e, {
			componentStack: null
		})
	}

	function Dd() {
		3 === qc && (qc = 0, ic(Qc, Kc), qc = 4)
	}

	function jd() {
		if (1 === qc) {
			qc = 0;
			var e = Kc,
				t = Qc,
				n = Xc,
				r = !!(13878 & t.flags);
			if (13878 & t.subtreeFlags || r) {
				r = Z.T, Z.T = null;
				var i = Y.p;
				Y.p = 2;
				var a = kc;
				kc |= 4;
				try {
					zu = Ru = !1, ec(t, e, n), n = jf;
					var o = wr(e.containerInfo),
						s = n.focusedElem,
						l = n.selectionRange;
					if (o !== s && s && s.ownerDocument && xr(s.ownerDocument.documentElement, s)) {
						if (null !== l && Sr(s)) {
							var u = l.start,
								c = l.end;
							if (void 0 === c && (c = u), "selectionStart" in s) s.selectionStart = u, s.selectionEnd = Math.min(c, s.value.length);
							else {
								var d = s.ownerDocument || document,
									f = d && d.defaultView || window;
								if (f.getSelection) {
									var h = f.getSelection(),
										p = s.textContent.length,
										m = Math.min(l.start, p),
										g = void 0 === l.end ? m : Math.min(l.end, p);
									!h.extend && m > g && (o = g, g = m, m = o);
									var v = br(s, m),
										y = br(s, g);
									if (v && y && (1 !== h.rangeCount || h.anchorNode !== v.node || h.anchorOffset !== v.offset || h.focusNode !== y.node || h.focusOffset !== y.offset)) {
										var b = d.createRange();
										b.setStart(v.node, v.offset), h.removeAllRanges(), m > g ? (h.addRange(b), h.extend(y.node, y.offset)) : (b.setEnd(y.node, y.offset), h.addRange(b))
									}
								}
							}
						}
						for (d = [], h = s; h = h.parentNode;) 1 === h.nodeType && d.push({
							element: h,
							left: h.scrollLeft,
							top: h.scrollTop
						});
						for ("function" == typeof s.focus && s.focus(), s = 0; s < d.length; s++) {
							var x = d[s];
							x.element.scrollLeft = x.left, x.element.scrollTop = x.top
						}
					}
					yp = !!Df, jf = Df = null
				} finally {
					kc = a, Y.p = i, Z.T = r
				}
			}
			e.current = t, qc = 2
		}
	}

	function Od() {
		if (2 === qc) {
			qc = 0;
			var e = Kc,
				t = Qc,
				n = !!(8772 & t.flags);
			if (8772 & t.subtreeFlags || n) {
				n = Z.T, Z.T = null;
				var r = Y.p;
				Y.p = 2;
				var i = kc;
				kc |= 4;
				try {
					Vu(e, t.alternate, t)
				} finally {
					kc = i, Y.p = r, Z.T = n
				}
			}
			qc = 3
		}
	}

	function zd() {
		if (4 === qc || 3 === qc) {
			qc = 0;
			var e = td;
			td = null, be();
			var t = Kc,
				n = Qc,
				r = Xc,
				i = ed,
				a = (335544064 & r) === r ? 10262 : 10256;
			if (0 !== (n.subtreeFlags & a) || 0 !== (n.flags & a) ? qc = 5 : (qc = 0, Qc = Kc = null, Rd(t, t.pendingLanes)), 0 === (a = t.pendingLanes) && (Yc = null), Qe(r), n = n.stateNode, Ae && "function" == typeof Ae.onCommitFiberRoot) try {
				Ae.onCommitFiberRoot(Me, n, void 0, !(128 & ~n.current.flags))
			} catch { }
			if (null !== i) {
				n = Z.T, a = Y.p, Y.p = 2, Z.T = null;
				try {
					for (var o = t.onRecoverableError, s = 0; s < i.length; s++) {
						var l = i[s];
						o(l.value, {
							componentStack: l.stack
						})
					}
				} finally {
					Z.T = n, Y.p = a
				}
			}
			if (o = rd, rd = null, null !== (i = nd) && (nd = null, null === o && (o = []), null !== e))
				for (l = 0; l < i.length; l++) void 0 !== (n = (0, i[l])(o)) && e.finished.finally(n);
			!!(3 & Xc) && Fd(), Jd(t), a = t.pendingLanes, 261930 & r && 42 & a ? t === ad ? id++ : (id = 0, ad = t) : (id = 0, ad = null), ef(0)
		}
	}

	function Rd(e, t) {
		0 === (e.pooledCacheLanes &= t) && (null != (t = e.pooledCache) && (e.pooledCache = null, la(t)))
	}

	function Fd() {
		return null !== td && (td.skipTransition(), td = null), jd(), Od(), zd(), Id()
	}

	function Id() {
		if (5 !== qc) return !1;
		var e = Kc,
			t = Gc;
		Gc = 0;
		var n = Qe(Xc),
			i = Z.T,
			a = Y.p;
		try {
			Y.p = 32 > n ? 32 : n, Z.T = null, n = Jc, Jc = null;
			var o = Kc,
				s = Xc;
			if (qc = 0, Qc = Kc = null, Xc = 0, 6 & kc) throw Error(r(331));
			var l = kc;
			if (kc |= 4, bc(o.current), dc(o, o.current, s, n), kc = l, ef(0, !1), Ae && "function" == typeof Ae.onPostCommitFiberRoot) try {
				Ae.onPostCommitFiberRoot(Me, o)
			} catch { }
			return !0
		} finally {
			Y.p = a, Z.T = i, Rd(e, t)
		}
	}

	function Vd(e, t, n) {
		t = gi(n, t), null !== (e = Ha(e, t = nl(e.stateNode, t, 2), 2)) && (We(e, 2), Jd(e))
	}

	function Bd(e, t, n) {
		if (3 === e.tag) Vd(e, e, n);
		else
			for (; null !== t;) {
				if (3 === t.tag) {
					Vd(t, e, n);
					break
				}
				if (1 === t.tag) {
					var r = t.stateNode;
					if ("function" == typeof t.type.getDerivedStateFromError || "function" == typeof r.componentDidCatch && (null === Yc || !Yc.has(r))) {
						e = gi(n, e), null !== (r = Ha(t, n = rl(2), 2)) && (il(n, r, t, e), We(r, 2), Jd(r));
						break
					}
				}
				t = t.return
			}
	}

	function Ud(e, t, n) {
		var r = e.pingCache;
		if (null === r) {
			r = e.pingCache = new Ec;
			var i = new Set;
			r.set(t, i)
		} else void 0 === (i = r.get(t)) && (i = new Set, r.set(t, i));
		i.has(n) || (Lc = !0, i.add(n), e = Hd.bind(null, e, t, n), t.then(e, e))
	}

	function Hd(e, t, n) {
		var r = e.pingCache;
		null !== r && r.delete(t), e.pingedLanes |= e.suspendedLanes & n, e.warmLanes &= ~n, Tc === e && (Cc & n) === n && (!(4 === jc || 3 === jc && (62914560 & Cc) === Cc && 300 > xe() - Hc) || 2 & kc ? Rc |= n : gd(e, 0), Ic === Cc && (Ic = 0)), Jd(e)
	}

	function $d(e, t) {
		0 === t && (t = He()), null !== (e = ti(e, t)) && (We(e, t), Jd(e))
	}

	function Wd(e) {
		var t = e.memoizedState,
			n = 0;
		null !== t && (n = t.retryLane), $d(e, n)
	}

	function Zd(e, t) {
		var n = 0;
		switch (e.tag) {
			case 31:
			case 13:
				var i = e.stateNode,
					a = e.memoizedState;
				null !== a && (n = a.retryLane);
				break;
			case 19:
				i = e.stateNode;
				break;
			case 22:
				i = e.stateNode._retryCache;
				break;
			default:
				throw Error(r(314))
		}
		null !== i && i.delete(t), $d(e, n)
	}
	var Yd = null,
		qd = null,
		Kd = !1,
		Qd = !1,
		Xd = !1,
		Gd = 0;

	function Jd(e) {
		e !== qd && null === e.next && (null === qd ? Yd = qd = e : qd = qd.next = e), Qd = !0, Kd || (Kd = !0, Wf(function () {
			6 & kc ? ge(Se, tf) : nf()
		}))
	}

	function ef(e, t) {
		if (!Xd && Qd) {
			Xd = !0;
			do {
				for (var n = !1, r = Yd; null !== r;) {
					if (0 !== e) {
						var i = r.pendingLanes;
						if (0 === i) var a = 0;
						else {
							var o = r.suspendedLanes,
								s = r.pingedLanes;
							a = (1 << 31 - Le(42 | e) + 1) - 1, a = 201326741 & (a &= i & ~(o & ~s)) ? 201326741 & a | 1 : a ? 2 | a : 0
						}
						0 !== a && (n = !0, of(r, a))
					} else a = Cc, !(3 & (a = Ie(r, r === Tc ? a : 0, null !== r.cancelPendingCommit || -1 !== r.timeoutHandle))) || Ve(r, a) || (n = !0, of(r, a));
					r = r.next
				}
			} while (n);
			Xd = !1
		}
	}

	function tf() {
		nf()
	}

	function nf() {
		Qd = Kd = !1;
		var e = 0;
		0 !== Gd && function () {
			var e = window.event;
			return e && "popstate" === e.type ? e !== Vf && (Vf = e, !0) : (Vf = null, !1)
		}() && (e = Gd);
		for (var t = xe(), n = null, r = Yd; null !== r;) {
			var i = r.next,
				a = rf(r, t);
			0 === a ? (r.next = null, null === n ? Yd = i : n.next = i, null === i && (qd = n)) : (n = r, (0 !== e || !!(3 & a)) && (Qd = !0)), r = i
		}
		0 !== qc && 5 !== qc || ef(e), 0 !== Gd && (Gd = 0)
	}

	function rf(e, t) {
		for (var n = e.suspendedLanes, r = e.pingedLanes, i = e.expirationTimes, a = -62914561 & e.pendingLanes; 0 < a;) {
			var o = 31 - Le(a),
				s = 1 << o,
				l = i[o]; - 1 === l ? (0 === (s & n) || 0 !== (s & r)) && (i[o] = Ue(s, t)) : l <= t && (e.expiredLanes |= s), a &= ~s
		}
		if (n = Cc, n = Ie(e, e === (t = Tc) ? n : 0, null !== e.cancelPendingCommit || -1 !== e.timeoutHandle), r = e.callbackNode, 0 === n || e === t && (2 === Nc || 9 === Nc) || null !== e.cancelPendingCommit) return null !== r && null !== r && ve(r), e.callbackNode = null, e.callbackPriority = 0;
		if (!(3 & n) || Ve(e, n)) {
			if ((t = n & -n) === e.callbackPriority) return t;
			switch (null !== r && ve(r), Qe(n)) {
				case 2:
				case 8:
					n = Ee;
					break;
				case 32:
				default:
					n = ke;
					break;
				case 268435456:
					n = Pe
			}
			return r = af.bind(null, e), n = ge(n, r), e.callbackPriority = t, e.callbackNode = n, t
		}
		return null !== r && null !== r && ve(r), e.callbackPriority = 2, e.callbackNode = null, 2
	}

	function af(e, t) {
		if (0 !== qc && 5 !== qc) return e.callbackNode = null, e.callbackPriority = 0, null;
		var n = e.callbackNode;
		if (Fd() && e.callbackNode !== n) return null;
		var r = Cc;
		return 0 === (r = Ie(e, e === Tc ? r : 0, null !== e.cancelPendingCommit || -1 !== e.timeoutHandle)) ? null : (cd(e, r, t), rf(e, xe()), null != e.callbackNode && e.callbackNode === n ? af.bind(null, e) : null)
	}

	function of(e, t) {
		if (Fd()) return null;
		cd(e, t, !0)
	}

	function sf() {
		if (0 === Gd) {
			var e = ha;
			0 === e && (e = Oe, !(261888 & (Oe <<= 1)) && (Oe = 256)), Gd = e
		}
		return Gd
	}

	function lf(e) {
		return null == e || "symbol" == typeof e || "boolean" == typeof e ? null : "function" == typeof e ? e : Yt(e)
	}
	for (var uf = 0; uf < Ur.length; uf++) {
		var cf = Ur[uf];
		Hr(cf.toLowerCase(), "on" + (cf[0].toUpperCase() + cf.slice(1)))
	}
	Hr(jr, "onAnimationEnd"), Hr(Or, "onAnimationIteration"), Hr(zr, "onAnimationStart"), Hr("dblclick", "onDoubleClick"), Hr("focusin", "onFocus"), Hr("focusout", "onBlur"), Hr(Rr, "onTransitionRun"), Hr(Fr, "onTransitionStart"), Hr(Ir, "onTransitionCancel"), Hr(Vr, "onTransitionEnd"), bt("onMouseEnter", ["mouseout", "mouseover"]), bt("onMouseLeave", ["mouseout", "mouseover"]), bt("onPointerEnter", ["pointerout", "pointerover"]), bt("onPointerLeave", ["pointerout", "pointerover"]), yt("onChange", "change click focusin focusout input keydown keyup selectionchange".split(" ")), yt("onSelect", "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")), yt("onBeforeInput", ["compositionend", "keypress", "textInput", "paste"]), yt("onCompositionEnd", "compositionend focusout keydown keypress keyup mousedown".split(" ")), yt("onCompositionStart", "compositionstart focusout keydown keypress keyup mousedown".split(" ")), yt("onCompositionUpdate", "compositionupdate focusout keydown keypress keyup mousedown".split(" "));
	var df = "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),
		ff = new Set("beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(df));

	function hf(e, t) {
		t = !!(4 & t);
		for (var n = 0; n < e.length; n++) {
			var r = e[n],
				i = r.event;
			r = r.listeners;
			e: {
				var a = void 0;
				if (t)
					for (var o = r.length - 1; 0 <= o; o--) {
						var s = r[o],
							l = s.instance,
							u = s.currentTarget;
						if (s = s.listener, l !== a && i.isPropagationStopped()) break e;
						a = s, i.currentTarget = u;
						try {
							a(i)
						} catch (e) {
							qr(e)
						}
						i.currentTarget = null, a = l
					} else
					for (o = 0; o < r.length; o++) {
						if (l = (s = r[o]).instance, u = s.currentTarget, s = s.listener, l !== a && i.isPropagationStopped()) break e;
						a = s, i.currentTarget = u;
						try {
							a(i)
						} catch (e) {
							qr(e)
						}
						i.currentTarget = null, a = l
					}
			}
		}
	}

	function pf(e, t) {
		var n = t[rt];
		void 0 === n && (n = t[rt] = new Set);
		var r = e + "__bubble";
		n.has(r) || (yf(t, e, 2, !1), n.add(r))
	}

	function mf(e, t, n) {
		var r = 0;
		t && (r |= 4), yf(n, e, r, t)
	}
	var gf = "_reactListening" + Math.random().toString(36).slice(2);

	function vf(e) {
		if (!e[gf]) {
			e[gf] = !0, gt.forEach(function (t) {
				"selectionchange" !== t && (ff.has(t) || mf(t, !1, e), mf(t, !0, e))
			});
			var t = 9 === e.nodeType ? e : e.ownerDocument;
			null === t || t[gf] || (t[gf] = !0, mf("selectionchange", !1, t))
		}
	}

	function yf(e, t, n, r) {
		switch (Tp(t)) {
			case 2:
				var i = bp;
				break;
			case 8:
				i = xp;
				break;
			default:
				i = wp
		}
		n = i.bind(null, t, n, e), i = void 0, !an || "touchstart" !== t && "touchmove" !== t && "wheel" !== t || (i = !0), r ? void 0 !== i ? e.addEventListener(t, n, {
			capture: !0,
			passive: i
		}) : e.addEventListener(t, n, !0) : void 0 !== i ? e.addEventListener(t, n, {
			passive: i
		}) : e.addEventListener(t, n, !1)
	}

	function bf(e, t, n, r, i) {
		var o = r;
		if (!(1 & t || 2 & t || null === r)) e: for (; ;) {
			if (null === r) return;
			var s = r.tag;
			if (3 === s || 4 === s) {
				var l = r.stateNode.containerInfo;
				if (l === i) break;
				if (4 === s)
					for (s = r.return; null !== s;) {
						var u = s.tag;
						if ((3 === u || 4 === u) && s.stateNode.containerInfo === i) return;
						s = s.return
					}
				for (; null !== l;) {
					if (null === (s = ct(l))) return;
					if (5 === (u = s.tag) || 6 === u || 26 === u || 27 === u) {
						r = o = s;
						continue e
					}
					l = l.parentNode
				}
			}
			r = r.return
		}
		tn(function () {
			var r = o,
				i = Qt(n),
				s = [];
			e: {
				var l = Br.get(e);
				if (void 0 !== l) {
					var u = bn,
						c = e;
					switch (e) {
						case "keypress":
							if (0 === dn(n)) break e;
						case "keydown":
						case "keyup":
							u = jn;
							break;
						case "focusin":
							c = "focus", u = Tn;
							break;
						case "focusout":
							c = "blur", u = Tn;
							break;
						case "beforeblur":
						case "afterblur":
							u = Tn;
							break;
						case "click":
							if (2 === n.button) break e;
						case "auxclick":
						case "dblclick":
						case "mousedown":
						case "mousemove":
						case "mouseup":
						case "mouseout":
						case "mouseover":
						case "contextmenu":
							u = En;
							break;
						case "drag":
						case "dragend":
						case "dragenter":
						case "dragexit":
						case "dragleave":
						case "dragover":
						case "dragstart":
						case "drop":
							u = kn;
							break;
						case "touchcancel":
						case "touchend":
						case "touchmove":
						case "touchstart":
							u = Rn;
							break;
						case jr:
						case Or:
						case zr:
							u = Pn;
							break;
						case Vr:
							u = Fn;
							break;
						case "scroll":
						case "scrollend":
							u = wn;
							break;
						case "wheel":
							u = In;
							break;
						case "copy":
						case "cut":
						case "paste":
							u = Cn;
							break;
						case "gotpointercapture":
						case "lostpointercapture":
						case "pointercancel":
						case "pointerdown":
						case "pointermove":
						case "pointerout":
						case "pointerover":
						case "pointerup":
							u = On;
							break;
						case "submit":
							u = zn;
							break;
						case "toggle":
						case "beforetoggle":
							u = Vn
					}
					var d = !!(4 & t),
						f = !d && ("scroll" === e || "scrollend" === e),
						h = d ? null !== l ? l + "Capture" : null : l;
					d = [];
					for (var p, m = r; null !== m;) {
						var g = m;
						if (p = g.stateNode, 5 !== (g = g.tag) && 26 !== g && 27 !== g || null === p || null === h || null != (g = nn(m, h)) && d.push(xf(m, g, p)), f) break;
						m = m.return
					}
					0 < d.length && (l = new u(l, c, null, n, i), s.push({
						event: l,
						listeners: d
					}))
				}
			}
			if (!(7 & t)) {
				if (l = "mouseout" === e || "pointerout" === e, (u = "mouseover" === e || "pointerover" === e) && n !== Kt && (c = n.relatedTarget || n.fromElement) && (ct(c) || c[nt]) || (l || u) && (c = i.window === i ? i : (u = i.ownerDocument) ? u.defaultView || u.parentWindow : window, l ? (l = r, null !== (u = (u = n.relatedTarget || n.toElement) ? ct(u) : null) && (f = a(u), d = u.tag, u !== f || 5 !== d && 27 !== d && 6 !== d) && (u = null)) : (l = null, u = r), l !== u && (d = En, g = "onMouseLeave", h = "onMouseEnter", m = "mouse", ("pointerout" === e || "pointerover" === e) && (d = On, g = "onPointerLeave", h = "onPointerEnter", m = "pointer"), f = null == l ? c : ft(l), p = null == u ? c : ft(u), (c = new d(g, m + "leave", l, n, i)).target = f, c.relatedTarget = p, g = null, ct(i) === r && ((d = new d(h, m + "enter", u, n, i)).target = p, d.relatedTarget = f, g = d), f = g, d = l && u ? w(l, u, Sf) : null, null !== l && Ef(s, c, l, d, !1), null !== u && null !== f && Ef(s, f, u, d, !0))), "select" === (u = (l = r ? ft(r) : window).nodeName && l.nodeName.toLowerCase()) || "input" === u && "file" === l.type) var v = ir;
				else if (Gn(l))
					if (ar) v = pr;
					else {
						v = fr;
						var y = dr
					}
				else !(u = l.nodeName) || "input" !== u.toLowerCase() || "checkbox" !== l.type && "radio" !== l.type ? r && $t(r.elementType) && (v = ir) : v = hr;
				switch (v && (v = v(e, r)) ? Jn(s, v, n, i) : y && y(e, l, r), y = r ? ft(r) : window, e) {
					case "focusin":
						(Gn(y) || "true" === y.contentEditable) && (kr = y, Tr = r, Pr = null);
						break;
					case "focusout":
						Pr = Tr = kr = null;
						break;
					case "mousedown":
						Cr = !0;
						break;
					case "contextmenu":
					case "mouseup":
					case "dragend":
						Cr = !1, Nr(s, n, i);
						break;
					case "selectionchange":
						if (Er) break;
					case "keydown":
					case "keyup":
						Nr(s, n, i)
				}
				var b;
				if (Un) e: {
					switch (e) {
						case "compositionstart":
							var x = "onCompositionStart";
							break e;
						case "compositionend":
							x = "onCompositionEnd";
							break e;
						case "compositionupdate":
							x = "onCompositionUpdate";
							break e
					}
					x = void 0
				}
				else Qn ? qn(e, n) && (x = "onCompositionEnd") : "keydown" === e && 229 === n.keyCode && (x = "onCompositionStart");
				x && (Wn && "ko" !== n.locale && (Qn || "onCompositionStart" !== x ? "onCompositionEnd" === x && Qn && (b = cn()) : (ln = "value" in (sn = i) ? sn.value : sn.textContent, Qn = !0)), 0 < (y = wf(r, x)).length && (x = new Nn(x, e, null, n, i), s.push({
					event: x,
					listeners: y
				}), b ? x.data = b : null !== (b = Kn(n)) && (x.data = b))), (b = $n ? function (e, t) {
					switch (e) {
						case "compositionend":
							return Kn(t);
						case "keypress":
							return 32 !== t.which ? null : (Yn = !0, Zn);
						case "textInput":
							return (e = t.data) === Zn && Yn ? null : e;
						default:
							return null
					}
				}(e, n) : function (e, t) {
					if (Qn) return "compositionend" === e || !Un && qn(e, t) ? (e = cn(), un = ln = sn = null, Qn = !1, e) : null;
					switch (e) {
						case "paste":
						default:
							return null;
						case "keypress":
							if (!(t.ctrlKey || t.altKey || t.metaKey) || t.ctrlKey && t.altKey) {
								if (t.char && 1 < t.char.length) return t.char;
								if (t.which) return String.fromCharCode(t.which)
							}
							return null;
						case "compositionend":
							return Wn && "ko" !== t.locale ? null : t.data
					}
				}(e, n)) && (0 < (x = wf(r, "onBeforeInput")).length && (y = new Nn("onBeforeInput", "beforeinput", null, n, i), s.push({
					event: y,
					listeners: x
				}), y.data = b)),
					function (e, t, n, r, i) {
						if ("submit" === t && n && n.stateNode === i) {
							var a = lf((i[tt] || null).action),
								o = r.submitter;
							o && null !== (t = (t = o[tt] || null) ? lf(t.formAction) : o.getAttribute("formAction")) && (a = t, o = null);
							var s = new bn("action", "action", null, r, i);
							e.push({
								event: s,
								listeners: [{
									instance: null,
									listener: function () {
										if (r.defaultPrevented) {
											if (0 !== Gd) {
												var e = new FormData(i, o);
												Ns(n, {
													pending: !0,
													data: e,
													method: i.method,
													action: a
												}, null, e)
											}
										} else "function" == typeof a && (s.preventDefault(), e = new FormData(i, o), Ns(n, {
											pending: !0,
											data: e,
											method: i.method,
											action: a
										}, a, e))
									},
									currentTarget: i
								}]
							})
						}
					}(s, e, r, n, i)
			}
			hf(s, t)
		})
	}

	function xf(e, t, n) {
		return {
			instance: e,
			listener: t,
			currentTarget: n
		}
	}

	function wf(e, t) {
		for (var n = t + "Capture", r = []; null !== e;) {
			var i = e,
				a = i.stateNode;
			if (5 !== (i = i.tag) && 26 !== i && 27 !== i || null === a || (null != (i = nn(e, n)) && r.unshift(xf(e, i, a)), null != (i = nn(e, t)) && r.push(xf(e, i, a))), 3 === e.tag) return r;
			e = e.return
		}
		return []
	}

	function Sf(e) {
		if (null === e) return null;
		do {
			e = e.return
		} while (e && 5 !== e.tag && 27 !== e.tag);
		return e || null
	}

	function Ef(e, t, n, r, i) {
		for (var a = t._reactName, o = []; null !== n && n !== r;) {
			var s = n,
				l = s.alternate,
				u = s.stateNode;
			if (s = s.tag, null !== l && l === r) break;
			5 !== s && 26 !== s && 27 !== s || null === u || (l = u, i ? null != (u = nn(n, a)) && o.unshift(xf(n, u, l)) : i || null != (u = nn(n, a)) && o.push(xf(n, u, l))), n = n.return
		}
		0 !== o.length && e.push({
			event: t,
			listeners: o
		})
	}
	var kf = /\r\n?/g,
		Tf = /\u0000|\uFFFD/g;

	function Pf(e) {
		return ("string" == typeof e ? e : "" + e).replace(kf, "\n").replace(Tf, "")
	}

	function Cf(e, t) {
		return t = Pf(t), Pf(e) === t
	}

	function Nf(e, t, n, i, a, o) {
		switch (n) {
			case "children":
				if ("string" == typeof i) "body" === t || "textarea" === t && "" === i || Vt(e, i);
				else {
					if ("number" != typeof i && "bigint" != typeof i) return;
					"body" !== t && Vt(e, "" + i)
				}
				break;
			case "className":
				Pt(e, "class", i);
				break;
			case "tabIndex":
				Pt(e, "tabindex", i);
				break;
			case "dir":
			case "role":
			case "viewBox":
			case "width":
			case "height":
				Pt(e, n, i);
				break;
			case "style":
				return void Ht(e, i, o);
			case "data":
				if ("object" !== t) {
					Pt(e, "data", i);
					break
				}
			case "src":
			case "href":
				if ("" === i && ("a" !== t || "href" !== n)) {
					e.removeAttribute(n);
					break
				}
				if (null == i || "function" == typeof i || "symbol" == typeof i || "boolean" == typeof i) {
					e.removeAttribute(n);
					break
				}
				i = Yt(i), e.setAttribute(n, i);
				break;
			case "action":
			case "formAction":
				if ("function" == typeof i) {
					e.setAttribute(n, "javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')");
					break
				}
				if ("function" == typeof o && ("formAction" === n ? ("input" !== t && Nf(e, t, "name", a.name, a, null), Nf(e, t, "formEncType", a.formEncType, a, null), Nf(e, t, "formMethod", a.formMethod, a, null), Nf(e, t, "formTarget", a.formTarget, a, null)) : (Nf(e, t, "encType", a.encType, a, null), Nf(e, t, "method", a.method, a, null), Nf(e, t, "target", a.target, a, null))), null == i || "symbol" == typeof i || "boolean" == typeof i) {
					e.removeAttribute(n);
					break
				}
				i = Yt(i), e.setAttribute(n, i);
				break;
			case "onClick":
				return void (null != i && (e.onclick = qt));
			case "onScroll":
				return void (null != i && pf("scroll", e));
			case "onScrollEnd":
				return void (null != i && pf("scrollend", e));
			case "dangerouslySetInnerHTML":
				if (null != i) {
					if ("object" != typeof i || !("__html" in i)) throw Error(r(61));
					if (null != (n = i.__html)) {
						if (null != a.children) throw Error(r(60));
						(null != o ? o.__html : void 0) !== n && (e.innerHTML = n)
					}
				}
				break;
			case "multiple":
				e.multiple = i && "function" != typeof i && "symbol" != typeof i;
				break;
			case "muted":
				e.muted = i && "function" != typeof i && "symbol" != typeof i;
				break;
			case "suppressContentEditableWarning":
			case "suppressHydrationWarning":
			case "defaultValue":
			case "defaultChecked":
			case "innerHTML":
			case "ref":
			case "autoFocus":
				break;
			case "xlinkHref":
				if (null == i || "function" == typeof i || "boolean" == typeof i || "symbol" == typeof i) {
					e.removeAttribute("xlink:href");
					break
				}
				n = Yt(i), e.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", n);
				break;
			case "contentEditable":
			case "spellCheck":
			case "draggable":
			case "value":
			case "autoReverse":
			case "externalResourcesRequired":
			case "focusable":
			case "preserveAlpha":
				null != i && "function" != typeof i && "symbol" != typeof i ? e.setAttribute(n, i) : e.removeAttribute(n);
				break;
			case "inert":
			case "allowFullScreen":
			case "async":
			case "autoPlay":
			case "controls":
			case "credentialless":
			case "default":
			case "defer":
			case "disabled":
			case "disablePictureInPicture":
			case "disableRemotePlayback":
			case "formNoValidate":
			case "hidden":
			case "loop":
			case "noModule":
			case "noValidate":
			case "open":
			case "playsInline":
			case "readOnly":
			case "required":
			case "reversed":
			case "scoped":
			case "seamless":
			case "itemScope":
				i && "function" != typeof i && "symbol" != typeof i ? e.setAttribute(n, "") : e.removeAttribute(n);
				break;
			case "capture":
			case "download":
				!0 === i ? e.setAttribute(n, "") : !1 !== i && null != i && "function" != typeof i && "symbol" != typeof i ? e.setAttribute(n, i) : e.removeAttribute(n);
				break;
			case "cols":
			case "rows":
			case "size":
			case "span":
				null != i && "function" != typeof i && "symbol" != typeof i && !isNaN(i) && 1 <= i ? e.setAttribute(n, i) : e.removeAttribute(n);
				break;
			case "rowSpan":
			case "start":
				null == i || "function" == typeof i || "symbol" == typeof i || isNaN(i) ? e.removeAttribute(n) : e.setAttribute(n, i);
				break;
			case "popover":
				pf("beforetoggle", e), pf("toggle", e), Tt(e, "popover", i);
				break;
			case "xlinkActuate":
				Ct(e, "http://www.w3.org/1999/xlink", "xlink:actuate", i);
				break;
			case "xlinkArcrole":
				Ct(e, "http://www.w3.org/1999/xlink", "xlink:arcrole", i);
				break;
			case "xlinkRole":
				Ct(e, "http://www.w3.org/1999/xlink", "xlink:role", i);
				break;
			case "xlinkShow":
				Ct(e, "http://www.w3.org/1999/xlink", "xlink:show", i);
				break;
			case "xlinkTitle":
				Ct(e, "http://www.w3.org/1999/xlink", "xlink:title", i);
				break;
			case "xlinkType":
				Ct(e, "http://www.w3.org/1999/xlink", "xlink:type", i);
				break;
			case "xmlBase":
				Ct(e, "http://www.w3.org/XML/1998/namespace", "xml:base", i);
				break;
			case "xmlLang":
				Ct(e, "http://www.w3.org/XML/1998/namespace", "xml:lang", i);
				break;
			case "xmlSpace":
				Ct(e, "http://www.w3.org/XML/1998/namespace", "xml:space", i);
				break;
			case "is":
				Tt(e, "is", i);
				break;
			case "innerText":
			case "textContent":
				return;
			default:
				if (2 < n.length && ("o" === n[0] || "O" === n[0]) && ("n" === n[1] || "N" === n[1])) return;
				Tt(e, n = Wt.get(n) || n, i)
		}
		Et = !0
	}

	function Mf(e, t, n, i, a, o) {
		switch (n) {
			case "style":
				return void Ht(e, i, o);
			case "dangerouslySetInnerHTML":
				if (null != i) {
					if ("object" != typeof i || !("__html" in i)) throw Error(r(61));
					if (null != (n = i.__html)) {
						if (null != a.children) throw Error(r(60));
						(null != o ? o.__html : void 0) !== n && (e.innerHTML = n)
					}
				}
				break;
			case "children":
				if ("string" == typeof i) Vt(e, i);
				else {
					if ("number" != typeof i && "bigint" != typeof i) return;
					Vt(e, "" + i)
				}
				break;
			case "onScroll":
				return void (null != i && pf("scroll", e));
			case "onScrollEnd":
				return void (null != i && pf("scrollend", e));
			case "onClick":
				return void (null != i && (e.onclick = qt));
			case "suppressContentEditableWarning":
			case "suppressHydrationWarning":
			case "innerHTML":
			case "ref":
			case "innerText":
			case "textContent":
				return;
			default:
				return void (vt.hasOwnProperty(n) || ("o" !== n[0] || "n" !== n[1] || (a = n.endsWith("Capture"), o = n.slice(2, a ? n.length - 7 : void 0), "function" == typeof (t = null != (t = e[tt] || null) ? t[n] : null) && e.removeEventListener(o, t, a), "function" != typeof i) ? (Et = !0, n in e ? e[n] = i : !0 === i ? e.setAttribute(n, "") : Tt(e, n, i)) : ("function" != typeof t && null !== t && (n in e ? e[n] = null : e.hasAttribute(n) && e.removeAttribute(n)), e.addEventListener(o, i, a))))
		}
		Et = !0
	}

	function Af(e, t, n) {
		switch (t) {
			case "div":
			case "span":
			case "svg":
			case "path":
			case "a":
			case "g":
			case "p":
			case "li":
				break;
			case "img":
				pf("error", e), pf("load", e);
				var i, a = !1,
					o = !1;
				for (i in n)
					if (n.hasOwnProperty(i)) {
						var s = n[i];
						if (null != s) switch (i) {
							case "src":
								a = !0;
								break;
							case "srcSet":
								o = !0;
								break;
							case "children":
							case "dangerouslySetInnerHTML":
								throw Error(r(137, t));
							default:
								Nf(e, t, i, s, n, null)
						}
					} return o && Nf(e, t, "srcSet", n.srcSet, n, null), void (a && Nf(e, t, "src", n.src, n, null));
			case "input":
				pf("invalid", e);
				var l = i = s = o = null,
					u = null,
					c = null;
				for (a in n)
					if (n.hasOwnProperty(a)) {
						var d = n[a];
						if (null != d) switch (a) {
							case "name":
								o = d;
								break;
							case "type":
								s = d;
								break;
							case "checked":
								u = d;
								break;
							case "defaultChecked":
								c = d;
								break;
							case "value":
								i = d;
								break;
							case "defaultValue":
								l = d;
								break;
							case "children":
							case "dangerouslySetInnerHTML":
								if (null != d) throw Error(r(137, t));
								break;
							default:
								Nf(e, t, a, d, n, null)
						}
					} return void Ot(e, i, l, u, c, s, o, !1);
			case "select":
				for (o in pf("invalid", e), a = s = i = null, n)
					if (n.hasOwnProperty(o) && null != (l = n[o])) switch (o) {
						case "value":
							i = l;
							break;
						case "defaultValue":
							s = l;
							break;
						case "multiple":
							a = l;
						default:
							Nf(e, t, o, l, n, null)
					}
				return t = i, n = s, e.multiple = !!a, void (null != t ? Rt(e, !!a, t, !1) : null != n && Rt(e, !!a, n, !0));
			case "textarea":
				for (s in pf("invalid", e), i = o = a = null, n)
					if (n.hasOwnProperty(s) && null != (l = n[s])) switch (s) {
						case "value":
							a = l;
							break;
						case "defaultValue":
							o = l;
							break;
						case "children":
							i = l;
							break;
						case "dangerouslySetInnerHTML":
							if (null != l) throw Error(r(91));
							break;
						default:
							Nf(e, t, s, l, n, null)
					}
				return void It(e, a, o, i);
			case "option":
				for (u in n)
					if (n.hasOwnProperty(u) && null != (a = n[u]))
						if ("selected" === u) e.selected = a && "function" != typeof a && "symbol" != typeof a;
						else Nf(e, t, u, a, n, null);
				return;
			case "dialog":
				pf("beforetoggle", e), pf("toggle", e), pf("cancel", e), pf("close", e);
				break;
			case "iframe":
			case "object":
				pf("load", e);
				break;
			case "video":
			case "audio":
				for (a = 0; a < df.length; a++) pf(df[a], e);
				break;
			case "image":
				pf("error", e), pf("load", e);
				break;
			case "details":
				pf("toggle", e);
				break;
			case "embed":
			case "source":
			case "link":
				pf("error", e), pf("load", e);
			case "area":
			case "base":
			case "br":
			case "col":
			case "hr":
			case "keygen":
			case "meta":
			case "param":
			case "track":
			case "wbr":
			case "menuitem":
				for (c in n)
					if (n.hasOwnProperty(c) && null != (a = n[c])) switch (c) {
						case "children":
						case "dangerouslySetInnerHTML":
							throw Error(r(137, t));
						default:
							Nf(e, t, c, a, n, null)
					}
				return;
			default:
				if ($t(t)) {
					for (d in n) n.hasOwnProperty(d) && (void 0 !== (a = n[d]) && Mf(e, t, d, a, n, void 0));
					return
				}
		}
		for (l in n) n.hasOwnProperty(l) && (null != (a = n[l]) && Nf(e, t, l, a, n, null))
	}
	var _f = {};

	function Lf(e) {
		switch (e) {
			case "css":
			case "script":
			case "font":
			case "img":
			case "image":
			case "input":
			case "link":
				return !0;
			default:
				return !1
		}
	}
	var Df = null,
		jf = null;

	function Of(e) {
		return 9 === e.nodeType ? e : e.ownerDocument
	}

	function zf(e) {
		switch (e) {
			case "http://www.w3.org/2000/svg":
				return 1;
			case "http://www.w3.org/1998/Math/MathML":
				return 2;
			default:
				return 0
		}
	}

	function Rf(e, t) {
		if (0 === e) switch (t) {
			case "svg":
				return 1;
			case "math":
				return 2;
			default:
				return 0
		}
		return 1 === e && "foreignObject" === t ? 0 : e
	}

	function Ff(e, t, n, r) {
		return (n = Of(n).createElement(e))[et] = r, n[tt] = t, Af(n, e, t), pt(n), n
	}

	function If(e, t) {
		return "textarea" === e || "noscript" === e || "string" == typeof t.children || "number" == typeof t.children || "bigint" == typeof t.children || "object" == typeof t.dangerouslySetInnerHTML && null !== t.dangerouslySetInnerHTML && null != t.dangerouslySetInnerHTML.__html
	}
	var Vf = null;
	var Bf = "function" == typeof setTimeout ? setTimeout : void 0,
		Uf = "function" == typeof clearTimeout ? clearTimeout : void 0,
		Hf = "function" == typeof Promise ? Promise : void 0,
		$f = "function" == typeof requestAnimationFrame ? requestAnimationFrame : Bf,
		Wf = "function" == typeof queueMicrotask ? queueMicrotask : typeof Hf < "u" ? function (e) {
			return Hf.resolve(null).then(e).catch(Zf)
		} : Bf;

	function Zf(e) {
		setTimeout(function () {
			throw e
		})
	}

	function Yf(e) {
		return "head" === e
	}

	function qf(e, t) {
		var n = t,
			r = 0;
		do {
			var i = n.nextSibling;
			if (e.removeChild(n), i && 8 === i.nodeType)
				if ("/$" === (n = i.data) || "/&" === n) {
					if (0 === r) return e.removeChild(i), void Hp(t);
					r--
				} else if ("$" === n || "$?" === n || "$~" === n || "$!" === n || "&" === n) r++;
				else if ("html" === n) Lh(e.ownerDocument.documentElement);
				else if ("head" === n) {
					Lh(n = e.ownerDocument.head);
					for (var a = n.firstChild; a;) {
						var o = a.nextSibling,
							s = a.nodeName;
						a[st] || "SCRIPT" === s || "STYLE" === s || "LINK" === s && "stylesheet" === a.rel.toLowerCase() || n.removeChild(a), a = o
					}
				} else "body" === n && Lh(e.ownerDocument.body);
			n = i
		} while (n);
		Hp(t)
	}

	function Kf(e, t) {
		var n = e;
		e = 0;
		do {
			var r = n.nextSibling;
			if (1 === n.nodeType ? t ? (n._stashedDisplay = n.style.display, n.style.display = "none") : (n.style.display = n._stashedDisplay || "", "" === n.getAttribute("style") && n.removeAttribute("style")) : 3 === n.nodeType && (t ? (n._stashedText = n.nodeValue, n.nodeValue = "") : n.nodeValue = n._stashedText || ""), r && 8 === r.nodeType)
				if ("/$" === (n = r.data)) {
					if (0 === e) break;
					e--
				} else "$" !== n && "$?" !== n && "$~" !== n && "$!" !== n || e++;
			n = r
		} while (n)
	}

	function Qf(e, t, n) {
		if (t = CSS.escape(t) !== t ? "r-" + btoa(t).replace(/=/g, "") : t, e.style.viewTransitionName = t, null != n && (e.style.viewTransitionClass = n), "inline" === (n = getComputedStyle(e)).display) {
			if (1 === (t = e.getClientRects()).length) var r = 1;
			else
				for (var i = r = 0; i < t.length; i++) {
					var a = t[i];
					0 < a.width && 0 < a.height && r++
				}
			1 === r && ((e = e.style).display = 1 === t.length ? "inline-block" : "block", e.marginTop = "-" + n.paddingTop, e.marginBottom = "-" + n.paddingBottom)
		}
	}

	function Xf(e, t) {
		e = e.style;
		var n = null != (t = t.style) ? t.hasOwnProperty("viewTransitionName") ? t.viewTransitionName : t.hasOwnProperty("view-transition-name") ? t["view-transition-name"] : null : null;
		e.viewTransitionName = null == n || "boolean" == typeof n ? "" : ("" + n).trim(), n = null != t ? t.hasOwnProperty("viewTransitionClass") ? t.viewTransitionClass : t.hasOwnProperty("view-transition-class") ? t["view-transition-class"] : null : null, e.viewTransitionClass = null == n || "boolean" == typeof n ? "" : ("" + n).trim(), "inline-block" === e.display && (null == t ? e.display = e.margin = "" : (n = t.display, e.display = null == n || "boolean" == typeof n ? "" : n, null != (n = t.margin) ? e.margin = n : (n = t.hasOwnProperty("marginTop") ? t.marginTop : t["margin-top"], e.marginTop = null == n || "boolean" == typeof n ? "" : n, t = t.hasOwnProperty("marginBottom") ? t.marginBottom : t["margin-bottom"], e.marginBottom = null == t || "boolean" == typeof t ? "" : t)))
	}

	function Gf(e) {
		return function (e, t, n) {
			return n = n.ownerDocument.defaultView, {
				rect: e,
				abs: "absolute" === t.position || "fixed" === t.position,
				clip: "none" !== t.clipPath || "visible" !== t.overflow || "none" !== t.filter || "none" !== t.mask || "none" !== t.mask || "0px" !== t.borderRadius,
				view: 0 <= e.bottom && 0 <= e.right && e.top <= n.innerHeight && e.left <= n.innerWidth
			}
		}(e.getBoundingClientRect(), getComputedStyle(e), e)
	}

	function Jf(e) {
		this.addEventListener("load", e), this.addEventListener("error", e)
	}

	function eh(e, t) {
		this._scope = document.documentElement, this._selector = "::view-transition-" + e + "(" + t + ")"
	}

	function th(e) {
		return {
			name: e,
			group: new eh("group", e),
			imagePair: new eh("image-pair", e),
			old: new eh("old", e),
			new: new eh("new", e)
		}
	}

	function nh(e) {
		this._fragmentFiber = e, this._observers = this._eventListeners = null
	}

	function rh(e, t, n, r) {
		return m(e).addEventListener(t, n, r), !1
	}

	function ih(e, t, n, r) {
		return m(e).removeEventListener(t, n, r), !1
	}

	function ah(e) {
		return null != e && "boolean" != typeof e && (!0 === e.once || e.signal instanceof AbortSignal) ? {
			capture: e.capture,
			passive: e.passive
		} : e
	}

	function oh(e) {
		return null == e ? "c=0" : "boolean" == typeof e ? "c=" + (e ? "1" : "0") : "c=" + (e.capture ? "1" : "0")
	}

	function sh(e, t, n, r) {
		if (0 === e.length) return -1;
		r = oh(r);
		for (var i = 0; i < e.length; i++) {
			var a = e[i];
			if (a.type === t && a.listener === n && oh(a.optionsOrUseCapture) === r) return i
		}
		return -1
	}

	function lh(e, t) {
		return 6 !== e.tag && function (e, t) {
			function n() {
				r = !0
			}
			if (e.ownerDocument.activeElement === e) return !0;
			var r = !1;
			try {
				e.ownerDocument.addEventListener("focus", n, !0), (e.focus || HTMLElement.prototype.focus).call(e, t)
			} finally {
				e.ownerDocument.removeEventListener("focus", n, !0)
			}
			return r
		}(e = m(e), t)
	}

	function uh(e, t) {
		return t.push(e), !1
	}

	function ch(e, t) {
		return 6 !== e.tag && (!((e = m(e)) !== t && !e.contains(t)) && (t.blur(), !0))
	}

	function dh(e, t) {
		return 6 === e.tag || (e = m(e), t.observe(e)), !1
	}

	function fh(e, t) {
		return 6 === e.tag || (e = m(e), t.unobserve(e)), !1
	}
	eh.prototype.animate = function (e, t) {
		return (t = "number" == typeof t ? {
			duration: t
		} : S({}, t)).pseudoElement = this._selector, this._scope.animate(e, t)
	}, eh.prototype.getAnimations = function () {
		for (var e = this._scope, t = this._selector, n = e.getAnimations({
			subtree: !0
		}), r = [], i = 0; i < n.length; i++) {
			var a = n[i].effect;
			null !== a && a.target === e && a.pseudoElement === t && r.push(n[i])
		}
		return r
	}, eh.prototype.getComputedStyle = function () {
		return getComputedStyle(this._scope, this._selector)
	}, nh.prototype.addEventListener = function (e, t, n) {
		var r = null,
			i = null;
		if (null == n || "boolean" == typeof n || (null === (r = n.signal || null) || !r.aborted)) {
			null === this._eventListeners && (this._eventListeners = []);
			var a = this._eventListeners;
			if (-1 === sh(a, e, t, n)) {
				var o = this,
					s = t;
				null != n && "boolean" != typeof n && !0 === n.once && (s = function (r) {
					o.removeEventListener(e, t, n), "function" == typeof t ? t.call(this, r) : t.handleEvent(r)
				}), null !== r && (i = o.removeEventListener.bind(o, e, t, n), r.addEventListener("abort", i, {
					once: !0
				}), i = r.removeEventListener.bind(r, "abort", i)), r = ah(n), a.push({
					type: e,
					listener: t,
					optionsOrUseCapture: n,
					attachedListener: s,
					cleanup: i
				}), c(this._fragmentFiber.child, !1, rh, e, s, r)
			}
			this._eventListeners = a
		}
	}, nh.prototype.removeEventListener = function (e, t, n) {
		var r = this._eventListeners;
		if (null !== r && -1 !== (t = sh(r, e, t, n))) {
			var i = r[t];
			n = i.attachedListener;
			var a = i.cleanup;
			i = ah(i.optionsOrUseCapture), c(this._fragmentFiber.child, !1, ih, e, n, i), r.splice(t, 1), null !== a && a()
		}
	}, nh.prototype.dispatchEvent = function (e) {
		var t = d(this._fragmentFiber);
		if (null === t) return !0;
		t = m(t);
		var n = this._eventListeners;
		if (null !== n && 0 < n.length || !e.bubbles) {
			var r = 9 === t.nodeType ? t.createComment("") : document.createTextNode("");
			if (n)
				for (var i = 0; i < n.length; i++) {
					var a = n[i];
					r.addEventListener(a.type, a.attachedListener, ah(a.optionsOrUseCapture))
				}
			if (t.appendChild(r), e = r.dispatchEvent(e), n)
				for (i = 0; i < n.length; i++) a = n[i], r.removeEventListener(a.type, a.attachedListener, ah(a.optionsOrUseCapture));
			return t.removeChild(r), e
		}
		return t.dispatchEvent(e)
	}, nh.prototype.focus = function (e) {
		c(this._fragmentFiber.child, !0, lh, e, void 0, void 0)
	}, nh.prototype.focusLast = function (e) {
		var t = [];
		c(this._fragmentFiber.child, !0, uh, t, void 0, void 0);
		for (var n = t.length - 1; 0 <= n && !lh(t[n], e); n--);
	}, nh.prototype.blur = function () {
		var e = d(this._fragmentFiber);
		null !== e && (null !== (e = Of(e = m(e)).activeElement) && c(this._fragmentFiber.child, !1, ch, e, void 0, void 0))
	}, nh.prototype.observeUsing = function (e) {
		null === this._observers && (this._observers = new Set), this._observers.add(e), c(this._fragmentFiber.child, !1, dh, e, void 0, void 0)
	}, nh.prototype.unobserveUsing = function (e) {
		var t = this._observers;
		if (null !== t && t.has(e)) {
			t.delete(e), c(this._fragmentFiber.child, !1, fh, e, void 0, void 0);
			for (var n = t = 0; n < hh.length; n++) {
				var r = hh[n];
				r.fragmentInstance === this && r.observer === e ? e.unobserve(r.instance) : hh[t++] = r
			}
			hh.length = t
		}
	};
	var hh = [],
		ph = !1;

	function mh(e, t, n) {
		hh.push({
			fragmentInstance: e,
			observer: t,
			instance: n
		}), ph || (ph = !0, function (e) {
			$f(function () {
				$f(function (t) {
					return e(t)
				})
			})
		}(function () {
			ph = !1;
			var e = hh;
			hh = [];
			for (var t = 0; t < e.length; t++) {
				var n = e[t];
				n.observer.unobserve(n.instance)
			}
		}))
	}

	function gh(e, t) {
		if (6 === e.tag) {
			var n = (e = e.stateNode).ownerDocument.createRange();
			n.selectNodeContents(e), t.push.apply(t, n.getClientRects())
		} else e = m(e), t.push.apply(t, e.getClientRects());
		return !1
	}

	function vh(e, t) {
		var n = e.ownerDocument.createRange();
		n.selectNodeContents(e), e = n.getBoundingClientRect(), window.scrollTo(window.scrollX + e.left, t ? window.scrollY + e.top : window.scrollY + e.bottom - window.innerHeight)
	}

	function yh(e, t) {
		return bh(e = m(e), t), !1
	}

	function bh(e, t) {
		null == e.reactFragments && (e.reactFragments = new Set), e.reactFragments.add(t)
	}

	function xh(e, t) {
		var n = t._eventListeners;
		if (null !== n)
			for (var r = 0; r < n.length; r++) {
				var i = n[r];
				e.addEventListener(i.type, i.attachedListener, ah(i.optionsOrUseCapture))
			}
		3 !== e.nodeType && (null !== (n = t._observers) && n.forEach(function (n) {
			for (var r = 0, i = 0; i < hh.length; i++) {
				var a = hh[i];
				(a.fragmentInstance !== t || a.observer !== n || a.instance !== e) && (hh[r++] = a)
			}
			hh.length = r, n.observe(e)
		}), bh(e, t))
	}

	function wh(e, t) {
		var n = t._eventListeners;
		if (null !== n)
			for (var r = 0; r < n.length; r++) {
				var i = n[r];
				e.removeEventListener(i.type, i.attachedListener, ah(i.optionsOrUseCapture))
			}
		3 !== e.nodeType && (null !== (n = t._observers) && n.forEach(function (n) {
			"string" == typeof n.rootMargin ? mh(t, n, e) : n.unobserve(e)
		}), null != e.reactFragments && e.reactFragments.delete(t))
	}

	function Sh(e) {
		var t = e.firstChild;
		for (t && 10 === t.nodeType && (t = t.nextSibling); t;) {
			var n = t;
			switch (t = t.nextSibling, n.nodeName) {
				case "HTML":
				case "HEAD":
				case "BODY":
					Sh(n), ut(n);
					continue;
				case "SCRIPT":
				case "STYLE":
					continue;
				case "LINK":
					if ("stylesheet" === n.rel.toLowerCase()) continue
			}
			e.removeChild(n)
		}
	}

	function Eh(e, t) {
		for (; 8 !== e.nodeType;)
			if ((1 !== e.nodeType || "INPUT" !== e.nodeName || "hidden" !== e.type) && !t || null === (e = Ph(e.nextSibling))) return null;
		return e
	}

	function kh(e) {
		return "$?" === e.data || "$~" === e.data
	}

	function Th(e) {
		return "$!" === e.data || "$?" === e.data && "loading" !== e.ownerDocument.readyState
	}

	function Ph(e) {
		for (; null != e; e = e.nextSibling) {
			var t = e.nodeType;
			if (1 === t || 3 === t) break;
			if (8 === t) {
				if ("$" === (t = e.data) || "$!" === t || "$?" === t || "$~" === t || "&" === t || "F!" === t || "F" === t) break;
				if ("/$" === t || "/&" === t) return null
			}
		}
		return e
	}
	nh.prototype.getClientRects = function () {
		var e = [];
		return c(this._fragmentFiber.child, !1, gh, e, void 0, void 0), e
	}, nh.prototype.getRootNode = function (e) {
		var t = d(this._fragmentFiber);
		return null === t ? this : m(t).getRootNode(e)
	}, nh.prototype.compareDocumentPosition = function (e) {
		var t = d(this._fragmentFiber);
		if (null === t) return Node.DOCUMENT_POSITION_DISCONNECTED;
		var n = [];
		c(this._fragmentFiber.child, !1, uh, n, void 0, void 0);
		var r = m(t);
		if (0 === n.length) {
			if (n = r, f(this._fragmentFiber)) {
				e: {
					for (t = this._fragmentFiber.return; null !== t;) {
						if (4 === t.tag) {
							t = t.stateNode.containerInfo;
							break e
						}
						if (3 === t.tag || 5 === t.tag || 27 === t.tag) break;
						t = t.return
					}
					t = null
				}
				null != t && (n = t)
			}
			t = this._fragmentFiber;
			var i = r = n.compareDocumentPosition(e);
			return n === e ? i = Node.DOCUMENT_POSITION_CONTAINS : r & Node.DOCUMENT_POSITION_CONTAINED_BY && (null === (n = h(t)[1]) ? i = Node.DOCUMENT_POSITION_PRECEDING : i = 0 === (e = m(n).compareDocumentPosition(e)) || e & Node.DOCUMENT_POSITION_FOLLOWING ? Node.DOCUMENT_POSITION_FOLLOWING : Node.DOCUMENT_POSITION_PRECEDING), i | Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC
		}
		t = m(n[0]), i = m(n[n.length - 1]);
		var a = f(this._fragmentFiber) ? t.parentElement : r;
		if (null == a) return Node.DOCUMENT_POSITION_DISCONNECTED;
		r = a.compareDocumentPosition(t) & Node.DOCUMENT_POSITION_CONTAINED_BY, a = a.compareDocumentPosition(i) & Node.DOCUMENT_POSITION_CONTAINED_BY;
		var o = t.compareDocumentPosition(e),
			s = i.compareDocumentPosition(e),
			l = o & Node.DOCUMENT_POSITION_CONTAINED_BY || s & Node.DOCUMENT_POSITION_CONTAINED_BY;
		return s = r && a && o & Node.DOCUMENT_POSITION_FOLLOWING && s & Node.DOCUMENT_POSITION_PRECEDING, (t = r && t === e || a && i === e || l || s ? Node.DOCUMENT_POSITION_CONTAINED_BY : !r && t === e || !a && i === e ? Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC : o) & Node.DOCUMENT_POSITION_DISCONNECTED || t & Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC || function (e, t, n, r, i) {
			var a = ct(i);
			if (e & Node.DOCUMENT_POSITION_CONTAINED_BY) {
				if (n = !!a) e: {
					for (; null !== a;) {
						if (7 === a.tag && (a === t || a.alternate === t)) {
							n = !0;
							break e
						}
						a = a.return
					}
					n = !1
				}
				return n
			}
			if (e & Node.DOCUMENT_POSITION_CONTAINS) {
				if (null === a) return i === (a = i.ownerDocument) || i === a.documentElement || i === a.body;
				e: {
					for (a = t, t = d(t); null !== a;) {
						if (!(5 !== a.tag && 3 !== a.tag && 27 !== a.tag || a !== t && a.alternate !== t)) {
							a = !0;
							break e
						}
						a = a.return
					}
					a = !1
				}
				return a
			}
			return e & Node.DOCUMENT_POSITION_PRECEDING ? ((t = !!a) && !(t = a === n) && (t = w(n, a, x), null === t ? t = !1 : (c(t, !0, y, a, n), a = g, g = null, t = null !== a)), t) : !!(e & Node.DOCUMENT_POSITION_FOLLOWING) && ((t = !!a) && !(t = a === r) && (t = w(r, a, x), null === t ? t = !1 : (c(t, !0, b, a, r), a = g, v = g = null, t = null !== a)), t)
		}(t, this._fragmentFiber, n[0], n[n.length - 1], e) ? t : Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC
	}, nh.prototype.scrollIntoView = function (e) {
		if ("object" == typeof e) throw Error(r(566));
		var t = [];
		c(this._fragmentFiber.child, !1, uh, t, void 0, void 0);
		var n = !1 !== e;
		if (0 === t.length) {
			var i = h(this._fragmentFiber);
			if (null === (i = n ? i[1] || i[0] || d(this._fragmentFiber) : i[0] || i[1])) return;
			if (6 === i.tag) return void vh(e = m(i), n);
			if (9 !== (i = m(i)).nodeType) {
				if (11 === i.nodeType) return void (null !== (n = "host" in i ? i.host : null) && n.scrollIntoView(e));
				i.scrollIntoView(e)
			}
		}
		for (i = n ? t.length - 1 : 0; i !== (n ? -1 : t.length);) {
			var a = t[i];
			6 === a.tag ? vh(a = m(a), n) : m(a).scrollIntoView(e), i += n ? -1 : 1
		}
	};
	var Ch = null;

	function Nh(e) {
		e = e.nextSibling;
		for (var t = 0; e;) {
			if (8 === e.nodeType) {
				var n = e.data;
				if ("/$" === n || "/&" === n) {
					if (0 === t) return Ph(e.nextSibling);
					t--
				} else "$" !== n && "$!" !== n && "$?" !== n && "$~" !== n && "&" !== n || t++
			}
			e = e.nextSibling
		}
		return null
	}

	function Mh(e) {
		e = e.previousSibling;
		for (var t = 0; e;) {
			if (8 === e.nodeType) {
				var n = e.data;
				if ("$" === n || "$!" === n || "$?" === n || "$~" === n || "&" === n) {
					if (0 === t) return e;
					t--
				} else "/$" !== n && "/&" !== n || t++
			}
			e = e.previousSibling
		}
		return null
	}

	function Ah(e, t, n) {
		switch (t = Of(n), e) {
			case "html":
				if (!(e = t.documentElement)) throw Error(r(452));
				return e;
			case "head":
				if (!(e = t.head)) throw Error(r(453));
				return e;
			case "body":
				if (!(e = t.body)) throw Error(r(454));
				return e;
			default:
				throw Error(r(451))
		}
	}

	function _h(e, t, n) {
		for (var r in n) {
			var i = n[r];
			n.hasOwnProperty(r) && null != i && Nf(e, t, r, null, _f, i)
		}
		null != n.dangerouslySetInnerHTML && (e.textContent = ""), e.onclick === qt && (e.onclick = null), ut(e)
	}

	function Lh(e) {
		for (var t = e.attributes; t.length;) e.removeAttributeNode(t[0]);
		ut(e)
	}
	var Dh = new Map,
		jh = new Set;

	function Oh(e) {
		if ("function" == typeof e.getRootNode) {
			var t = e.getRootNode();
			if (9 === t.nodeType || 11 === t.nodeType) return t
		}
		return 9 === e.nodeType ? e : e.ownerDocument
	}
	var zh = Y.d;
	Y.d = {
		f: function () {
			var e = zh.f(),
				t = pd();
			return e || t
		},
		r: function (e) {
			var t = dt(e);
			null !== t && 5 === t.tag && "form" === t.type ? As(t) : zh.r(e)
		},
		D: function (e) {
			zh.D(e), Fh("dns-prefetch", e, null)
		},
		C: function (e, t) {
			zh.C(e, t), Fh("preconnect", e, t)
		},
		L: function (e, t, n) {
			zh.L(e, t, n);
			var r = Rh;
			if (r && e && t) {
				var i = 'link[rel="preload"][as="' + Dt(t) + '"]';
				"image" === t && n && n.imageSrcSet ? (i += '[imagesrcset="' + Dt(n.imageSrcSet) + '"]', "string" == typeof n.imageSizes && (i += '[imagesizes="' + Dt(n.imageSizes) + '"]')) : i += '[href="' + Dt(e) + '"]';
				var a = i;
				switch (t) {
					case "style":
						a = Vh(e);
						break;
					case "script":
						a = Hh(e)
				}
				if (!(Dh.has(a) || (e = S({
					rel: "preload",
					href: "image" === t && n && n.imageSrcSet ? void 0 : e,
					as: t
				}, n), Dh.set(a, e), null !== r.querySelector(i) || "style" === t && r.querySelector(Bh(a)) || "script" === t && r.querySelector($h(a))))) {
					var o = r.createElement("link");
					Af(o, "link", e), "style" === t && (o[lt] = !0, o.onload = o.onerror = function () {
						mt(o)
					}), pt(o), r.head.appendChild(o)
				}
			}
		},
		m: function (e, t) {
			zh.m(e, t);
			var n = Rh;
			if (n && e) {
				var r = t && "string" == typeof t.as ? t.as : "script",
					i = 'link[rel="modulepreload"][as="' + Dt(r) + '"][href="' + Dt(e) + '"]',
					a = i;
				switch (r) {
					case "audioworklet":
					case "paintworklet":
					case "serviceworker":
					case "sharedworker":
					case "worker":
					case "script":
						a = Hh(e)
				}
				if (!Dh.has(a) && (e = S({
					rel: "modulepreload",
					href: e
				}, t), Dh.set(a, e), null === n.querySelector(i))) {
					switch (r) {
						case "audioworklet":
						case "paintworklet":
						case "serviceworker":
						case "sharedworker":
						case "worker":
						case "script":
							if (n.querySelector($h(a))) return
					}
					Af(r = n.createElement("link"), "link", e), pt(r), n.head.appendChild(r)
				}
			}
		},
		X: function (e, t) {
			zh.X(e, t);
			var n = Rh;
			if (n && e) {
				var r = ht(n).hoistableScripts,
					i = Hh(e),
					a = r.get(i);
				a || ((a = n.querySelector($h(i))) || (e = S({
					src: e,
					async: !0
				}, t), (t = Dh.get(i)) && qh(e, t), pt(a = n.createElement("script")), Af(a, "link", e), n.head.appendChild(a)), a = {
					type: "script",
					instance: a,
					count: 1,
					state: null
				}, r.set(i, a))
			}
		},
		S: function (e, t, n) {
			zh.S(e, t, n);
			var r = Rh;
			if (r && e) {
				var i = ht(r).hoistableStyles,
					a = Vh(e);
				t = t || "default";
				var o = i.get(a);
				if (!o) {
					var s = {
						loading: 0,
						preload: null
					};
					if (o = r.querySelector(Bh(a))) s.loading = 5;
					else {
						e = S({
							rel: "stylesheet",
							href: e,
							"data-precedence": t
						}, n), (n = Dh.get(a)) && Yh(e, n);
						var l = o = r.createElement("link");
						pt(l), Af(l, "link", e), l._p = new Promise(function (e, t) {
							l.onload = e, l.onerror = t
						}), l.addEventListener("load", function () {
							s.loading |= 1
						}), l.addEventListener("error", function () {
							s.loading |= 2
						}), s.loading |= 4, Zh(o, t, r)
					}
					o = {
						type: "stylesheet",
						instance: o,
						count: 1,
						state: s
					}, i.set(a, o)
				}
			}
		},
		M: function (e, t) {
			zh.M(e, t);
			var n = Rh;
			if (n && e) {
				var r = ht(n).hoistableScripts,
					i = Hh(e),
					a = r.get(i);
				a || ((a = n.querySelector($h(i))) || (e = S({
					src: e,
					async: !0,
					type: "module"
				}, t), (t = Dh.get(i)) && qh(e, t), pt(a = n.createElement("script")), Af(a, "link", e), n.head.appendChild(a)), a = {
					type: "script",
					instance: a,
					count: 1,
					state: null
				}, r.set(i, a))
			}
		}
	};
	var Rh = typeof document > "u" ? null : document;

	function Fh(e, t, n) {
		var r = Rh;
		if (r && "string" == typeof t && t) {
			var i = Dt(t);
			i = 'link[rel="' + e + '"][href="' + i + '"]', "string" == typeof n && (i += '[crossorigin="' + n + '"]'), jh.has(i) || (jh.add(i), e = {
				rel: e,
				crossOrigin: n,
				href: t
			}, null === r.querySelector(i) && (Af(t = r.createElement("link"), "link", e), pt(t), r.head.appendChild(t)))
		}
	}

	function Ih(e, t, n, i) {
		var a = (a = ie.current) ? Oh(a) : null;
		if (!a) throw Error(r(446));
		switch (e) {
			case "meta":
			case "title":
				return null;
			case "style":
				return "string" == typeof n.precedence && "string" == typeof n.href ? (n = Vh(n.href), (i = (t = ht(a).hoistableStyles).get(n)) || (i = {
					type: "style",
					instance: null,
					count: 0,
					state: null
				}, t.set(n, i)), i) : {
					type: "void",
					instance: null,
					count: 0,
					state: null
				};
			case "link":
				if ("stylesheet" === n.rel && "string" == typeof n.href && "string" == typeof n.precedence) {
					e = Vh(n.href);
					var o = ht(a).hoistableStyles,
						s = o.get(e);
					if (s || (a = a.ownerDocument || a, s = {
						type: "stylesheet",
						instance: null,
						count: 0,
						state: {
							loading: 0,
							preload: null
						}
					}, o.set(e, s), (o = a.querySelector(Bh(e))) ? o._p || (s.instance = o, s.state.loading = 5) : ((o = Dh.get(e)) || (o = {
						rel: "preload",
						as: "style",
						href: n.href,
						crossOrigin: n.crossOrigin,
						integrity: n.integrity,
						media: n.media,
						hrefLang: n.hrefLang,
						referrerPolicy: n.referrerPolicy
					}, Dh.set(e, o)), function (e, t, n, r) {
						if (t = e.querySelector('link[rel="preload"][as="style"][' + t + "]")) {
							if (!0 !== t[lt]) return void (r.loading = 1)
						} else t = e.createElement("link"), t[lt] = !0, t.onload = t.onerror = mt.bind(null, t), Af(t, "link", n), pt(t), e.head.appendChild(t);
						r.preload = t, t.addEventListener("load", function () {
							return r.loading |= 1
						}), t.addEventListener("error", function () {
							return r.loading |= 2
						})
					}(a, e, o, s.state))), t && null === i) throw Error(r(528, ""));
					return s
				}
				if (t && null !== i) throw Error(r(529, ""));
				return null;
			case "script":
				return t = n.async, "string" == typeof (n = n.src) && t && "function" != typeof t && "symbol" != typeof t ? (n = Hh(n), (i = (t = ht(a).hoistableScripts).get(n)) || (i = {
					type: "script",
					instance: null,
					count: 0,
					state: null
				}, t.set(n, i)), i) : {
					type: "void",
					instance: null,
					count: 0,
					state: null
				};
			default:
				throw Error(r(444, e))
		}
	}

	function Vh(e) {
		return 'href="' + Dt(e) + '"'
	}

	function Bh(e) {
		return 'link[rel="stylesheet"][' + e + "]"
	}

	function Uh(e) {
		return S({}, e, {
			"data-precedence": e.precedence,
			precedence: null
		})
	}

	function Hh(e) {
		return '[src="' + Dt(e) + '"]'
	}

	function $h(e) {
		return "script[async]" + e
	}

	function Wh(e, t, n) {
		if (t.count++, null === t.instance) switch (t.type) {
			case "style":
				var i = e.querySelector('style[data-href~="' + Dt(n.href) + '"]');
				if (i) return t.instance = i, pt(i), i;
				var a = S({}, n, {
					"data-href": n.href,
					"data-precedence": n.precedence,
					href: null,
					precedence: null
				});
				return pt(i = (e.ownerDocument || e).createElement("style")), Af(i, "style", a), Zh(i, n.precedence, e), t.instance = i;
			case "stylesheet":
				a = Vh(n.href);
				var o = e.querySelector(Bh(a));
				if (o) return t.state.loading |= 4, t.instance = o, pt(o), o;
				i = Uh(n), (a = Dh.get(a)) && Yh(i, a), pt(o = (e.ownerDocument || e).createElement("link"));
				var s = o;
				return s._p = new Promise(function (e, t) {
					s.onload = e, s.onerror = t
				}), Af(o, "link", i), t.state.loading |= 4, Zh(o, n.precedence, e), t.instance = o;
			case "script":
				return o = Hh(n.src), (a = e.querySelector($h(o))) ? (t.instance = a, pt(a), a) : (i = n, (a = Dh.get(o)) && qh(i = S({}, n), a), pt(a = (e = e.ownerDocument || e).createElement("script")), Af(a, "link", i), e.head.appendChild(a), t.instance = a);
			case "void":
				return null;
			default:
				throw Error(r(443, t.type))
		} else "stylesheet" === t.type && !(4 & t.state.loading) && (i = t.instance, t.state.loading |= 4, Zh(i, n.precedence, e));
		return t.instance
	}

	function Zh(e, t, n) {
		for (var r = n.querySelectorAll('link[rel="stylesheet"][data-precedence],style[data-precedence]'), i = r.length ? r[r.length - 1] : null, a = i, o = 0; o < r.length; o++) {
			var s = r[o];
			if (s.dataset.precedence === t) a = s;
			else if (a !== i) break
		}
		a ? a.parentNode.insertBefore(e, a.nextSibling) : (t = 9 === n.nodeType ? n.head : n).insertBefore(e, t.firstChild)
	}

	function Yh(e, t) {
		null == e.crossOrigin && (e.crossOrigin = t.crossOrigin), null == e.referrerPolicy && (e.referrerPolicy = t.referrerPolicy), null == e.title && (e.title = t.title)
	}

	function qh(e, t) {
		null == e.crossOrigin && (e.crossOrigin = t.crossOrigin), null == e.referrerPolicy && (e.referrerPolicy = t.referrerPolicy), null == e.integrity && (e.integrity = t.integrity)
	}
	var Kh = null;

	function Qh(e, t, n) {
		if (null === Kh) {
			var r = new Map,
				i = Kh = new Map;
			i.set(n, r)
		} else (r = (i = Kh).get(n)) || (r = new Map, i.set(n, r));
		if (r.has(e)) return r;
		for (r.set(e, null), n = n.getElementsByTagName(e), i = 0; i < n.length; i++) {
			var a = n[i];
			if (!(a[st] || a[et] || "link" === e && "stylesheet" === a.getAttribute("rel")) && "http://www.w3.org/2000/svg" !== a.namespaceURI) {
				var o = a.getAttribute(t) || "";
				o = e + o;
				var s = r.get(o);
				s ? s.push(a) : r.set(o, [a])
			}
		}
		return r
	}

	function Xh(e, t, n) {
		(e = e.ownerDocument || e).head.insertBefore(n, "title" === t ? e.querySelector("head > title") : null)
	}

	function Gh(e, t) {
		return "img" === e && null != t.src && "" !== t.src && null == t.onLoad && "lazy" !== t.loading
	}

	function Jh(e) {
		return !("stylesheet" === e.type && !(3 & e.state.loading))
	}

	function ep(e) {
		return (e.width || 100) * (e.height || 100) * ("number" == typeof devicePixelRatio ? devicePixelRatio : 1) * .25
	}

	function tp(e, t) {
		"function" == typeof t.decode && (e.imgCount++, t.complete || (e.imgBytes += ep(t), e.suspenseyImages.push(t)), e = ap.bind(e), t.decode().then(e, e))
	}
	var np = 0;

	function rp(e) {
		if (0 === e.count && (0 === e.imgCount || !e.waitingForImages))
			if (e.stylesheets) sp(e, e.stylesheets);
			else if (e.unsuspend) {
				var t = e.unsuspend;
				e.unsuspend = null, t()
			}
	}

	function ip() {
		this.count--, rp(this)
	}

	function ap() {
		this.imgCount--, rp(this)
	}
	var op = null;

	function sp(e, t) {
		e.stylesheets = null, null !== e.unsuspend && (e.count++, op = new Map, t.forEach(lp, e), op = null, ip.call(e))
	}

	function lp(e, t) {
		if (!(4 & t.state.loading)) {
			var n = op.get(e);
			if (n) var r = n.get(null);
			else {
				n = new Map, op.set(e, n);
				for (var i = e.querySelectorAll("link[data-precedence],style[data-precedence]"), a = 0; a < i.length; a++) {
					var o = i[a];
					("LINK" === o.nodeName || "not all" !== o.getAttribute("media")) && (n.set(o.dataset.precedence, o), r = o)
				}
				r && n.set(null, r)
			}
			o = (i = t.instance).getAttribute("data-precedence"), (a = n.get(o) || r) === r && n.set(null, i), n.set(o, i), this.count++, r = ip.bind(this), i.addEventListener("load", r), i.addEventListener("error", r), a ? a.parentNode.insertBefore(i, a.nextSibling) : (e = 9 === e.nodeType ? e.head : e).insertBefore(i, e.firstChild), t.state.loading |= 4
		}
	}
	var up = {
		$$typeof: A,
		Provider: null,
		Consumer: null,
		_currentValue: q,
		_currentValue2: q,
		_threadCount: 0
	};

	function cp(e, t, n, r, i, a, o, s, l) {
		this.tag = 1, this.containerInfo = e, this.pingCache = this.current = this.pendingChildren = null, this.timeoutHandle = -1, this.callbackNode = this.next = this.pendingContext = this.context = this.cancelPendingCommit = null, this.callbackPriority = 0, this.expirationTimes = $e(-1), this.entangledLanes = this.shellSuspendCounter = this.errorRecoveryDisabledLanes = this.expiredLanes = this.warmLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0, this.entanglements = $e(0), this.hiddenUpdates = $e(null), this.identifierPrefix = r, this.onUncaughtError = i, this.onCaughtError = a, this.onRecoverableError = o, this.pooledCache = null, this.pooledCacheLanes = 0, this.formState = l, this.transitionTypes = null, this.incompleteTransitions = new Map
	}

	function dp(e, t, n, r, i, a, o, s, l, u, c, d) {
		return e = new cp(e, t, n, o, l, u, c, d, s), t = 1, !0 === a && (t |= 24), a = oi(3, null, null, t), e.current = a, a.stateNode = e, (t = sa()).refCount++, e.pooledCache = t, t.refCount++, a.memoizedState = {
			element: r,
			isDehydrated: n,
			cache: t
		}, Va(a), e
	}

	function fp(e) {
		return e ? e = ii : ii
	}

	function hp(e, t, n, r, i, a) {
		i = fp(i), null === r.context ? r.context = i : r.pendingContext = i, (r = Ua(t)).payload = {
			element: n
		}, null !== (a = void 0 === a ? null : a) && (r.callback = a), null !== (n = Ha(e, r, t)) && (ud(n, 0, t), $a(n, e, t))
	}

	function pp(e, t) {
		if (null !== (e = e.memoizedState) && null !== e.dehydrated) {
			var n = e.retryLane;
			e.retryLane = 0 !== n && n < t ? n : t
		}
	}

	function mp(e, t) {
		pp(e, t), (e = e.alternate) && pp(e, t)
	}

	function gp(e) {
		if (13 === e.tag || 31 === e.tag) {
			var t = ti(e, 67108864);
			null !== t && ud(t, 0, 67108864), mp(e, 67108864)
		}
	}

	function vp(e) {
		if (13 === e.tag || 31 === e.tag) {
			var t = od(),
				n = ti(e, t = Ke(t));
			null !== n && ud(n, 0, t), mp(e, t)
		}
	}
	var yp = !0;

	function bp(e, t, n, r) {
		var i = Z.T;
		Z.T = null;
		var a = Y.p;
		try {
			Y.p = 2, wp(e, t, n, r)
		} finally {
			Y.p = a, Z.T = i
		}
	}

	function xp(e, t, n, r) {
		var i = Z.T;
		Z.T = null;
		var a = Y.p;
		try {
			Y.p = 8, wp(e, t, n, r)
		} finally {
			Y.p = a, Z.T = i
		}
	}

	function wp(e, t, n, r) {
		if (yp) {
			var i = Sp(r);
			if (null === i) bf(e, t, r, Ep, n), jp(e, r);
			else if (function (e, t, n, r, i) {
				switch (t) {
					case "focusin":
						return Cp = Op(Cp, e, t, n, r, i), !0;
					case "dragenter":
						return Np = Op(Np, e, t, n, r, i), !0;
					case "mouseover":
						return Mp = Op(Mp, e, t, n, r, i), !0;
					case "pointerover":
						var a = i.pointerId;
						return Ap.set(a, Op(Ap.get(a) || null, e, t, n, r, i)), !0;
					case "gotpointercapture":
						return a = i.pointerId, _p.set(a, Op(_p.get(a) || null, e, t, n, r, i)), !0
				}
				return !1
			}(i, e, t, n, r)) r.stopPropagation();
			else if (jp(e, r), 4 & t && -1 < Dp.indexOf(e)) {
				for (; null !== i;) {
					var a = dt(i);
					if (null !== a) switch (a.tag) {
						case 3:
							if ((a = a.stateNode).current.memoizedState.isDehydrated) {
								var o = Fe(a.pendingLanes);
								if (0 !== o) {
									var s = a;
									for (s.pendingLanes |= 2, s.entangledLanes |= 2; o;) {
										var l = 1 << 31 - Le(o);
										s.entanglements[1] |= l, o &= ~l
									}
									Jd(a), !(6 & kc) && (Wc = xe() + 500, ef(0))
								}
							}
							break;
						case 31:
						case 13:
							null !== (s = ti(a, 2)) && ud(s, 0, 2), pd(), mp(a, 2)
					}
					if (null === (a = Sp(r)) && bf(e, t, r, Ep, n), a === i) break;
					i = a
				}
				null !== i && r.stopPropagation()
			} else bf(e, t, r, null, n)
		}
	}

	function Sp(e) {
		return kp(e = Qt(e))
	}
	var Ep = null;

	function kp(e) {
		if (Ep = null, null !== (e = ct(e))) {
			var t = a(e);
			if (null === t) e = null;
			else {
				var n = t.tag;
				if (13 === n) {
					if (null !== (e = o(t))) return e;
					e = null
				} else if (31 === n) {
					if (null !== (e = s(t))) return e;
					e = null
				} else if (3 === n) {
					if (t.stateNode.current.memoizedState.isDehydrated) return 3 === t.tag ? t.stateNode.containerInfo : null;
					e = null
				} else t !== e && (e = null)
			}
		}
		return Ep = e, null
	}

	function Tp(e) {
		switch (e) {
			case "beforetoggle":
			case "cancel":
			case "click":
			case "close":
			case "contextmenu":
			case "copy":
			case "cut":
			case "auxclick":
			case "dblclick":
			case "dragend":
			case "dragstart":
			case "drop":
			case "focusin":
			case "focusout":
			case "input":
			case "invalid":
			case "keydown":
			case "keypress":
			case "keyup":
			case "mousedown":
			case "mouseup":
			case "paste":
			case "pause":
			case "play":
			case "pointercancel":
			case "pointerdown":
			case "pointerup":
			case "ratechange":
			case "reset":
			case "seeked":
			case "submit":
			case "toggle":
			case "touchcancel":
			case "touchend":
			case "touchstart":
			case "volumechange":
			case "change":
			case "selectionchange":
			case "textInput":
			case "compositionstart":
			case "compositionend":
			case "compositionupdate":
			case "beforeblur":
			case "afterblur":
			case "beforeinput":
			case "blur":
			case "fullscreenchange":
			case "fullscreenerror":
			case "focus":
			case "hashchange":
			case "popstate":
			case "select":
			case "selectstart":
				return 2;
			case "drag":
			case "dragenter":
			case "dragexit":
			case "dragleave":
			case "dragover":
			case "mousemove":
			case "mouseout":
			case "mouseover":
			case "pointermove":
			case "pointerout":
			case "pointerover":
			case "resize":
			case "scroll":
			case "touchmove":
			case "wheel":
			case "mouseenter":
			case "mouseleave":
			case "pointerenter":
			case "pointerleave":
				return 8;
			case "message":
				switch (we()) {
					case Se:
						return 2;
					case Ee:
						return 8;
					case ke:
					case Te:
						return 32;
					case Pe:
						return 268435456;
					default:
						return 32
				}
			default:
				return 32
		}
	}
	var Pp = !1,
		Cp = null,
		Np = null,
		Mp = null,
		Ap = new Map,
		_p = new Map,
		Lp = [],
		Dp = "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(" ");

	function jp(e, t) {
		switch (e) {
			case "focusin":
			case "focusout":
				Cp = null;
				break;
			case "dragenter":
			case "dragleave":
				Np = null;
				break;
			case "mouseover":
			case "mouseout":
				Mp = null;
				break;
			case "pointerover":
			case "pointerout":
				Ap.delete(t.pointerId);
				break;
			case "gotpointercapture":
			case "lostpointercapture":
				_p.delete(t.pointerId)
		}
	}

	function Op(e, t, n, r, i, a) {
		return null === e || e.nativeEvent !== a ? (e = {
			blockedOn: t,
			domEventName: n,
			eventSystemFlags: r,
			nativeEvent: a,
			targetContainers: [i]
		}, null !== t && (null !== (t = dt(t)) && gp(t)), e) : (e.eventSystemFlags |= r, t = e.targetContainers, null !== i && -1 === t.indexOf(i) && t.push(i), e)
	}

	function zp(e) {
		var t = ct(e.target);
		if (null !== t) {
			var n = a(t);
			if (null !== n)
				if (13 === (t = n.tag)) {
					if (null !== (t = o(n))) return e.blockedOn = t, void Ge(e.priority, function () {
						vp(n)
					})
				} else if (31 === t) {
					if (null !== (t = s(n))) return e.blockedOn = t, void Ge(e.priority, function () {
						vp(n)
					})
				} else if (3 === t && n.stateNode.current.memoizedState.isDehydrated) return void (e.blockedOn = 3 === n.tag ? n.stateNode.containerInfo : null)
		}
		e.blockedOn = null
	}

	function Rp(e) {
		if (null !== e.blockedOn) return !1;
		for (var t = e.targetContainers; 0 < t.length;) {
			var n = Sp(e.nativeEvent);
			if (null !== n) return null !== (t = dt(n)) && gp(t), e.blockedOn = n, !1;
			var r = new (n = e.nativeEvent).constructor(n.type, n);
			Kt = r, n.target.dispatchEvent(r), Kt = null, t.shift()
		}
		return !0
	}

	function Fp(e, t, n) {
		Rp(e) && n.delete(t)
	}

	function Ip() {
		Pp = !1, null !== Cp && Rp(Cp) && (Cp = null), null !== Np && Rp(Np) && (Np = null), null !== Mp && Rp(Mp) && (Mp = null), Ap.forEach(Fp), _p.forEach(Fp)
	}

	function Vp(t, n) {
		t.blockedOn === n && (t.blockedOn = null, Pp || (Pp = !0, e.unstable_scheduleCallback(e.unstable_NormalPriority, Ip)))
	}
	var Bp = null;

	function Up(t) {
		Bp !== t && (Bp = t, e.unstable_scheduleCallback(e.unstable_NormalPriority, function () {
			Bp === t && (Bp = null);
			for (var e = 0; e < t.length; e += 3) {
				var n = t[e],
					r = t[e + 1],
					i = t[e + 2];
				if ("function" != typeof r) {
					if (null === kp(r || n)) continue;
					break
				}
				var a = dt(n);
				null !== a && (t.splice(e, 3), e -= 3, Ns(a, {
					pending: !0,
					data: i,
					method: n.method,
					action: r
				}, r, i))
			}
		}))
	}

	function Hp(e) {
		function t(t) {
			return Vp(t, e)
		}
		null !== Cp && Vp(Cp, e), null !== Np && Vp(Np, e), null !== Mp && Vp(Mp, e), Ap.forEach(t), _p.forEach(t);
		for (var n = 0; n < Lp.length; n++) {
			var r = Lp[n];
			r.blockedOn === e && (r.blockedOn = null)
		}
		for (; 0 < Lp.length && null === (n = Lp[0]).blockedOn;) zp(n), null === n.blockedOn && Lp.shift();
		if (null != (n = (e.ownerDocument || e).$$reactFormReplay))
			for (r = 0; r < n.length; r += 3) {
				var i = n[r],
					a = n[r + 1],
					o = i[tt] || null;
				if ("function" == typeof a) o || Up(n);
				else if (o) {
					var s = null;
					if (a && a.hasAttribute("formAction")) {
						if (i = a, o = a[tt] || null) s = o.formAction;
						else if (null !== kp(i)) continue
					} else s = o.action;
					"function" == typeof s ? n[r + 1] = s : (n.splice(r, 3), r -= 3), Up(n)
				}
			}
	}

	function $p() {
		function e(e) {
			e.canIntercept && "react-transition" === e.info && e.intercept({
				handler: function () {
					return new Promise(function (e) {
						return i = e
					})
				},
				focusReset: "manual",
				scroll: "manual"
			})
		}

		function t() {
			null !== i && (i(), i = null), r || setTimeout(n, 20)
		}

		function n() {
			if (!r && !navigation.transition) {
				var e = navigation.currentEntry;
				e && null != e.url && navigation.navigate(e.url, {
					state: e.getState(),
					info: "react-transition",
					history: "replace"
				})
			}
		}
		if ("object" == typeof navigation) {
			var r = !1,
				i = null;
			return navigation.addEventListener("navigate", e), navigation.addEventListener("navigatesuccess", t), navigation.addEventListener("navigateerror", t), setTimeout(n, 100),
				function () {
					r = !0, navigation.removeEventListener("navigate", e), navigation.removeEventListener("navigatesuccess", t), navigation.removeEventListener("navigateerror", t), null !== i && (i(), i = null)
				}
		}
	}

	function Wp(e) {
		this._internalRoot = e
	}

	function Zp(e) {
		this._internalRoot = e
	}
	Zp.prototype.render = Wp.prototype.render = function (e) {
		var t = this._internalRoot;
		if (null === t) throw Error(r(409));
		hp(t.current, od(), e, t, null, null)
	}, Zp.prototype.unmount = Wp.prototype.unmount = function () {
		var e = this._internalRoot;
		if (null !== e) {
			this._internalRoot = null;
			var t = e.containerInfo;
			hp(e.current, 2, null, e, null, null), pd(), t[nt] = null
		}
	}, Zp.prototype.unstable_scheduleHydration = function (e) {
		if (e) {
			var t = Xe();
			e = {
				blockedOn: null,
				target: e,
				priority: t
			};
			for (var n = 0; n < Lp.length && 0 !== t && t < Lp[n].priority; n++);
			Lp.splice(n, 0, e), 0 === n && zp(e)
		}
	};
	var Yp = t.version;
	if ("19.3.0" !== Yp) throw Error(r(527, Yp, "19.3.0"));
	Y.findDOMNode = function (e) {
		var t = e._reactInternals;
		if (void 0 === t) throw "function" == typeof e.render ? Error(r(188)) : (e = Object.keys(e).join(","), Error(r(268, e)));
		return e = function (e) {
			var t = e.alternate;
			if (!t) {
				if (null === (t = a(e))) throw Error(r(188));
				return t !== e ? null : e
			}
			for (var n = e, i = t; ;) {
				var o = n.return;
				if (null === o) break;
				var s = o.alternate;
				if (null === s) {
					if (null !== (i = o.return)) {
						n = i;
						continue
					}
					break
				}
				if (o.child === s.child) {
					for (s = o.child; s;) {
						if (s === n) return l(o), e;
						if (s === i) return l(o), t;
						s = s.sibling
					}
					throw Error(r(188))
				}
				if (n.return !== i.return) n = o, i = s;
				else {
					for (var u = !1, c = o.child; c;) {
						if (c === n) {
							u = !0, n = o, i = s;
							break
						}
						if (c === i) {
							u = !0, i = o, n = s;
							break
						}
						c = c.sibling
					}
					if (!u) {
						for (c = s.child; c;) {
							if (c === n) {
								u = !0, n = s, i = o;
								break
							}
							if (c === i) {
								u = !0, i = s, n = o;
								break
							}
							c = c.sibling
						}
						if (!u) throw Error(r(189))
					}
				}
				if (n.alternate !== i) throw Error(r(190))
			}
			if (3 !== n.tag) throw Error(r(188));
			return n.stateNode.current === n ? e : t
		}(t), e = null === (e = null !== e ? u(e) : null) ? null : e.stateNode
	};
	var qp = {
		bundleType: 0,
		version: "19.3.0",
		rendererPackageName: "react-dom",
		currentDispatcherRef: Z,
		reconcilerVersion: "19.3.0"
	};
	if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u") {
		var Kp = __REACT_DEVTOOLS_GLOBAL_HOOK__;
		if (!Kp.isDisabled && Kp.supportsFiber) try {
			Me = Kp.inject(qp), Ae = Kp
		} catch { }
	}
	return ms.createRoot = function (e, t) {
		if (!i(e)) throw Error(r(299));
		var n = !1,
			a = "",
			o = Xs,
			s = Gs,
			l = Js;
		return null != t && (!0 === t.unstable_strictMode && (n = !0), void 0 !== t.identifierPrefix && (a = t.identifierPrefix), void 0 !== t.onUncaughtError && (o = t.onUncaughtError), void 0 !== t.onCaughtError && (s = t.onCaughtError), void 0 !== t.onRecoverableError && (l = t.onRecoverableError)), t = dp(e, 1, !1, null, 0, n, a, null, o, s, l, $p), e[nt] = t.current, vf(e), new Wp(t)
	}, ms.hydrateRoot = function (e, t, n) {
		if (!i(e)) throw Error(r(299));
		var a = !1,
			o = "",
			s = Xs,
			l = Gs,
			u = Js,
			c = null;
		return null != n && (!0 === n.unstable_strictMode && (a = !0), void 0 !== n.identifierPrefix && (o = n.identifierPrefix), void 0 !== n.onUncaughtError && (s = n.onUncaughtError), void 0 !== n.onCaughtError && (l = n.onCaughtError), void 0 !== n.onRecoverableError && (u = n.onRecoverableError), void 0 !== n.formState && (c = n.formState)), (t = dp(e, 1, !0, t, 0, a, o, c, s, l, u, $p)).context = fp(null), n = t.current, (o = Ua(a = Ke(a = od()))).callback = null, Ha(n, o, a), n = a, t.current.lanes = n, We(t, n), Jd(t), e[nt] = t.current, vf(e), new Zp(t)
	}, ms.version = "19.3.0", ms
}

function B2() {
	if (Ny) return Cf.exports;
	return Ny = 1,
		function e() {
			if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" || "function" != typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE)) try {
				__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(e)
			} catch (e) {
				console.error(e)
			}
		}(), Cf.exports = V2(), Cf.exports
}
var U2 = B2();
const Sd = Z.createContext({});

function Td(e) {
	const t = Z.useRef(null);
	return null === t.current && (t.current = e()), t.current
}
const L2 = typeof window < "u",
	Ed = L2 ? Z.useLayoutEffect : Z.useEffect,
	Bo = Z.createContext(null);

function Ad(e, t) {
	-1 === e.indexOf(t) && e.push(t)
}

function Mo(e, t) {
	const n = e.indexOf(t);
	n > -1 && e.splice(n, 1)
}
const Vn = (e, t, n) => n > t ? t : n < e ? e : n;
let Uo = () => { };
const zi = {},
	Ig = e => /^-?(?:\d+(?:\.\d+)?|\.\d+)$/u.test(e),
	$g = e => "object" == typeof e && null !== e,
	Wg = e => /^0[^.\s]+$/u.test(e);

function tv(e) {
	let t;
	return () => (void 0 === t && (t = e()), t)
}
const rn = e => e,
	ws = (...e) => e.reduce((e, t) => n => t(e(n))),
	Es = (e, t, n) => {
		const r = t - e;
		return r ? (n - e) / r : 1
	};
class Md {
	constructor() {
		this.subscriptions = []
	}
	add(e) {
		return Ad(this.subscriptions, e), () => Mo(this.subscriptions, e)
	}
	notify(e, t, n) {
		const r = this.subscriptions.length;
		if (r)
			if (1 === r) this.subscriptions[0](e, t, n);
			else
				for (let i = 0; i < r; i++) {
					const r = this.subscriptions[i];
					r && r(e, t, n)
				}
	}
	getSize() {
		return this.subscriptions.length
	}
	clear() {
		this.subscriptions.length = 0
	}
}
const Fe = e => 1e3 * e,
	on = e => e / 1e3,
	ev = (e, t) => t ? e * (1e3 / t) : 0,
	nv = (e, t, n) => (((1 - 3 * n + 3 * t) * e + (3 * n - 6 * t)) * e + 3 * t) * e,
	H2 = 1e-7,
	Y2 = 12;

function G2(e, t, n, r, i) {
	let a, o, s = 0;
	do {
		o = t + (n - t) / 2, a = nv(o, r, i) - e, a > 0 ? n = o : t = o
	} while (Math.abs(a) > H2 && ++s < 12);
	return o
}

function _s(e, t, n, r) {
	if (e === t && n === r) return rn;
	return i => 0 === i || 1 === i ? i : nv((t => G2(t, 0, 1, e, n))(i), t, r)
}
const iv = e => t => t <= .5 ? e(2 * t) / 2 : (2 - e(2 * (1 - t))) / 2,
	av = e => t => 1 - e(1 - t),
	lv = _s(.33, 1.53, .69, .99),
	Cd = av(lv),
	sv = iv(Cd),
	uv = e => e >= 1 ? 1 : (e *= 2) < 1 ? .5 * Cd(e) : .5 * (2 - Math.pow(2, -10 * (e - 1))),
	Dd = e => 1 - Math.sin(Math.acos(e)),
	ov = av(Dd),
	rv = iv(Dd),
	q2 = _s(.42, 0, 1, 1),
	X2 = _s(0, 0, .58, 1),
	cv = _s(.42, 0, .58, 1),
	Q2 = e => Array.isArray(e) && "number" != typeof e[0],
	fv = e => Array.isArray(e) && "number" == typeof e[0],
	Z2 = {
		linear: rn,
		easeIn: q2,
		easeInOut: cv,
		easeOut: X2,
		circIn: Dd,
		circInOut: rv,
		circOut: ov,
		backIn: Cd,
		backInOut: sv,
		backOut: lv,
		anticipate: uv
	},
	K2 = e => "string" == typeof e,
	Oy = e => {
		if (fv(e)) {
			Uo(4 === e.length);
			const [t, n, r, i] = e;
			return _s(t, n, r, i)
		}
		return K2(e) ? Z2[e] : e
	},
	fo = ["setup", "read", "resolveKeyframes", "preUpdate", "update", "preRender", "render", "postRender"];

function P2(e) {
	let t = new Set,
		n = new Set,
		r = !1,
		i = !1;
	const a = new WeakSet;
	let o = {
		delta: 0,
		timestamp: 0,
		isProcessing: !1
	};

	function s(t) {
		a.has(t) && (l.schedule(t), e()), t(o)
	}
	const l = {
		schedule: (e, i = !1, o = !1) => {
			const s = o && r ? t : n;
			return i && a.add(e), s.add(e), e
		},
		cancel: e => {
			n.delete(e), a.delete(e)
		},
		process: e => {
			if (o = e, r) return void (i = !0);
			r = !0;
			const a = t;
			t = n, n = a, t.forEach(s), t.clear(), r = !1, i && (i = !1, l.process(e))
		}
	};
	return l
}
const J2 = 40;

function dv(e, t) {
	let n = !1,
		r = !0;
	const i = {
		delta: 0,
		timestamp: 0,
		isProcessing: !1
	},
		a = () => n = !0,
		o = fo.reduce((e, t) => (e[t] = P2(a), e), {}),
		{
			setup: s,
			read: l,
			resolveKeyframes: u,
			preUpdate: c,
			update: d,
			preRender: f,
			render: h,
			postRender: p
		} = o,
		m = () => {
			const a = zi.useManualTiming,
				o = a ? i.timestamp : performance.now();
			n = !1, a || (i.delta = r ? 1e3 / 60 : Math.max(Math.min(o - i.timestamp, 40), 1)), i.timestamp = o, i.isProcessing = !0, s.process(i), l.process(i), u.process(i), c.process(i), d.process(i), f.process(i), h.process(i), p.process(i), i.isProcessing = !1, n && t && (r = !1, e(m))
		};
	return {
		schedule: fo.reduce((t, a) => {
			const s = o[a];
			return t[a] = (t, a = !1, o = !1) => (n || (n = !0, r = !0, i.isProcessing || e(m)), s.schedule(t, a, o)), t
		}, {}),
		cancel: e => {
			for (let t = 0; t < fo.length; t++) o[fo[t]].cancel(e)
		},
		state: i,
		steps: o
	}
}
const {
	schedule: Yt,
	cancel: wi,
	state: xe,
	steps: zf
} = dv(typeof requestAnimationFrame < "u" ? requestAnimationFrame : rn, !0);
let go;

function k2() {
	go = void 0
}
const Oe = {
	now: () => (void 0 === go && Oe.set(xe.isProcessing || zi.useManualTiming ? xe.timestamp : performance.now()), go),
	set: e => {
		go = e, queueMicrotask(k2)
	}
},
	hv = e => t => "string" == typeof t && t.startsWith(e),
	mv = hv("--"),
	F2 = hv("var(--"),
	Nd = e => !!F2(e) && I2.test(e.split("/*")[0].trim()),
	I2 = /var\(--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)$/iu;

function zy(e) {
	return "string" == typeof e && e.split("/*")[0].includes("var(--")
}
const cl = {
	test: e => "number" == typeof e,
	parse: parseFloat,
	transform: e => e
},
	As = {
		...cl,
		transform: e => Vn(0, 1, e)
	},
	ho = {
		...cl,
		default: 1
	},
	vs = e => Math.round(1e5 * e) / 1e5,
	Od = /-?(?:\d+(?:\.\d+)?|\.\d+)/gu;

function $2(e) {
	return null == e
}
const W2 = /^(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))$/iu,
	zd = (e, t) => n => !!("string" == typeof n && W2.test(n) && n.startsWith(e) || t && !$2(n) && Object.prototype.hasOwnProperty.call(n, t)),
	pv = (e, t, n) => r => {
		if ("string" != typeof r) return r;
		const [i, a, o, s] = r.match(Od);
		return {
			[e]: parseFloat(i),
			[t]: parseFloat(a),
			[n]: parseFloat(o),
			alpha: void 0 !== s ? parseFloat(s) : 1
		}
	},
	tS = e => Vn(0, 255, e),
	wf = {
		...cl,
		transform: e => Math.round(tS(e))
	},
	ua = {
		test: zd("rgb", "red"),
		parse: pv("red", "green", "blue"),
		transform: ({
			red: e,
			green: t,
			blue: n,
			alpha: r = 1
		}) => "rgba(" + wf.transform(e) + ", " + wf.transform(t) + ", " + wf.transform(n) + ", " + vs(As.transform(r)) + ")"
	};

function eS(e) {
	let t = "",
		n = "",
		r = "",
		i = "";
	return e.length > 5 ? (t = e.substring(1, 3), n = e.substring(3, 5), r = e.substring(5, 7), i = e.substring(7, 9)) : (t = e.substring(1, 2), n = e.substring(2, 3), r = e.substring(3, 4), i = e.substring(4, 5), t += t, n += n, r += r, i += i), {
		red: parseInt(t, 16),
		green: parseInt(n, 16),
		blue: parseInt(r, 16),
		alpha: i ? parseInt(i, 16) / 255 : 1
	}
}
const Pf = {
	test: zd("#"),
	parse: eS,
	transform: ua.transform
},
	Rs = e => ({
		test: t => "string" == typeof t && t.endsWith(e) && 1 === t.split(" ").length,
		parse: parseFloat,
		transform: t => `${t}${e}`
	}),
	$n = Rs("deg"),
	jn = Rs("%"),
	at = Rs("px"),
	nS = Rs("vh"),
	iS = Rs("vw"),
	wy = {
		...jn,
		parse: e => jn.parse(e) / 100,
		transform: e => jn.transform(100 * e)
	},
	ll = {
		test: zd("hsl", "hue"),
		parse: pv("hue", "saturation", "lightness"),
		transform: ({
			hue: e,
			saturation: t,
			lightness: n,
			alpha: r = 1
		}) => "hsla(" + Math.round(e) + ", " + jn.transform(vs(t)) + ", " + jn.transform(vs(n)) + ", " + vs(As.transform(r)) + ")"
	},
	ie = {
		test: e => ua.test(e) || Pf.test(e) || ll.test(e),
		parse: e => ua.test(e) ? ua.parse(e) : ll.test(e) ? ll.parse(e) : Pf.parse(e),
		transform: e => "string" == typeof e ? e : e.hasOwnProperty("red") ? ua.transform(e) : ll.transform(e),
		getAnimatableNone: e => {
			const t = ie.parse(e);
			return t.alpha = 0, ie.transform(t)
		}
	},
	aS = /(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))/giu;

function lS(e) {
	var t, n;
	return isNaN(e) && "string" == typeof e && ((null == (t = e.match(Od)) ? void 0 : t.length) || 0) + ((null == (n = e.match(aS)) ? void 0 : n.length) || 0) > 0
}
const yv = "number",
	gv = "color",
	sS = "var",
	uS = "var(",
	_y = "${}",
	oS = /var\s*\(\s*--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)|#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\)|-?(?:\d+(?:\.\d+)?|\.\d+)/giu;

function ol(e) {
	const t = e.toString(),
		n = [],
		r = {
			color: [],
			number: [],
			var: []
		},
		i = [];
	let a = 0;
	const o = t.replace(oS, e => (ie.test(e) ? (r.color.push(a), i.push(gv), n.push(ie.parse(e))) : e.startsWith(uS) ? (r.var.push(a), i.push(sS), n.push(e)) : (r.number.push(a), i.push(yv), n.push(parseFloat(e))), ++a, _y)).split(_y);
	return {
		values: n,
		split: o,
		indexes: r,
		types: i
	}
}

function rS(e) {
	return ol(e).values
}

function vv({
	split: e,
	types: t
}) {
	const n = e.length;
	return r => {
		let i = "";
		for (let a = 0; a < n; a++)
			if (i += e[a], void 0 !== r[a]) {
				const e = t[a];
				i += e === yv ? vs(r[a]) : e === gv ? ie.transform(r[a]) : r[a]
			} return i
	}
}

function cS(e) {
	return vv(ol(e))
}
const fS = e => "number" == typeof e ? 0 : ie.test(e) ? ie.getAnimatableNone(e) : e,
	dS = (e, t) => "number" == typeof e ? null != t && t.trim().endsWith("/") ? e : 0 : fS(e);

function hS(e) {
	const t = ol(e);
	return vv(t)(t.values.map((e, n) => dS(e, t.split[n])))
}
const vn = {
	test: lS,
	parse: rS,
	createTransformer: cS,
	getAnimatableNone: hS
};

function _f(e, t, n) {
	return n < 0 && (n += 1), n > 1 && (n -= 1), n < 1 / 6 ? e + 6 * (t - e) * n : n < .5 ? t : n < 2 / 3 ? e + (t - e) * (2 / 3 - n) * 6 : e
}

function mS({
	hue: e,
	saturation: t,
	lightness: n,
	alpha: r
}) {
	e /= 360, n /= 100;
	let i = 0,
		a = 0,
		o = 0;
	if (t /= 100) {
		const r = n < .5 ? n * (1 + t) : n + t - n * t,
			s = 2 * n - r;
		i = _f(s, r, e + 1 / 3), a = _f(s, r, e), o = _f(s, r, e - 1 / 3)
	} else i = a = o = n;
	return {
		red: Math.round(255 * i),
		green: Math.round(255 * a),
		blue: Math.round(255 * o),
		alpha: r
	}
}

function Co(e, t) {
	return n => n > 0 ? t : e
}
const Ht = (e, t, n) => e + (t - e) * n,
	Rf = (e, t, n) => {
		const r = e * e,
			i = n * (t * t - r) + r;
		return i < 0 ? 0 : Math.sqrt(i)
	},
	pS = [Pf, ua, ll],
	yS = e => pS.find(t => t.test(e));

function Ry(e) {
	const t = yS(e);
	if (!t) return !1;
	let n = t.parse(e);
	return t === ll && (n = mS(n)), n
}
const jy = (e, t) => {
	const n = Ry(e),
		r = Ry(t);
	if (!n || !r) return Co(e, t);
	const i = {
		...n
	};
	return e => (i.red = Rf(n.red, r.red, e), i.green = Rf(n.green, r.green, e), i.blue = Rf(n.blue, r.blue, e), i.alpha = Ht(n.alpha, r.alpha, e), ua.transform(i))
},
	Jf = new Set(["none", "hidden"]);

function gS(e, t) {
	return Jf.has(e) ? n => n <= 0 ? e : t : n => n >= 1 ? t : e
}

function vS(e, t) {
	return n => Ht(e, t, n)
}

function wd(e) {
	return "number" == typeof e ? vS : "string" == typeof e ? Nd(e) ? Co : ie.test(e) ? jy : SS : Array.isArray(e) ? bv : "object" == typeof e ? ie.test(e) ? jy : bS : Co
}

function bv(e, t) {
	const n = [...e],
		r = n.length,
		i = e.map((e, n) => wd(e)(e, t[n]));
	return e => {
		for (let t = 0; t < r; t++) n[t] = i[t](e);
		return n
	}
}

function bS(e, t) {
	const n = {
		...e,
		...t
	},
		r = {};
	for (const i in n) void 0 !== e[i] && void 0 !== t[i] && (r[i] = wd(e[i])(e[i], t[i]));
	return e => {
		for (const t in r) n[t] = r[t](e);
		return n
	}
}

function xS(e, t) {
	const n = [],
		r = {
			color: 0,
			var: 0,
			number: 0
		};
	for (let i = 0; i < t.values.length; i++) {
		const a = t.types[i],
			o = e.indexes[a][r[a]],
			s = e.values[o] ?? 0;
		n[i] = s, r[a]++
	}
	return n
}
const SS = (e, t) => {
	const n = vn.createTransformer(t),
		r = ol(e),
		i = ol(t);
	return r.indexes.var.length === i.indexes.var.length && r.indexes.color.length === i.indexes.color.length && r.indexes.number.length >= i.indexes.number.length ? Jf.has(e) && !i.values.length || Jf.has(t) && !r.values.length ? gS(e, t) : ws(bv(xS(r, i), i.values), n) : Co(e, t)
};

function xv(e, t, n) {
	return "number" == typeof e && "number" == typeof t && "number" == typeof n ? Ht(e, t, n) : wd(e)(e, t)
}
const TS = e => {
	const t = ({
		timestamp: t
	}) => e(t);
	return {
		start: (e = !0) => Yt.update(t, e),
		stop: () => wi(t),
		now: () => xe.isProcessing ? xe.timestamp : Oe.now()
	}
},
	Sv = (e, t, n = 10) => {
		let r = "";
		const i = Math.max(Math.round(t / n), 2);
		for (let t = 0; t < i; t++) r += Math.round(1e4 * e(t / (i - 1))) / 1e4 + ", ";
		return `linear(${r.substring(0, r.length - 2)})`
	},
	Do = 2e4;

function _d(e) {
	let t = 0;
	let n = e.next(t);
	for (; !n.done && t < Do;) t += 50, n = e.next(t);
	return t >= Do ? 1 / 0 : t
}

function ES(e, t = 100, n) {
	const r = n({
		...e,
		keyframes: [0, t]
	}),
		i = Math.min(_d(r), Do);
	return {
		type: "keyframes",
		ease: e => r.next(i * e).value / t,
		duration: on(i)
	}
}
const Ft = {
	stiffness: 100,
	damping: 10,
	mass: 1,
	velocity: 0,
	duration: 800,
	bounce: .3,
	visualDuration: .3,
	restSpeed: {
		granular: .01,
		default: 2
	},
	restDelta: {
		granular: .005,
		default: .5
	},
	minDuration: .01,
	maxDuration: 10,
	minDamping: .05,
	maxDamping: 1
};

function kf(e, t) {
	return e * Math.sqrt(1 - t * t)
}
const AS = 12;

function MS(e, t, n) {
	let r = n;
	for (let n = 1; n < 12; n++) r -= e(r) / t(r);
	return r
}
const jf = .001;

function CS({
	duration: e = Ft.duration,
	bounce: t = Ft.bounce,
	velocity: n = Ft.velocity,
	mass: r = Ft.mass
}) {
	let i, a, o = 1 - t;
	o = Vn(Ft.minDamping, Ft.maxDamping, o), e = Vn(Ft.minDuration, Ft.maxDuration, on(e)), o < 1 ? (i = t => {
		const r = t * o,
			i = r * e,
			a = r - n,
			s = kf(t, o),
			l = Math.exp(-i);
		return jf - a / s * l
	}, a = t => {
		const r = t * o * e,
			a = r * n + n,
			s = Math.pow(o, 2) * Math.pow(t, 2) * e,
			l = Math.exp(-r),
			u = kf(Math.pow(t, 2), o);
		return (-i(t) + jf > 0 ? -1 : 1) * ((a - s) * l) / u
	}) : (i = t => Math.exp(-t * e) * ((t - n) * e + 1) - jf, a = t => Math.exp(-t * e) * (e * e * (n - t)));
	const s = MS(i, a, 5 / e);
	if (e = Fe(e), isNaN(s)) return {
		stiffness: Ft.stiffness,
		damping: Ft.damping,
		duration: e
	};
	{
		const t = Math.pow(s, 2) * r;
		return {
			stiffness: t,
			damping: 2 * o * Math.sqrt(r * t),
			duration: e
		}
	}
}
const DS = ["duration", "bounce"],
	NS = ["stiffness", "damping", "mass"];

function Vy(e, t) {
	return t.some(t => void 0 !== e[t])
}

function OS(e) {
	let t = {
		velocity: Ft.velocity,
		stiffness: Ft.stiffness,
		damping: Ft.damping,
		mass: Ft.mass,
		isResolvedFromDuration: !1,
		...e
	};
	if (!Vy(e, NS) && Vy(e, DS))
		if (t.velocity = 0, e.visualDuration) {
			const n = e.visualDuration,
				r = 2 * Math.PI / (1.2 * n),
				i = r * r,
				a = 2 * Vn(.05, 1, 1 - (e.bounce || 0)) * Math.sqrt(i);
			t = {
				...t,
				mass: Ft.mass,
				stiffness: i,
				damping: a
			}
		} else {
			const n = CS({
				...e,
				velocity: 0
			});
			t = {
				...t,
				...n,
				mass: Ft.mass
			}, t.isResolvedFromDuration = !0
		} return t
}

function No(e = Ft.visualDuration, t = Ft.bounce) {
	const n = "object" != typeof e ? {
		visualDuration: e,
		keyframes: [0, 1],
		bounce: t
	} : e;
	let {
		restSpeed: r,
		restDelta: i
	} = n;
	const a = n.keyframes[0],
		o = n.keyframes[n.keyframes.length - 1],
		s = {
			done: !1,
			value: a
		},
		{
			stiffness: l,
			damping: u,
			mass: c,
			duration: d,
			velocity: f,
			isResolvedFromDuration: h
		} = OS({
			...n,
			velocity: -on(n.velocity || 0)
		}),
		p = f || 0,
		m = u / (2 * Math.sqrt(l * c)),
		g = o - a,
		v = on(Math.sqrt(l / c)),
		y = Math.abs(g) < 5;
	let b, x, w, S, E, k;
	if (r || (r = y ? Ft.restSpeed.granular : Ft.restSpeed.default), i || (i = y ? Ft.restDelta.granular : Ft.restDelta.default), m < 1) w = kf(v, m), S = (p + m * v * g) / w, b = e => {
		const t = Math.exp(-m * v * e);
		return o - t * (S * Math.sin(w * e) + g * Math.cos(w * e))
	}, E = m * v * S + g * w, k = m * v * g - S * w, x = e => Math.exp(-m * v * e) * (E * Math.sin(w * e) + k * Math.cos(w * e));
	else if (1 === m) {
		b = e => o - Math.exp(-v * e) * (g + (p + v * g) * e);
		const e = p + v * g;
		x = t => Math.exp(-v * t) * (v * e * t - p)
	} else {
		const e = v * Math.sqrt(m * m - 1);
		b = t => {
			const n = Math.exp(-m * v * t),
				r = Math.min(e * t, 300);
			return o - n * ((p + m * v * g) * Math.sinh(r) + e * g * Math.cosh(r)) / e
		};
		const t = (p + m * v * g) / e,
			n = m * v * t - g * e,
			r = m * v * g - t * e;
		x = t => {
			const i = Math.exp(-m * v * t),
				a = Math.min(e * t, 300);
			return i * (n * Math.sinh(a) + r * Math.cosh(a))
		}
	}
	const T = {
		calculatedDuration: h && d || null,
		velocity: e => Fe(x(e)),
		next: e => {
			if (!h && m < 1) {
				const t = Math.exp(-m * v * e),
					n = Math.sin(w * e),
					a = Math.cos(w * e),
					l = o - t * (S * n + g * a),
					u = Fe(t * (E * n + k * a));
				return s.done = Math.abs(u) <= r && Math.abs(o - l) <= i, s.value = s.done ? o : l, s
			}
			const t = b(e);
			if (h) s.done = e >= d;
			else {
				const n = Fe(x(e));
				s.done = Math.abs(n) <= r && Math.abs(o - t) <= i
			}
			return s.value = s.done ? o : t, s
		},
		toString: () => {
			const e = Math.min(_d(T), Do),
				t = Sv(t => T.next(e * t).value, e, 30);
			return e + "ms " + t
		},
		toTransition: () => { }
	};
	return T
}
No.applyToOptions = e => {
	const t = ES(e, 100, No);
	return e.ease = t.ease, e.duration = Fe(t.duration), e.type = "keyframes", e
};
const zS = 5;

function Tv(e, t, n) {
	const r = Math.max(t - 5, 0);
	return ev(n - e(r), t - r)
}

function Ff({
	keyframes: e,
	velocity: t = 0,
	power: n = .8,
	timeConstant: r = 325,
	bounceDamping: i = 10,
	bounceStiffness: a = 500,
	modifyTarget: o,
	min: s,
	max: l,
	restDelta: u = .5,
	restSpeed: c
}) {
	const d = e[0],
		f = {
			done: !1,
			value: d
		},
		h = e => void 0 === s ? l : void 0 === l || Math.abs(s - e) < Math.abs(l - e) ? s : l;
	let p = n * t;
	const m = d + p,
		g = void 0 === o ? m : o(m);
	g !== m && (p = g - d);
	const v = e => -p * Math.exp(-e / r),
		y = e => g + v(e),
		b = e => {
			const t = v(e),
				n = y(e);
			f.done = Math.abs(t) <= u, f.value = f.done ? g : n
		};
	let x, w;
	const S = e => {
		(e => void 0 !== s && e < s || void 0 !== l && e > l)(f.value) && (x = e, w = No({
			keyframes: [f.value, h(f.value)],
			velocity: Tv(y, e, f.value),
			damping: i,
			stiffness: a,
			restDelta: u,
			restSpeed: c
		}))
	};
	return S(0), {
		calculatedDuration: null,
		next: e => {
			let t = !1;
			return !w && void 0 === x && (t = !0, b(e), S(e)), void 0 !== x && e >= x ? w.next(e - x) : (!t && b(e), f)
		}
	}
}

function wS(e, t, n) {
	const r = [],
		i = n || zi.mix || xv,
		a = e.length - 1;
	for (let n = 0; n < a; n++) {
		let a = i(e[n], e[n + 1]);
		if (t) {
			const e = Array.isArray(t) ? t[n] || rn : t;
			a = ws(e, a)
		}
		r.push(a)
	}
	return r
}

function _S(e, t, {
	clamp: n = !0,
	ease: r,
	mixer: i
} = {}) {
	const a = e.length;
	if (Uo(a === t.length), 1 === a) return () => t[0];
	if (2 === a && t[0] === t[1]) return () => t[1];
	const o = e[0] === e[1];
	e[0] > e[a - 1] && (e = [...e].reverse(), t = [...t].reverse());
	const s = wS(t, r, i),
		l = s.length,
		u = n => {
			if (o && n < e[0]) return t[0];
			let r = 0;
			if (l > 1)
				for (; r < e.length - 2 && !(n < e[r + 1]); r++);
			const i = Es(e[r], e[r + 1], n);
			return s[r](i)
		};
	return n ? t => u(Vn(e[0], e[a - 1], t)) : u
}

function RS(e, t) {
	const n = e[e.length - 1];
	for (let r = 1; r <= t; r++) {
		const i = Es(0, t, r);
		e.push(Ht(n, 1, i))
	}
}

function jS(e) {
	const t = [0];
	return RS(t, e.length - 1), t
}

function VS(e, t) {
	return e.map(e => e * t)
}

function BS(e, t) {
	return e.map(() => t || cv).splice(0, e.length - 1)
}

function bs({
	duration: e = 300,
	keyframes: t,
	times: n,
	ease: r = "easeInOut"
}) {
	const i = Q2(r) ? r.map(Oy) : Oy(r),
		a = {
			done: !1,
			value: t[0]
		},
		o = _S(VS(n && n.length === t.length ? n : jS(t), e), t, {
			ease: Array.isArray(i) ? i : BS(t, i)
		});
	return {
		calculatedDuration: e,
		next: t => (a.value = o(t), a.done = t >= e, a)
	}
}
const US = e => null !== e;

function Lo(e, {
	repeat: t,
	repeatType: n = "loop"
}, r, i = 1) {
	const a = e.filter(US),
		o = i < 0 || t && "loop" !== n && t % 2 == 1 ? 0 : a.length - 1;
	return o && void 0 !== r ? r : a[o]
}
const LS = {
	decay: Ff,
	inertia: Ff,
	tween: bs,
	keyframes: bs,
	spring: No
};

function Ev(e) {
	"string" == typeof e.type && (e.type = LS[e.type])
}
class Rd {
	constructor() {
		this.updateFinished()
	}
	get finished() {
		return this._finished
	}
	updateFinished() {
		this._finished = new Promise(e => {
			this.resolve = e
		})
	}
	notifyFinished() {
		this.resolve()
	}
	then(e, t) {
		return this.finished.then(e, t)
	}
}
const HS = e => e / 100;
class Oo extends Rd {
	constructor(e) {
		super(), this.state = "idle", this.startTime = null, this.isStopped = !1, this.currentTime = 0, this.holdTime = null, this.playbackSpeed = 1, this.delayState = {
			done: !1,
			value: void 0
		}, this.stop = () => {
			var e, t;
			const {
				motionValue: n
			} = this.options;
			n && n.updatedAt !== Oe.now() && this.tick(Oe.now()), this.isStopped = !0, "idle" !== this.state && (this.teardown(), null == (t = (e = this.options).onStop) || t.call(e))
		}, this.options = e, this.initAnimation(), this.play(), !1 === e.autoplay && this.pause()
	}
	initAnimation() {
		const {
			options: e
		} = this;
		Ev(e);
		const {
			type: t = bs,
			repeat: n = 0,
			repeatDelay: r = 0,
			repeatType: i,
			velocity: a = 0
		} = e;
		let {
			keyframes: o
		} = e;
		const s = t || bs;
		s !== bs && "number" != typeof o[0] && (this.mixKeyframes = ws(HS, xv(o[0], o[1])), o = [0, 100]);
		const l = s({
			...e,
			keyframes: o
		});
		"mirror" === i && (this.mirroredGenerator = s({
			...e,
			keyframes: [...o].reverse(),
			velocity: -a
		})), null === l.calculatedDuration && (l.calculatedDuration = _d(l));
		const {
			calculatedDuration: u
		} = l;
		this.calculatedDuration = u, this.resolvedDuration = u + r, this.totalDuration = this.resolvedDuration * (n + 1) - r, this.generator = l
	}
	updateTime(e) {
		const t = Math.round(e - this.startTime) * this.playbackSpeed;
		null !== this.holdTime ? this.currentTime = this.holdTime : this.currentTime = t
	}
	tick(e, t = !1) {
		const {
			generator: n,
			totalDuration: r,
			mixKeyframes: i,
			mirroredGenerator: a,
			resolvedDuration: o,
			calculatedDuration: s
		} = this;
		if (null === this.startTime) return n.next(0);
		const {
			delay: l = 0,
			keyframes: u,
			repeat: c,
			repeatType: d,
			repeatDelay: f,
			type: h,
			onUpdate: p,
			finalKeyframe: m
		} = this.options;
		this.speed > 0 ? this.startTime = Math.min(this.startTime, e) : this.speed < 0 && (this.startTime = Math.min(e - r / this.speed, this.startTime)), t ? this.currentTime = e : this.updateTime(e);
		const g = this.currentTime - l * (this.playbackSpeed >= 0 ? 1 : -1),
			v = this.playbackSpeed >= 0 ? g < 0 : g > r;
		this.currentTime = Math.max(g, 0), "finished" === this.state && null === this.holdTime && (this.currentTime = r);
		let y, b = this.currentTime,
			x = n;
		if (c) {
			const e = Math.min(this.currentTime, r) / o;
			let t = Math.floor(e),
				n = e % 1;
			!n && e >= 1 && (n = 1), 1 === n && t--, t = Math.min(t, c + 1), !!(t % 2) && ("reverse" === d ? (n = 1 - n, f && (n -= f / o)) : "mirror" === d && (x = a)), b = Vn(0, 1, n) * o
		}
		v ? (this.delayState.value = u[0], y = this.delayState) : y = x.next(b), i && !v && (y.value = i(y.value));
		let {
			done: w
		} = y;
		!v && null !== s && (w = this.playbackSpeed >= 0 ? this.currentTime >= r : this.currentTime <= 0);
		const S = null === this.holdTime && ("finished" === this.state || "running" === this.state && w);
		return S && h !== Ff && (y.value = Lo(u, this.options, m, this.speed)), p && p(y.value), S && this.finish(), y
	}
	then(e, t) {
		return this.finished.then(e, t)
	}
	get duration() {
		return on(this.calculatedDuration)
	}
	get iterationDuration() {
		const {
			delay: e = 0
		} = this.options || {};
		return this.duration + on(e)
	}
	get time() {
		return on(this.currentTime)
	}
	set time(e) {
		e = Fe(e), this.currentTime = e, null === this.startTime || null !== this.holdTime || 0 === this.playbackSpeed ? this.holdTime = e : this.driver && (this.startTime = this.driver.now() - e / this.playbackSpeed), this.driver ? this.driver.start(!1) : (this.startTime = 0, this.state = "paused", this.holdTime = e, this.tick(e))
	}
	getGeneratorVelocity() {
		const e = this.currentTime;
		if (e <= 0) return this.options.velocity || 0;
		if (this.generator.velocity) return this.generator.velocity(e);
		return Tv(e => this.generator.next(e).value, e, this.generator.next(e).value)
	}
	get speed() {
		return this.playbackSpeed
	}
	set speed(e) {
		const t = this.playbackSpeed !== e;
		t && this.driver && this.updateTime(Oe.now()), this.playbackSpeed = e, t && this.driver && (this.time = on(this.currentTime))
	}
	play() {
		var e, t;
		if (this.isStopped) return;
		const {
			driver: n = TS,
			startTime: r
		} = this.options;
		this.driver || (this.driver = n(e => this.tick(e))), null == (t = (e = this.options).onPlay) || t.call(e);
		const i = this.driver.now();
		"finished" === this.state ? (this.updateFinished(), this.startTime = i) : null !== this.holdTime ? this.startTime = i - this.holdTime : this.startTime || (this.startTime = r ?? i), "finished" === this.state && this.speed < 0 && (this.startTime += this.calculatedDuration), this.holdTime = null, this.state = "running", this.driver.start()
	}
	pause() {
		this.state = "paused", this.updateTime(Oe.now()), this.holdTime = this.currentTime
	}
	complete() {
		"running" !== this.state && this.play(), this.state = "finished", this.holdTime = null
	}
	finish() {
		var e, t;
		this.notifyFinished(), this.teardown(), this.state = "finished", null == (t = (e = this.options).onComplete) || t.call(e)
	}
	cancel() {
		var e, t;
		this.holdTime = null, this.startTime = 0, this.tick(0), this.teardown(), null == (t = (e = this.options).onCancel) || t.call(e)
	}
	teardown() {
		this.state = "idle", this.stopDriver(), this.startTime = this.holdTime = null
	}
	stopDriver() {
		this.driver && (this.driver.stop(), this.driver = void 0)
	}
	sample(e) {
		return this.startTime = 0, this.tick(e, !0)
	}
	attachTimeline(e) {
		var t;
		return this.options.allowFlatten && (this.options.type = "keyframes", this.options.ease = "linear", this.initAnimation()), null == (t = this.driver) || t.stop(), e.observe(this)
	}
}

function YS(e) {
	for (let t = 1; t < e.length; t++) e[t] ?? (e[t] = e[t - 1])
}
const oa = e => 180 * e / Math.PI,
	If = e => {
		const t = oa(Math.atan2(e[1], e[0]));
		return $f(t)
	},
	GS = {
		x: 4,
		y: 5,
		translateX: 4,
		translateY: 5,
		scaleX: 0,
		scaleY: 3,
		scale: e => (Math.abs(e[0]) + Math.abs(e[3])) / 2,
		rotate: If,
		rotateZ: If,
		skewX: e => oa(Math.atan(e[1])),
		skewY: e => oa(Math.atan(e[2])),
		skew: e => (Math.abs(e[1]) + Math.abs(e[2])) / 2
	},
	$f = e => ((e %= 360) < 0 && (e += 360), e),
	By = If,
	Uy = e => Math.sqrt(e[0] * e[0] + e[1] * e[1]),
	Ly = e => Math.sqrt(e[4] * e[4] + e[5] * e[5]),
	qS = {
		x: 12,
		y: 13,
		z: 14,
		translateX: 12,
		translateY: 13,
		translateZ: 14,
		scaleX: Uy,
		scaleY: Ly,
		scale: e => (Uy(e) + Ly(e)) / 2,
		rotateX: e => $f(oa(Math.atan2(e[6], e[5]))),
		rotateY: e => $f(oa(Math.atan2(-e[2], e[0]))),
		rotateZ: If,
		rotate: If,
		skewX: e => oa(Math.atan(e[4])),
		skewY: e => oa(Math.atan(e[1])),
		skew: e => (Math.abs(e[1]) + Math.abs(e[4])) / 2
	};

function Wf(e) {
	return e.includes("scale") ? 1 : 0
}

function td(e, t) {
	if (!e || "none" === e) return Wf(t);
	const n = e.match(/^matrix3d\(([-\d.e\s,]+)\)$/u);
	let r, i;
	if (n) r = qS, i = n;
	else {
		const t = e.match(/^matrix\(([-\d.e\s,]+)\)$/u);
		r = GS, i = t
	}
	if (!i) return Wf(t);
	const a = r[t],
		o = i[1].split(",").map(QS);
	return "function" == typeof a ? a(o) : o[a]
}
const XS = (e, t) => {
	const {
		transform: n = "none"
	} = getComputedStyle(e);
	return td(n, t)
};

function QS(e) {
	return parseFloat(e.trim())
}
const fl = ["transformPerspective", "x", "y", "z", "translateX", "translateY", "translateZ", "scale", "scaleX", "scaleY", "rotate", "rotateX", "rotateY", "rotateZ", "skew", "skewX", "skewY"],
	dl = new Set([...fl, "pathRotation"]),
	Hy = e => e === cl || e === at,
	ZS = new Set(["x", "y", "z"]),
	KS = fl.filter(e => !ZS.has(e));

function PS(e) {
	const t = [];
	return KS.forEach(n => {
		const r = e.getValue(n);
		void 0 !== r && (t.push([n, r.get()]), r.set(n.startsWith("scale") ? 1 : 0))
	}), t
}
const Oi = {
	width: ({
		x: e
	}, {
		paddingLeft: t = "0",
		paddingRight: n = "0",
		boxSizing: r
	}) => {
		const i = e.max - e.min;
		return "border-box" === r ? i : i - parseFloat(t) - parseFloat(n)
	},
	height: ({
		y: e
	}, {
		paddingTop: t = "0",
		paddingBottom: n = "0",
		boxSizing: r
	}) => {
		const i = e.max - e.min;
		return "border-box" === r ? i : i - parseFloat(t) - parseFloat(n)
	},
	top: (e, {
		top: t
	}) => parseFloat(t),
	left: (e, {
		left: t
	}) => parseFloat(t),
	bottom: ({
		y: e
	}, {
		top: t
	}) => parseFloat(t) + (e.max - e.min),
	right: ({
		x: e
	}, {
		left: t
	}) => parseFloat(t) + (e.max - e.min),
	x: (e, {
		transform: t
	}) => td(t, "x"),
	y: (e, {
		transform: t
	}) => td(t, "y")
};
Oi.translateX = Oi.x, Oi.translateY = Oi.y;
const ra = new Set;
let ed = !1,
	nd = !1,
	id = !1;

function Av() {
	if (nd) {
		const e = Array.from(ra).filter(e => e.needsMeasurement),
			t = new Set(e.map(e => e.element)),
			n = new Map;
		t.forEach(e => {
			const t = PS(e);
			t.length && (n.set(e, t), e.render())
		}), e.forEach(e => e.measureInitialState()), t.forEach(e => {
			e.render();
			const t = n.get(e);
			t && t.forEach(([t, n]) => {
				var r;
				null == (r = e.getValue(t)) || r.set(n)
			})
		}), e.forEach(e => e.measureEndState()), e.forEach(e => {
			void 0 !== e.suspendedScrollY && window.scrollTo(0, e.suspendedScrollY)
		})
	}
	nd = !1, ed = !1, ra.forEach(e => e.complete(id)), ra.clear()
}

function Mv() {
	ra.forEach(e => {
		e.readKeyframes(), e.needsMeasurement && (nd = !0)
	})
}

function JS() {
	id = !0, Mv(), Av(), id = !1
}
class jd {
	constructor(e, t, n, r, i, a = !1) {
		this.state = "pending", this.isAsync = !1, this.needsMeasurement = !1, this.unresolvedKeyframes = [...e], this.onComplete = t, this.name = n, this.motionValue = r, this.element = i, this.isAsync = a
	}
	scheduleResolve() {
		this.state = "scheduled", this.isAsync ? (ra.add(this), ed || (ed = !0, Yt.read(Mv), Yt.resolveKeyframes(Av))) : (this.readKeyframes(), this.complete())
	}
	readKeyframes() {
		const {
			unresolvedKeyframes: e,
			name: t,
			element: n,
			motionValue: r
		} = this;
		if (null === e[0]) {
			const i = null == r ? void 0 : r.get(),
				a = e[e.length - 1];
			if (void 0 !== i) e[0] = i;
			else if (n && t) {
				const r = n.readValue(t, a);
				null != r && (e[0] = r)
			}
			void 0 === e[0] && (e[0] = a), r && void 0 === i && r.set(e[0])
		}
		YS(e)
	}
	setFinalKeyframe() { }
	measureInitialState() { }
	renderEndStyles() { }
	measureEndState() { }
	complete(e = !1) {
		this.state = "complete", this.onComplete(this.unresolvedKeyframes, this.finalKeyframe, e), ra.delete(this)
	}
	cancel() {
		"scheduled" === this.state && (ra.delete(this), this.state = "pending")
	}
	resume() {
		"pending" === this.state && this.scheduleResolve()
	}
}
const kS = e => e.startsWith("--");

function Cv(e, t, n) {
	kS(t) ? e.style.setProperty(t, n) : e.style[t] = n
}
const FS = {};

function Dv(e, t) {
	const n = tv(e);
	return () => FS[t] ?? n()
}
const IS = Dv(() => void 0 !== window.ScrollTimeline, "scrollTimeline"),
	Nv = Dv(() => {
		try {
			document.createElement("div").animate({
				opacity: 0
			}, {
				easing: "linear(0, 1)"
			})
		} catch {
			return !1
		}
		return !0
	}, "linearEasing"),
	ys = ([e, t, n, r]) => `cubic-bezier(${e}, ${t}, ${n}, ${r})`,
	Yy = {
		linear: "linear",
		ease: "ease",
		easeIn: "ease-in",
		easeOut: "ease-out",
		easeInOut: "ease-in-out",
		circIn: ys([0, .65, .55, 1]),
		circOut: ys([.55, 0, 1, .45]),
		backIn: ys([.31, .01, .66, -.59]),
		backOut: ys([.33, 1.53, .69, .99])
	};

function Ov(e, t) {
	if (e) return "function" == typeof e ? Nv() ? Sv(e, t) : "ease-out" : fv(e) ? ys(e) : Array.isArray(e) ? e.map(e => Ov(e, t) || Yy.easeOut) : Yy[e]
}

function $S(e, t, n, {
	delay: r = 0,
	duration: i = 300,
	repeat: a = 0,
	repeatType: o = "loop",
	ease: s = "easeOut",
	times: l
} = {}, u = void 0) {
	const c = {
		[t]: n
	};
	l && (c.offset = l);
	const d = Ov(s, i);
	Array.isArray(d) && (c.easing = d);
	const f = {
		delay: r,
		duration: i,
		easing: Array.isArray(d) ? "linear" : d,
		fill: "both",
		iterations: a + 1,
		direction: "reverse" === o ? "alternate" : "normal"
	};
	return u && (f.pseudoElement = u), e.animate(c, f)
}

function zv(e) {
	return "function" == typeof e && "applyToOptions" in e
}

function WS({
	type: e,
	...t
}) {
	return zv(e) && Nv() ? e.applyToOptions(t) : (t.duration ?? (t.duration = 300), t.ease ?? (t.ease = "easeOut"), t)
}
class wv extends Rd {
	constructor(e) {
		if (super(), this.finishedTime = null, this.isStopped = !1, this.manualStartTime = null, !e) return;
		const {
			element: t,
			name: n,
			keyframes: r,
			pseudoElement: i,
			allowFlatten: a = !1,
			finalKeyframe: o,
			onComplete: s
		} = e;
		this.isPseudoElement = !!i, this.allowFlatten = a, this.options = e, Uo("string" != typeof e.type);
		const l = WS(e);
		this.animation = $S(t, n, r, l, i), !1 === l.autoplay && this.animation.pause(), this.animation.onfinish = () => {
			if (this.finishedTime = this.time, !i) {
				const e = Lo(r, this.options, o, this.speed);
				this.updateMotionValue && this.updateMotionValue(e), Cv(t, n, e), this.animation.cancel()
			}
			null == s || s(), this.notifyFinished()
		}
	}
	play() {
		this.isStopped || (this.manualStartTime = null, this.animation.play(), "finished" === this.state && this.updateFinished())
	}
	pause() {
		this.animation.pause()
	}
	complete() {
		var e, t;
		null == (t = (e = this.animation).finish) || t.call(e)
	}
	cancel() {
		try {
			this.animation.cancel()
		} catch { }
	}
	stop() {
		if (this.isStopped) return;
		this.isStopped = !0;
		const {
			state: e
		} = this;
		"idle" === e || "finished" === e || (this.updateMotionValue ? this.updateMotionValue() : this.commitStyles(), this.isPseudoElement || this.cancel())
	}
	commitStyles() {
		var e, t, n;
		const r = null == (e = this.options) ? void 0 : e.element;
		!this.isPseudoElement && null != r && r.isConnected && (null == (n = (t = this.animation).commitStyles) || n.call(t))
	}
	get duration() {
		var e, t;
		const n = (null == (t = null == (e = this.animation.effect) ? void 0 : e.getComputedTiming) ? void 0 : t.call(e).duration) || 0;
		return on(Number(n))
	}
	get iterationDuration() {
		const {
			delay: e = 0
		} = this.options || {};
		return this.duration + on(e)
	}
	get time() {
		return on(Number(this.animation.currentTime) || 0)
	}
	set time(e) {
		const t = null !== this.finishedTime;
		this.manualStartTime = null, this.finishedTime = null, this.animation.currentTime = Fe(e), t && this.animation.pause()
	}
	get speed() {
		return this.animation.playbackRate
	}
	set speed(e) {
		e < 0 && (this.finishedTime = null), this.animation.playbackRate = e
	}
	get state() {
		return null !== this.finishedTime ? "finished" : this.animation.playState
	}
	get startTime() {
		return this.manualStartTime ?? Number(this.animation.startTime)
	}
	set startTime(e) {
		this.manualStartTime = this.animation.startTime = e
	}
	attachTimeline({
		timeline: e,
		rangeStart: t,
		rangeEnd: n,
		observe: r
	}) {
		var i;
		return this.allowFlatten && (null == (i = this.animation.effect) || i.updateTiming({
			easing: "linear"
		})), this.animation.onfinish = null, e && IS() ? (this.animation.timeline = e, t && (this.animation.rangeStart = t), n && (this.animation.rangeEnd = n), rn) : r(this)
	}
}
const _v = {
	anticipate: uv,
	backInOut: sv,
	circInOut: rv
};

function tT(e) {
	return e in _v
}

function eT(e) {
	"string" == typeof e.ease && tT(e.ease) && (e.ease = _v[e.ease])
}
const Vf = 10;
class nT extends wv {
	constructor(e) {
		eT(e), Ev(e), super(e), void 0 !== e.startTime && !1 !== e.autoplay && (this.startTime = e.startTime), this.options = e
	}
	updateMotionValue(e) {
		const {
			motionValue: t,
			onUpdate: n,
			onComplete: r,
			element: i,
			...a
		} = this.options;
		if (!t) return;
		if (void 0 !== e) return void t.set(e);
		const o = new Oo({
			...a,
			autoplay: !1
		}),
			s = Math.max(10, Oe.now() - this.startTime),
			l = Vn(0, 10, s - 10),
			u = o.sample(s).value,
			{
				name: c
			} = this.options;
		i && c && Cv(i, c, u), t.setWithVelocity(o.sample(Math.max(0, s - l)).value, u, l), o.stop()
	}
}
const Gy = (e, t) => "zIndex" !== t && !("number" != typeof e && !Array.isArray(e) && ("string" != typeof e || !vn.test(e) && "0" !== e || e.startsWith("url(")));

function iT(e) {
	const t = e[0];
	if (1 === e.length) return !0;
	for (let n = 0; n < e.length; n++)
		if (e[n] !== t) return !0
}

function aT(e, t, n, r) {
	const i = e[0];
	if (null === i) return !1;
	if ("display" === t || "visibility" === t) return !0;
	const a = e[e.length - 1],
		o = Gy(i, t),
		s = Gy(a, t);
	return !(!o || !s) && (iT(e) || ("spring" === n || zv(n)) && r)
}

function ad(e) {
	e.duration = 0, e.type = "keyframes"
}
const Rv = new Set(["opacity", "clipPath", "filter", "transform", "backgroundColor"]),
	lT = /^(?:oklch|oklab|lab|lch|color|color-mix|light-dark)\(/;

function sT(e) {
	for (let t = 0; t < e.length; t++)
		if ("string" == typeof e[t] && lT.test(e[t])) return !0;
	return !1
}
const uT = new Set(["color", "backgroundColor", "outlineColor", "fill", "stroke", "borderColor", "borderTopColor", "borderRightColor", "borderBottomColor", "borderLeftColor"]),
	oT = tv(() => Object.hasOwnProperty.call(Element.prototype, "animate"));

function rT(e) {
	var t;
	const {
		motionValue: n,
		name: r,
		repeatDelay: i,
		repeatType: a,
		damping: o,
		type: s,
		keyframes: l
	} = e, u = null == (t = null == n ? void 0 : n.owner) ? void 0 : t.current;
	if (!(u instanceof HTMLElement || u instanceof SVGElement)) return !1;
	const {
		onUpdate: c,
		transformTemplate: d
	} = n.owner.getProps();
	return oT() && r && (Rv.has(r) || uT.has(r) && sT(l)) && ("transform" !== r || !d) && !c && !i && "mirror" !== a && 0 !== o && "inertia" !== s
}
const cT = 40;
class fT extends Rd {
	constructor({
		autoplay: e = !0,
		delay: t = 0,
		type: n = "keyframes",
		repeat: r = 0,
		repeatDelay: i = 0,
		repeatType: a = "loop",
		keyframes: o,
		name: s,
		motionValue: l,
		element: u,
		...c
	}) {
		var d;
		super(), this.stop = () => {
			var e, t;
			this._animation && (this._animation.stop(), null == (e = this.stopTimeline) || e.call(this)), null == (t = this.keyframeResolver) || t.cancel()
		}, this.createdAt = Oe.now();
		const f = {
			autoplay: e,
			delay: t,
			type: n,
			repeat: r,
			repeatDelay: i,
			repeatType: a,
			name: s,
			motionValue: l,
			element: u,
			...c
		},
			h = (null == u ? void 0 : u.KeyframeResolver) || jd;
		this.keyframeResolver = new h(o, (e, t, n) => this.onKeyframesResolved(e, t, f, !n), s, l, u), null == (d = this.keyframeResolver) || d.scheduleResolve()
	}
	onKeyframesResolved(e, t, n, r) {
		var i, a;
		this.keyframeResolver = void 0;
		const {
			name: o,
			type: s,
			velocity: l,
			delay: u,
			isHandoff: c,
			onUpdate: d
		} = n;
		this.resolvedAt = Oe.now();
		let f = !0;
		aT(e, o, s, l) || (f = !1, (zi.instantAnimations || !u) && (null == d || d(Lo(e, n, t))), e[0] = e[e.length - 1], ad(n), n.repeat = 0);
		const h = {
			startTime: r ? this.resolvedAt && this.resolvedAt - this.createdAt > 40 ? this.resolvedAt : this.createdAt : void 0,
			finalKeyframe: t,
			...n,
			keyframes: e
		},
			p = f && !c && rT(h),
			m = null == (a = null == (i = h.motionValue) ? void 0 : i.owner) ? void 0 : a.current;
		let g;
		if (p) try {
			g = new nT({
				...h,
				element: m
			})
		} catch {
			g = new Oo(h)
		} else g = new Oo(h);
		g.finished.then(() => {
			this.notifyFinished()
		}).catch(rn), this.pendingTimeline && (this.stopTimeline = g.attachTimeline(this.pendingTimeline), this.pendingTimeline = void 0), this._animation = g
	}
	get finished() {
		return this._animation ? this.animation.finished : this._finished
	}
	then(e, t) {
		return this.finished.finally(e).then(() => { })
	}
	get animation() {
		var e;
		return this._animation || (null == (e = this.keyframeResolver) || e.resume(), JS()), this._animation
	}
	get duration() {
		return this.animation.duration
	}
	get iterationDuration() {
		return this.animation.iterationDuration
	}
	get time() {
		return this.animation.time
	}
	set time(e) {
		this.animation.time = e
	}
	get speed() {
		return this.animation.speed
	}
	get state() {
		return this.animation.state
	}
	set speed(e) {
		this.animation.speed = e
	}
	get startTime() {
		return this.animation.startTime
	}
	attachTimeline(e) {
		return this._animation ? this.stopTimeline = this.animation.attachTimeline(e) : this.pendingTimeline = e, () => this.stop()
	}
	play() {
		this.animation.play()
	}
	pause() {
		this.animation.pause()
	}
	complete() {
		this.animation.complete()
	}
	cancel() {
		var e;
		this._animation && this.animation.cancel(), null == (e = this.keyframeResolver) || e.cancel()
	}
}

function jv(e, t, n, r = 0, i = 1) {
	const a = Array.from(e).sort((e, t) => e.sortNodePosition(t)).indexOf(t),
		o = e.size,
		s = (o - 1) * r;
	return "function" == typeof n ? n(a, o) : 1 === i ? a * r : s - a * r
}
const qy = 30,
	dT = e => !isNaN(parseFloat(e));
class hT {
	constructor(e, t = {}) {
		this.canTrackVelocity = null, this.events = {}, this.updateAndNotify = e => {
			var t;
			const n = Oe.now();
			if (this.updatedAt !== n && this.setPrevFrameValue(), this.prev = this.current, this.setCurrent(e), this.current !== this.prev && (null == (t = this.events.change) || t.notify(this.current), this.dependents))
				for (const e of this.dependents) e.dirty()
		}, this.hasAnimated = !1, this.setCurrent(e), this.owner = t.owner
	}
	setCurrent(e) {
		this.current = e, this.updatedAt = Oe.now(), null === this.canTrackVelocity && void 0 !== e && (this.canTrackVelocity = dT(this.current))
	}
	setPrevFrameValue(e = this.current) {
		this.prevFrameValue = e, this.prevUpdatedAt = this.updatedAt
	}
	onChange(e) {
		return this.on("change", e)
	}
	on(e, t) {
		this.events[e] || (this.events[e] = new Md);
		const n = this.events[e].add(t);
		return "change" === e ? () => {
			n(), Yt.read(() => {
				this.events.change.getSize() || this.stop()
			})
		} : n
	}
	clearListeners() {
		for (const e in this.events) this.events[e].clear()
	}
	attach(e, t) {
		this.passiveEffect = e, this.stopPassiveEffect = t
	}
	set(e) {
		this.passiveEffect ? this.passiveEffect(e, this.updateAndNotify) : this.updateAndNotify(e)
	}
	setWithVelocity(e, t, n) {
		this.set(t), this.prev = void 0, this.prevFrameValue = e, this.prevUpdatedAt = this.updatedAt - n
	}
	jump(e, t = !0) {
		this.updateAndNotify(e), this.prev = e, this.prevUpdatedAt = this.prevFrameValue = void 0, t && this.stop(), this.stopPassiveEffect && this.stopPassiveEffect()
	}
	dirty() {
		var e;
		null == (e = this.events.change) || e.notify(this.current)
	}
	addDependent(e) {
		this.dependents || (this.dependents = new Set), this.dependents.add(e)
	}
	removeDependent(e) {
		this.dependents && this.dependents.delete(e)
	}
	get() {
		return this.current
	}
	getPrevious() {
		return this.prev
	}
	getVelocity() {
		const e = Oe.now();
		if (!this.canTrackVelocity || void 0 === this.prevFrameValue || e - this.updatedAt > 30) return 0;
		const t = Math.min(this.updatedAt - this.prevUpdatedAt, 30);
		return ev(parseFloat(this.current) - parseFloat(this.prevFrameValue), t)
	}
	start(e) {
		return this.stop(), new Promise(t => {
			this.hasAnimated = !0, this.animation = e(t), this.events.animationStart && this.events.animationStart.notify()
		}).then(() => {
			this.events.animationComplete && this.events.animationComplete.notify(), this.clearAnimation()
		})
	}
	stop() {
		this.animation && (this.animation.stop(), this.events.animationCancel && this.events.animationCancel.notify()), this.clearAnimation()
	}
	isAnimating() {
		return !!this.animation
	}
	clearAnimation() {
		delete this.animation
	}
	destroy() {
		var e, t;
		null == (e = this.dependents) || e.clear(), null == (t = this.events.destroy) || t.notify(), this.clearListeners(), this.stop(), this.stopPassiveEffect && this.stopPassiveEffect()
	}
}

function rl(e, t) {
	return new hT(e, t)
}

function Vv(e, t) {
	if (null != e && e.inherit && t) {
		const {
			inherit: n,
			...r
		} = e;
		return {
			...t,
			...r
		}
	}
	return e
}

function Vd(e, t) {
	const n = (null == e ? void 0 : e[t]) ?? (null == e ? void 0 : e.default) ?? e;
	return n !== e ? Vv(n, e) : n
}
const mT = {
	type: "spring",
	stiffness: 500,
	damping: 25,
	restSpeed: 10
},
	pT = e => ({
		type: "spring",
		stiffness: 550,
		damping: 0 === e ? 2 * Math.sqrt(550) : 30,
		restSpeed: 10
	}),
	yT = {
		type: "keyframes",
		duration: .8
	},
	gT = {
		type: "keyframes",
		ease: [.25, .1, .35, 1],
		duration: .3
	},
	vT = (e, {
		keyframes: t
	}) => t.length > 2 ? yT : dl.has(e) ? e.startsWith("scale") ? pT(t[1]) : mT : gT,
	bT = new Set(["when", "delay", "delayChildren", "staggerChildren", "staggerDirection", "repeat", "repeatType", "repeatDelay", "from", "elapsed"]);

function xT(e) {
	for (const t in e)
		if (!bT.has(t)) return !0;
	return !1
}
const Bd = (e, t, n, r = {}, i, a) => o => {
	const s = Vd(r, e) || {},
		l = s.delay || r.delay || 0;
	let {
		elapsed: u = 0
	} = r;
	u -= Fe(l);
	const c = {
		keyframes: Array.isArray(n) ? n : [null, n],
		ease: "easeOut",
		velocity: t.getVelocity(),
		...s,
		delay: -u,
		onUpdate: e => {
			t.set(e), s.onUpdate && s.onUpdate(e)
		},
		onComplete: () => {
			o(), s.onComplete && s.onComplete()
		},
		name: e,
		motionValue: t,
		element: a ? void 0 : i
	};
	xT(s) || Object.assign(c, vT(e, c)), c.duration && (c.duration = Fe(c.duration)), c.repeatDelay && (c.repeatDelay = Fe(c.repeatDelay)), void 0 !== c.from && (c.keyframes[0] = c.from);
	let d = !1;
	if ((!1 === c.type || 0 === c.duration && !c.repeatDelay) && (ad(c), 0 === c.delay && (d = !0)), (zi.instantAnimations || zi.skipAnimations || null != i && i.shouldSkipAnimations || s.skipAnimations) && (d = !0, ad(c), c.delay = 0), c.allowFlatten = !s.type && !s.ease, d && !a && void 0 !== t.get()) {
		const e = Lo(c.keyframes, s);
		if (void 0 !== e) return void Yt.update(() => {
			c.onUpdate(e), c.onComplete()
		})
	}
	return s.isSync ? new Oo(c) : new fT(c)
},
	ST = /^var\(--(?:([\w-]+)|([\w-]+), ?([a-zA-Z\d ()%#.,-]+))\)/u;

function TT(e) {
	const t = ST.exec(e);
	if (!t) return [,];
	const [, n, r, i] = t;
	return [`--${n ?? r}`, i]
}

function Bv(e, t, n = 1) {
	const [r, i] = TT(e);
	if (!r) return;
	const a = window.getComputedStyle(t).getPropertyValue(r);
	if (a) {
		const e = a.trim();
		return Ig(e) ? parseFloat(e) : e
	}
	return Nd(i) ? Bv(i, t, n + 1) : i
}

function Xy(e) {
	const t = [{}, {}];
	return null == e || e.values.forEach((e, n) => {
		t[0][n] = e.get(), t[1][n] = e.getVelocity()
	}), t
}

function Ud(e, t, n, r) {
	if ("function" == typeof t) {
		const [i, a] = Xy(r);
		t = t(void 0 !== n ? n : e.custom, i, a)
	}
	if ("string" == typeof t && (t = e.variants && e.variants[t]), "function" == typeof t) {
		const [i, a] = Xy(r);
		t = t(void 0 !== n ? n : e.custom, i, a)
	}
	return t
}

function ca(e, t, n) {
	const r = e.getProps();
	return Ud(r, t, void 0 !== n ? n : r.custom, e)
}
const Uv = new Set(["width", "height", "top", "left", "right", "bottom", ...fl]),
	ld = e => Array.isArray(e);

function ET(e, t, n) {
	e.hasValue(t) ? e.getValue(t).set(n) : e.addValue(t, rl(n))
}

function AT(e) {
	return ld(e) ? e[e.length - 1] || 0 : e
}

function MT(e, t) {
	const n = ca(e, t);
	let {
		transitionEnd: r = {},
		transition: i = {},
		...a
	} = n || {};
	a = {
		...a,
		...r
	};
	for (const t in a) {
		ET(e, t, AT(a[t]))
	}
}
const Te = e => !(!e || !e.getVelocity);

function CT(e) {
	return !(!Te(e) || !e.add)
}

function sd(e, t) {
	const n = e.getValue("willChange");
	if (CT(n)) return n.add(t);
	if (!n && zi.WillChange) {
		const n = new zi.WillChange("auto");
		e.addValue("willChange", n), n.add(t)
	}
}

function Ld(e) {
	return e.replace(/([A-Z])/g, e => `-${e.toLowerCase()}`)
}
const DT = "framerAppearId",
	Lv = "data-" + Ld(DT);

function Hv(e) {
	return e.props[Lv]
}

function NT({
	protectedKeys: e,
	needsAnimating: t
}, n) {
	const r = e.hasOwnProperty(n) && !0 !== t[n];
	return t[n] = !1, r
}

function Yv(e, t, {
	delay: n = 0,
	transitionOverride: r,
	type: i
} = {}) {
	let {
		transition: a,
		transitionEnd: o,
		...s
	} = t;
	const l = e.getDefaultTransition();
	a = a ? Vv(a, l) : l;
	const u = null == a ? void 0 : a.reduceMotion,
		c = null == a ? void 0 : a.skipAnimations;
	r && (a = r);
	const d = [],
		f = i && e.animationState && e.animationState.getState()[i],
		h = null == a ? void 0 : a.path;
	h && h.animateVisualElement(e, s, a, n, d);
	for (const t in s) {
		const r = e.getValue(t, e.latestValues[t] ?? null),
			i = s[t];
		if (void 0 === i || f && NT(f, t)) continue;
		const o = {
			delay: n,
			...Vd(a || {}, t)
		};
		c && (o.skipAnimations = !0);
		const l = r.get();
		if (void 0 !== l && !r.isAnimating() && !Array.isArray(i) && i === l && !o.velocity) {
			Yt.update(() => r.set(i));
			continue
		}
		let h = !1;
		if (window.MotionHandoffAnimation) {
			const n = Hv(e);
			if (n) {
				const e = window.MotionHandoffAnimation(n, t, Yt);
				null !== e && (o.startTime = e, h = !0)
			}
		}
		sd(e, t);
		const p = u ?? e.shouldReduceMotion;
		r.start(Bd(t, r, i, p && Uv.has(t) ? {
			type: !1
		} : o, e, h));
		const m = r.animation;
		m && d.push(m)
	}
	if (o) {
		const t = () => Yt.update(() => {
			o && MT(e, o)
		});
		d.length ? Promise.all(d).then(t) : t()
	}
	return d
}

function ud(e, t, n = {}) {
	var r;
	const i = ca(e, t, "exit" === n.type ? null == (r = e.presenceContext) ? void 0 : r.custom : void 0);
	let {
		transition: a = e.getDefaultTransition() || {}
	} = i || {};
	n.transitionOverride && (a = n.transitionOverride);
	const o = i ? () => Promise.all(Yv(e, i, n)) : () => Promise.resolve(),
		s = e.variantChildren && e.variantChildren.size ? (r = 0) => {
			const {
				delayChildren: i = 0,
				staggerChildren: o,
				staggerDirection: s
			} = a;
			return OT(e, t, r, i, o, s, n)
		} : () => Promise.resolve(),
		{
			when: l
		} = a;
	if (l) {
		const [e, t] = "beforeChildren" === l ? [o, s] : [s, o];
		return e().then(() => t())
	}
	return Promise.all([o(), s(n.delay)])
}

function OT(e, t, n = 0, r = 0, i = 0, a = 1, o) {
	const s = [];
	for (const l of e.variantChildren) l.notify("AnimationStart", t), s.push(ud(l, t, {
		...o,
		delay: n + ("function" == typeof r ? 0 : r) + jv(e.variantChildren, l, r, i, a)
	}).then(() => l.notify("AnimationComplete", t)));
	return Promise.all(s)
}

function zT(e, t, n = {}) {
	let r;
	if (e.notify("AnimationStart", t), Array.isArray(t)) {
		const i = t.map(t => ud(e, t, n));
		r = Promise.all(i)
	} else if ("string" == typeof t) r = ud(e, t, n);
	else {
		const i = "function" == typeof t ? ca(e, t, n.custom) : t;
		r = Promise.all(Yv(e, i, n))
	}
	return r.then(() => {
		e.notify("AnimationComplete", t)
	})
}
const wT = {
	test: e => "auto" === e,
	parse: e => e
},
	Gv = e => t => t.test(e),
	qv = [cl, at, jn, $n, iS, nS, wT],
	Qy = e => qv.find(Gv(e));

function _T(e) {
	return "number" == typeof e ? 0 === e : null === e || ("none" === e || "0" === e || Wg(e))
}
const RT = new Set(["brightness", "contrast", "saturate", "opacity"]);

function jT(e) {
	const [t, n] = e.slice(0, -1).split("(");
	if ("drop-shadow" === t) return e;
	const [r] = n.match(Od) || [];
	if (!r) return e;
	const i = n.replace(r, "");
	let a = RT.has(t) ? 1 : 0;
	return r !== n && (a *= 100), t + "(" + a + i + ")"
}
const VT = /\b([a-z-]*)\(.*?\)/gu,
	od = {
		...vn,
		getAnimatableNone: e => {
			const t = e.match(VT);
			return t ? t.map(jT).join(" ") : e
		}
	},
	rd = {
		...vn,
		getAnimatableNone: e => {
			const t = vn.parse(e);
			return vn.createTransformer(e)(t.map(e => "number" == typeof e ? 0 : "object" == typeof e ? {
				...e,
				alpha: 1
			} : e))
		}
	},
	Zy = {
		...cl,
		transform: Math.round
	},
	BT = {
		rotate: $n,
		pathRotation: $n,
		rotateX: $n,
		rotateY: $n,
		rotateZ: $n,
		scale: ho,
		scaleX: ho,
		scaleY: ho,
		scaleZ: ho,
		skew: $n,
		skewX: $n,
		skewY: $n,
		distance: at,
		translateX: at,
		translateY: at,
		translateZ: at,
		x: at,
		y: at,
		z: at,
		perspective: at,
		transformPerspective: at,
		opacity: As,
		originX: wy,
		originY: wy,
		originZ: at
	},
	zo = {
		borderWidth: at,
		borderTopWidth: at,
		borderRightWidth: at,
		borderBottomWidth: at,
		borderLeftWidth: at,
		borderRadius: at,
		borderTopLeftRadius: at,
		borderTopRightRadius: at,
		borderBottomRightRadius: at,
		borderBottomLeftRadius: at,
		width: at,
		maxWidth: at,
		height: at,
		maxHeight: at,
		top: at,
		right: at,
		bottom: at,
		left: at,
		inset: at,
		insetBlock: at,
		insetBlockStart: at,
		insetBlockEnd: at,
		insetInline: at,
		insetInlineStart: at,
		insetInlineEnd: at,
		padding: at,
		paddingTop: at,
		paddingRight: at,
		paddingBottom: at,
		paddingLeft: at,
		paddingBlock: at,
		paddingBlockStart: at,
		paddingBlockEnd: at,
		paddingInline: at,
		paddingInlineStart: at,
		paddingInlineEnd: at,
		margin: at,
		marginTop: at,
		marginRight: at,
		marginBottom: at,
		marginLeft: at,
		marginBlock: at,
		marginBlockStart: at,
		marginBlockEnd: at,
		marginInline: at,
		marginInlineStart: at,
		marginInlineEnd: at,
		fontSize: at,
		backgroundPositionX: at,
		backgroundPositionY: at,
		...BT,
		zIndex: Zy,
		fillOpacity: As,
		strokeOpacity: As,
		numOctaves: Zy
	},
	UT = {
		...zo,
		color: ie,
		backgroundColor: ie,
		outlineColor: ie,
		fill: ie,
		stroke: ie,
		borderColor: ie,
		borderTopColor: ie,
		borderRightColor: ie,
		borderBottomColor: ie,
		borderLeftColor: ie,
		filter: od,
		WebkitFilter: od,
		mask: rd,
		WebkitMask: rd
	},
	Xv = e => UT[e],
	LT = new Set([od, rd]);

function Qv(e, t) {
	let n = Xv(e);
	return LT.has(n) || (n = vn), n.getAnimatableNone ? n.getAnimatableNone(t) : void 0
}
const HT = new Set(["auto", "none", "0"]);

function YT(e, t, n) {
	let r, i = 0;
	for (; i < e.length && !r;) {
		const t = e[i];
		"string" == typeof t && !HT.has(t) && ol(t).values.length && (r = e[i]), i++
	}
	if (r && n)
		for (const i of t) e[i] = Qv(n, r)
}
class GT extends jd {
	constructor(e, t, n, r, i) {
		super(e, t, n, r, i, !0)
	}
	readKeyframes() {
		const {
			unresolvedKeyframes: e,
			element: t,
			name: n
		} = this;
		if (!t || !t.current) return;
		super.readKeyframes();
		for (let n = 0; n < e.length; n++) {
			let r = e[n];
			if ("string" == typeof r && (r = r.trim(), Nd(r))) {
				const i = Bv(r, t.current);
				void 0 !== i && (e[n] = i), n === e.length - 1 && (this.finalKeyframe = r)
			}
		}
		if (this.resolveNoneKeyframes(), !Uv.has(n) || 2 !== e.length) return;
		const [r, i] = e, a = Qy(r), o = Qy(i);
		if (zy(r) !== zy(i) && Oi[n]) this.needsMeasurement = !0;
		else if (a !== o)
			if (Hy(a) && Hy(o))
				for (let t = 0; t < e.length; t++) {
					const n = e[t];
					"string" == typeof n && (e[t] = parseFloat(n))
				} else Oi[n] && (this.needsMeasurement = !0)
	}
	resolveNoneKeyframes() {
		const {
			unresolvedKeyframes: e,
			name: t
		} = this, n = [];
		for (let t = 0; t < e.length; t++)(null === e[t] || _T(e[t])) && n.push(t);
		n.length && YT(e, n, t)
	}
	measureInitialState() {
		const {
			element: e,
			unresolvedKeyframes: t,
			name: n
		} = this;
		if (!e || !e.current) return;
		"height" === n && (this.suspendedScrollY = window.pageYOffset), this.measuredOrigin = Oi[n](e.measureViewportBox(), window.getComputedStyle(e.current)), t[0] = this.measuredOrigin;
		const r = t[t.length - 1];
		void 0 !== r && e.getValue(n, r).jump(r, !1)
	}
	measureEndState() {
		var e;
		const {
			element: t,
			name: n,
			unresolvedKeyframes: r
		} = this;
		if (!t || !t.current) return;
		const i = t.getValue(n);
		i && i.jump(this.measuredOrigin, !1);
		const a = r.length - 1,
			o = r[a];
		r[a] = Oi[n](t.measureViewportBox(), window.getComputedStyle(t.current)), null !== o && void 0 === this.finalKeyframe && (this.finalKeyframe = o), null != (e = this.removedTransforms) && e.length && this.removedTransforms.forEach(([e, n]) => {
			t.getValue(e).set(n)
		}), this.resolveNoneKeyframes()
	}
}
const Hd = ["borderTopLeftRadius", "borderTopRightRadius", "borderBottomRightRadius", "borderBottomLeftRadius"];

function Zv(e, t, n) {
	if (null == e) return [];
	if (e instanceof EventTarget) return [e];
	if ("string" == typeof e) {
		let t = document;
		const r = (null == n ? void 0 : n[e]) ?? t.querySelectorAll(e);
		return r ? Array.from(r) : []
	}
	return Array.from(e).filter(e => null != e)
}
const cd = (e, t) => t && "number" == typeof e ? t.transform(e) : e;

function vo(e) {
	return $g(e) && "offsetHeight" in e && !("ownerSVGElement" in e)
}
const {
	schedule: Yd
} = dv(queueMicrotask, !1), gn = {
	x: !1,
	y: !1
};

function Kv() {
	return gn.x || gn.y
}

function qT(e) {
	return "x" === e || "y" === e ? gn[e] ? null : (gn[e] = !0, () => {
		gn[e] = !1
	}) : gn.x || gn.y ? null : (gn.x = gn.y = !0, () => {
		gn.x = gn.y = !1
	})
}

function Pv(e, t) {
	const n = Zv(e),
		r = new AbortController;
	return [n, {
		passive: !0,
		...t,
		signal: r.signal
	}, () => r.abort()]
}

function XT(e) {
	return !("touch" === e.pointerType || Kv())
}

function QT(e, t, n = {}) {
	const [r, i, a] = Pv(e, n);
	return r.forEach(e => {
		let n, r = !1,
			a = !1;
		const o = t => {
			n && (n(t), n = void 0), e.removeEventListener("pointerleave", l)
		},
			s = e => {
				r = !1, window.removeEventListener("pointerup", s), window.removeEventListener("pointercancel", s), a && (a = !1, o(e))
			},
			l = e => {
				if ("touch" !== e.pointerType) {
					if (r) return void (a = !0);
					o(e)
				}
			};
		e.addEventListener("pointerenter", r => {
			if (!XT(r)) return;
			a = !1;
			const o = t(e, r);
			"function" == typeof o && (n = o, e.addEventListener("pointerleave", l, i))
		}, i), e.addEventListener("pointerdown", () => {
			r = !0, window.addEventListener("pointerup", s, i), window.addEventListener("pointercancel", s, i)
		}, i)
	}), a
}
const Jv = (e, t) => !!t && (e === t || Jv(e, t.parentElement)),
	Gd = e => "mouse" === e.pointerType ? "number" != typeof e.button || e.button <= 0 : !1 !== e.isPrimary,
	ZT = new Set(["BUTTON", "INPUT", "SELECT", "TEXTAREA", "A"]);

function KT(e) {
	return ZT.has(e.tagName) || !0 === e.isContentEditable
}
const PT = new Set(["INPUT", "SELECT", "TEXTAREA"]);

function JT(e) {
	return PT.has(e.tagName) || !0 === e.isContentEditable
}
const bo = new WeakSet;

function Ky(e) {
	return t => {
		"Enter" === t.key && e(t)
	}
}

function Bf(e, t) {
	e.dispatchEvent(new PointerEvent("pointer" + t, {
		isPrimary: !0,
		bubbles: !0
	}))
}
const kT = (e, t) => {
	const n = e.currentTarget;
	if (!n) return;
	const r = Ky(() => {
		if (bo.has(n)) return;
		Bf(n, "down");
		const e = Ky(() => {
			Bf(n, "up")
		});
		n.addEventListener("keyup", e, t), n.addEventListener("blur", () => Bf(n, "cancel"), t)
	});
	n.addEventListener("keydown", r, t), n.addEventListener("blur", () => n.removeEventListener("keydown", r), t)
};

function Py(e) {
	return Gd(e) && !Kv()
}
const Jy = new WeakSet;

function FT(e, t, n = {}) {
	const [r, i, a] = Pv(e, n), o = e => {
		const r = e.currentTarget;
		if (!Py(e) || Jy.has(e)) return;
		bo.add(r), n.stopPropagation && Jy.add(e);
		const a = t(r, e),
			o = {
				...i,
				capture: !0
			},
			s = (e, t) => {
				window.removeEventListener("pointerup", l, o), window.removeEventListener("pointercancel", u, o), bo.has(r) && bo.delete(r), Py(e) && "function" == typeof a && a(e, {
					success: t
				})
			},
			l = e => {
				s(e, r === window || r === document || n.useGlobalTarget || Jv(r, e.target))
			},
			u = e => {
				s(e, !1)
			};
		window.addEventListener("pointerup", l, o), window.addEventListener("pointercancel", u, o)
	};
	return r.forEach(e => {
		(n.useGlobalTarget ? window : e).addEventListener("pointerdown", o, i), vo(e) && (e.addEventListener("focus", e => kT(e, i)), !KT(e) && !e.hasAttribute("tabindex") && (e.tabIndex = 0))
	}), a
}

function qd(e) {
	return $g(e) && "ownerSVGElement" in e
}
const xo = new WeakMap;
let Ni;
const kv = (e, t, n) => (r, i) => i && i[0] ? i[0][e + "Size"] : qd(r) && "getBBox" in r ? r.getBBox()[t] : r[n],
	IT = kv("inline", "width", "offsetWidth"),
	$T = kv("block", "height", "offsetHeight");

function WT({
	target: e,
	borderBoxSize: t
}) {
	var n;
	null == (n = xo.get(e)) || n.forEach(n => {
		n(e, {
			get width() {
				return IT(e, t)
			},
			get height() {
				return $T(e, t)
			}
		})
	})
}

function tE(e) {
	e.forEach(WT)
}

function eE() {
	typeof ResizeObserver > "u" || (Ni = new ResizeObserver(tE))
}

function nE(e, t) {
	Ni || eE();
	const n = Zv(e);
	return n.forEach(e => {
		let n = xo.get(e);
		n || (n = new Set, xo.set(e, n)), n.add(t), null == Ni || Ni.observe(e)
	}), () => {
		n.forEach(e => {
			const n = xo.get(e);
			null == n || n.delete(t), null != n && n.size || null == Ni || Ni.unobserve(e)
		})
	}
}
const So = new Set;
let sl;

function iE() {
	sl = () => {
		const e = {
			get width() {
				return window.innerWidth
			},
			get height() {
				return window.innerHeight
			}
		};
		So.forEach(t => t(e))
	}, window.addEventListener("resize", sl)
}

function aE(e) {
	return So.add(e), sl || iE(), () => {
		So.delete(e), !So.size && "function" == typeof sl && (window.removeEventListener("resize", sl), sl = void 0)
	}
}

function ky(e, t) {
	return "function" == typeof e ? aE(e) : nE(e, t)
}

function lE(e) {
	return qd(e) && "svg" === e.tagName
}
const sE = [...qv, ie, vn],
	uE = e => sE.find(Gv(e)),
	Fy = () => ({
		translate: 0,
		scale: 1,
		origin: 0,
		originPoint: 0
	}),
	ul = () => ({
		x: Fy(),
		y: Fy()
	}),
	Iy = () => ({
		min: 0,
		max: 0
	}),
	se = () => ({
		x: Iy(),
		y: Iy()
	}),
	oE = new WeakMap;

function Ho(e) {
	return null !== e && "object" == typeof e && "function" == typeof e.start
}

function Ms(e) {
	return "string" == typeof e || Array.isArray(e)
}
const Xd = ["animate", "whileInView", "whileFocus", "whileHover", "whileTap", "whileDrag", "exit"],
	Qd = ["initial", ...Xd];

function Yo(e) {
	return Ho(e.animate) || Qd.some(t => Ms(e[t]))
}

function Fv(e) {
	return !(!Yo(e) && !e.variants)
}

function rE(e, t, n) {
	for (const r in t) {
		const i = t[r],
			a = n[r];
		if (Te(i)) e.addValue(r, i);
		else if (Te(a)) e.addValue(r, rl(i, {
			owner: e
		}));
		else if (a !== i)
			if (e.hasValue(r)) {
				const t = e.getValue(r);
				!0 === t.liveStyle ? t.jump(i) : t.hasAnimated || t.set(i)
			} else {
				const t = e.getStaticValue(r);
				e.addValue(r, rl(void 0 !== t ? t : i, {
					owner: e
				}))
			}
	}
	for (const r in n) void 0 === t[r] && e.removeValue(r);
	return t
}
const fd = {
	current: null
},
	Iv = {
		current: !1
	},
	cE = typeof window < "u";

function fE() {
	if (Iv.current = !0, cE)
		if (window.matchMedia) {
			const e = window.matchMedia("(prefers-reduced-motion)"),
				t = () => fd.current = e.matches;
			e.addEventListener("change", t), t()
		} else fd.current = !1
}
const $y = ["AnimationStart", "AnimationComplete", "Update", "BeforeLayoutMeasure", "LayoutMeasure", "LayoutAnimationStart", "LayoutAnimationComplete"];
let wo = {};

function $v(e) {
	wo = e
}

function dE() {
	return wo
}
class hE {
	scrapeMotionValuesFromProps(e, t, n) {
		return {}
	}
	constructor({
		parent: e,
		props: t,
		presenceContext: n,
		reducedMotionConfig: r,
		skipAnimations: i,
		blockInitialAnimation: a,
		visualState: o
	}, s = {}) {
		this.current = null, this.children = new Set, this.isVariantNode = !1, this.isControllingVariants = !1, this.shouldReduceMotion = null, this.shouldSkipAnimations = !1, this.values = new Map, this.KeyframeResolver = jd, this.features = {}, this.valueSubscriptions = new Map, this.prevMotionValues = {}, this.hasBeenMounted = !1, this.events = {}, this.propEventSubscriptions = {}, this.notifyUpdate = () => this.notify("Update", this.latestValues), this.render = () => {
			this.current && (this.triggerBuild(), this.renderInstance(this.current, this.renderState, this.props.style, this.projection))
		}, this.renderScheduledAt = 0, this.scheduleRender = () => {
			const e = Oe.now();
			this.renderScheduledAt < e && (this.renderScheduledAt = e, Yt.render(this.render, !1, !0))
		};
		const {
			latestValues: l,
			renderState: u
		} = o;
		this.latestValues = l, this.baseTarget = {
			...l
		}, this.initialValues = t.initial ? {
			...l
		} : {}, this.renderState = u, this.parent = e, this.props = t, this.presenceContext = n, this.depth = e ? e.depth + 1 : 0, this.reducedMotionConfig = r, this.skipAnimationsConfig = i, this.options = s, this.blockInitialAnimation = !!a, this.isControllingVariants = Yo(t), this.isVariantNode = Fv(t), this.isVariantNode && (this.variantChildren = new Set), this.manuallyAnimateOnMount = !(!e || !e.current);
		const {
			willChange: c,
			...d
		} = this.scrapeMotionValuesFromProps(t, {}, this);
		for (const e in d) {
			const t = d[e];
			void 0 !== l[e] && Te(t) && t.set(l[e])
		}
	}
	mount(e) {
		var t, n;
		if (this.hasBeenMounted)
			for (const e in this.initialValues) null == (t = this.values.get(e)) || t.jump(this.initialValues[e]), this.latestValues[e] = this.initialValues[e];
		this.current = e, oE.set(e, this), this.projection && !this.projection.instance && this.projection.mount(e), this.parent && this.isVariantNode && !this.isControllingVariants && (this.removeFromVariantTree = this.parent.addVariantChild(this)), this.values.forEach((e, t) => this.bindToMotionValue(t, e)), "never" === this.reducedMotionConfig ? this.shouldReduceMotion = !1 : "always" === this.reducedMotionConfig ? this.shouldReduceMotion = !0 : (Iv.current || fE(), this.shouldReduceMotion = fd.current), this.shouldSkipAnimations = this.skipAnimationsConfig ?? !1, null == (n = this.parent) || n.addChild(this), this.update(this.props, this.presenceContext), this.hasBeenMounted = !0
	}
	unmount() {
		var e;
		this.projection && this.projection.unmount(), wi(this.notifyUpdate), wi(this.render), this.valueSubscriptions.forEach(e => e()), this.valueSubscriptions.clear(), this.removeFromVariantTree && this.removeFromVariantTree(), null == (e = this.parent) || e.removeChild(this);
		for (const e in this.events) this.events[e].clear();
		for (const e in this.features) {
			const t = this.features[e];
			t && (t.unmount(), t.isMounted = !1)
		}
		this.current = null
	}
	addChild(e) {
		this.children.add(e), this.enteringChildren ?? (this.enteringChildren = new Set), this.enteringChildren.add(e)
	}
	removeChild(e) {
		this.children.delete(e), this.enteringChildren && this.enteringChildren.delete(e)
	}
	bindToMotionValue(e, t) {
		if (this.valueSubscriptions.has(e) && this.valueSubscriptions.get(e)(), t.accelerate && Rv.has(e) && this.current instanceof HTMLElement) {
			const {
				factory: n,
				keyframes: r,
				times: i,
				ease: a,
				duration: o
			} = t.accelerate, s = new wv({
				element: this.current,
				name: e,
				keyframes: r,
				times: i,
				ease: a,
				duration: Fe(o)
			}), l = n(s);
			return void this.valueSubscriptions.set(e, () => {
				l(), s.cancel()
			})
		}
		const n = dl.has(e);
		n && this.onBindTransform && this.onBindTransform();
		const r = t.on("change", t => {
			this.latestValues[e] = t, this.props.onUpdate && Yt.preRender(this.notifyUpdate), n && this.projection && (this.projection.isTransformDirty = !0), this.scheduleRender()
		});
		let i;
		typeof window < "u" && window.MotionCheckAppearSync && (i = window.MotionCheckAppearSync(this, e, t)), this.valueSubscriptions.set(e, () => {
			r(), i && i()
		})
	}
	sortNodePosition(e) {
		return this.current && this.sortInstanceNodePosition && this.type === e.type ? this.sortInstanceNodePosition(this.current, e.current) : 0
	}
	updateFeatures() {
		let e = "animation";
		for (e in wo) {
			const t = wo[e];
			if (!t) continue;
			const {
				isEnabled: n,
				Feature: r
			} = t;
			if (!this.features[e] && r && n(this.props) && (this.features[e] = new r(this)), this.features[e]) {
				const t = this.features[e];
				t.isMounted ? t.update() : (t.mount(), t.isMounted = !0)
			}
		}
	}
	triggerBuild() {
		this.build(this.renderState, this.latestValues, this.props)
	}
	measureViewportBox() {
		return this.current ? this.measureInstanceViewportBox(this.current, this.props) : se()
	}
	getStaticValue(e) {
		return this.latestValues[e]
	}
	setStaticValue(e, t) {
		this.latestValues[e] = t
	}
	update(e, t) {
		(e.transformTemplate || this.props.transformTemplate) && this.scheduleRender(), this.prevProps = this.props, this.props = e, this.prevPresenceContext = this.presenceContext, this.presenceContext = t;
		for (let t = 0; t < $y.length; t++) {
			const n = $y[t];
			this.propEventSubscriptions[n] && (this.propEventSubscriptions[n](), delete this.propEventSubscriptions[n]);
			const r = e["on" + n];
			r && (this.propEventSubscriptions[n] = this.on(n, r))
		}
		this.prevMotionValues = rE(this, this.scrapeMotionValuesFromProps(e, this.prevProps || {}, this), this.prevMotionValues), this.handleChildMotionValue && this.handleChildMotionValue()
	}
	getProps() {
		return this.props
	}
	getVariant(e) {
		return this.props.variants ? this.props.variants[e] : void 0
	}
	getDefaultTransition() {
		return this.props.transition
	}
	getTransformPagePoint() {
		return this.props.transformPagePoint
	}
	getClosestVariantNode() {
		return this.isVariantNode ? this : this.parent ? this.parent.getClosestVariantNode() : void 0
	}
	addVariantChild(e) {
		const t = this.getClosestVariantNode();
		if (t) return t.variantChildren && t.variantChildren.add(e), () => t.variantChildren.delete(e)
	}
	addValue(e, t) {
		const n = this.values.get(e);
		t !== n && (n && this.removeValue(e), this.bindToMotionValue(e, t), this.values.set(e, t), this.latestValues[e] = t.get())
	}
	removeValue(e) {
		this.values.delete(e);
		const t = this.valueSubscriptions.get(e);
		t && (t(), this.valueSubscriptions.delete(e)), delete this.latestValues[e], this.removeValueFromRenderState(e, this.renderState)
	}
	hasValue(e) {
		return this.values.has(e)
	}
	getValue(e, t) {
		if (this.props.values && this.props.values[e]) return this.props.values[e];
		let n = this.values.get(e);
		return void 0 === n && void 0 !== t && (n = rl(null === t ? void 0 : t, {
			owner: this
		}), this.addValue(e, n)), n
	}
	readValue(e, t) {
		let n = void 0 === this.latestValues[e] && this.current ? this.getBaseTargetFromProps(this.props, e) ?? this.readValueFromInstance(this.current, e, this.options) : this.latestValues[e];
		return null != n && ("string" == typeof n && (Ig(n) || Wg(n)) ? n = parseFloat(n) : !uE(n) && vn.test(t) && (n = Qv(e, t)), this.setBaseTarget(e, Te(n) ? n.get() : n)), Te(n) ? n.get() : n
	}
	setBaseTarget(e, t) {
		this.baseTarget[e] = t
	}
	getBaseTarget(e) {
		var t;
		const {
			initial: n
		} = this.props;
		let r;
		if ("string" == typeof n || "object" == typeof n) {
			const i = Ud(this.props, n, null == (t = this.presenceContext) ? void 0 : t.custom);
			i && (r = i[e])
		}
		if (n && void 0 !== r) return r;
		const i = this.getBaseTargetFromProps(this.props, e);
		return void 0 === i || Te(i) ? void 0 !== this.initialValues[e] && void 0 === r ? void 0 : this.baseTarget[e] : i
	}
	on(e, t) {
		return this.events[e] || (this.events[e] = new Md), this.events[e].add(t)
	}
	notify(e, ...t) {
		this.events[e] && this.events[e].notify(...t)
	}
	scheduleRenderMicrotask() {
		Yd.render(this.render)
	}
}
class Wv extends hE {
	constructor() {
		super(...arguments), this.KeyframeResolver = GT
	}
	sortInstanceNodePosition(e, t) {
		return 2 & e.compareDocumentPosition(t) ? 1 : -1
	}
	getBaseTargetFromProps(e, t) {
		const n = e.style;
		return n ? n[t] : void 0
	}
	removeValueFromRenderState(e, {
		vars: t,
		style: n
	}) {
		delete t[e], delete n[e]
	}
	handleChildMotionValue() {
		this.childSubscription && (this.childSubscription(), delete this.childSubscription);
		const {
			children: e
		} = this.props;
		Te(e) && (this.childSubscription = e.on("change", e => {
			this.current && (this.current.textContent = `${e}`)
		}))
	}
}
class _i {
	constructor(e) {
		this.isMounted = !1, this.node = e
	}
	update() { }
}

function t1({
	top: e,
	left: t,
	right: n,
	bottom: r
}) {
	return {
		x: {
			min: t,
			max: n
		},
		y: {
			min: e,
			max: r
		}
	}
}

function mE({
	x: e,
	y: t
}) {
	return {
		top: t.min,
		right: e.max,
		bottom: t.max,
		left: e.min
	}
}

function pE(e, t) {
	if (!t) return e;
	const n = t({
		x: e.left,
		y: e.top
	}),
		r = t({
			x: e.right,
			y: e.bottom
		});
	return {
		top: n.y,
		left: n.x,
		bottom: r.y,
		right: r.x
	}
}

function Uf(e) {
	return void 0 === e || 1 === e
}

function dd({
	scale: e,
	scaleX: t,
	scaleY: n
}) {
	return !Uf(e) || !Uf(t) || !Uf(n)
}

function sa(e) {
	return dd(e) || e1(e) || e.z || e.rotate || e.rotateX || e.rotateY || e.skewX || e.skewY
}

function e1(e) {
	return Wy(e.x) || Wy(e.y)
}

function Wy(e) {
	return e && "0%" !== e
}

function _o(e, t, n) {
	return n + t * (e - n)
}

function tg(e, t, n, r, i) {
	return void 0 !== i && (e = _o(e, i, r)), _o(e, n, r) + t
}

function hd(e, t = 0, n = 1, r, i) {
	e.min = tg(e.min, t, n, r, i), e.max = tg(e.max, t, n, r, i)
}

function n1(e, {
	x: t,
	y: n
}) {
	hd(e.x, t.translate, t.scale, t.originPoint), hd(e.y, n.translate, n.scale, n.originPoint)
}
const eg = .999999999999,
	ng = 1.0000000000001;

function yE(e, t, n, r = !1) {
	var i;
	const a = n.length;
	if (!a) return;
	let o, s;
	t.x = t.y = 1;
	for (let l = 0; l < a; l++) {
		o = n[l], s = o.projectionDelta;
		const {
			visualElement: a
		} = o.options;
		a && a.props.style && "contents" === a.props.style.display || (r && o.options.layoutScroll && o.scroll && o !== o.root && (Rn(e.x, -o.scroll.offset.x), Rn(e.y, -o.scroll.offset.y)), s && (t.x *= s.x.scale, t.y *= s.y.scale, n1(e, s)), r && sa(o.latestValues) && To(e, o.latestValues, null == (i = o.layout) ? void 0 : i.layoutBox))
	}
	t.x < ng && t.x > eg && (t.x = 1), t.y < ng && t.y > eg && (t.y = 1)
}

function Rn(e, t) {
	e.min += t, e.max += t
}

function ig(e, t, n, r, i = .5) {
	hd(e, t, n, Ht(e.min, e.max, i), r)
}

function ag(e, t) {
	return "string" == typeof e ? parseFloat(e) / 100 * (t.max - t.min) : e
}

function To(e, t, n) {
	const r = n ?? e;
	ig(e.x, ag(t.x, r.x), t.scaleX, t.scale, t.originX), ig(e.y, ag(t.y, r.y), t.scaleY, t.scale, t.originY)
}

function i1(e, t) {
	return t1(pE(e.getBoundingClientRect(), t))
}

function gE(e, t, n) {
	const r = i1(e, n),
		{
			scroll: i
		} = t;
	return i && (Rn(r.x, i.offset.x), Rn(r.y, i.offset.y)), r
}
const vE = {
	x: "translateX",
	y: "translateY",
	z: "translateZ",
	transformPerspective: "perspective"
},
	bE = fl.length;

function xE(e, t, n) {
	let r = "",
		i = !0;
	for (let a = 0; a < bE; a++) {
		const o = fl[a],
			s = e[o];
		if (void 0 === s) continue;
		let l = !0;
		if ("number" == typeof s) l = s === (o.startsWith("scale") ? 1 : 0);
		else {
			const e = parseFloat(s);
			l = o.startsWith("scale") ? 1 === e : 0 === e
		}
		if (!l || n) {
			const e = cd(s, zo[o]);
			if (!l) {
				i = !1;
				r += `${vE[o] || o}(${e}) `
			}
			n && (t[o] = e)
		}
	}
	const a = e.pathRotation;
	return a && (i = !1, r += `rotate(${cd(a, zo.pathRotation)}) `), r = r.trim(), n ? r = n(t, i ? "" : r) : i && (r = "none"), r
}

function Zd(e, t, n) {
	const {
		style: r,
		vars: i,
		transformOrigin: a
	} = e;
	let o = !1,
		s = !1;
	for (const e in t) {
		const n = t[e];
		if (dl.has(e)) o = !0;
		else if (mv(e)) i[e] = n;
		else {
			const t = cd(n, zo[e]);
			e.startsWith("origin") ? (s = !0, a[e] = t) : r[e] = t
		}
	}
	if (t.transform || (o || n ? r.transform = xE(t, e.transform, n) : r.transform && (r.transform = "none")), s) {
		const {
			originX: e = "50%",
			originY: t = "50%",
			originZ: n = 0
		} = a;
		r.transformOrigin = `${e} ${t} ${n}`
	}
}

function a1(e, {
	style: t,
	vars: n
}, r, i) {
	const a = e.style;
	let o;
	for (o in t) a[o] = t[o];
	for (o in null == i || i.applyProjectionStyles(a, r), n) a.setProperty(o, n[o])
}

function lg(e, t) {
	return t.max === t.min ? 0 : e / (t.max - t.min) * 100
}
const ps = {
	correct: (e, t) => {
		if (!t.target) return e;
		if ("string" == typeof e) {
			if (!at.test(e)) return e;
			e = parseFloat(e)
		}
		return `${lg(e, t.target.x)}% ${lg(e, t.target.y)}%`
	}
},
	SE = {
		correct: (e, {
			treeScale: t,
			projectionDelta: n
		}) => {
			const r = e,
				i = vn.parse(e);
			if (i.length > 5) return r;
			const a = vn.createTransformer(e),
				o = "number" != typeof i[0] ? 1 : 0,
				s = n.x.scale * t.x,
				l = n.y.scale * t.y;
			i[0 + o] /= s, i[1 + o] /= l;
			const u = Ht(s, l, .5);
			return "number" == typeof i[2 + o] && (i[2 + o] /= u), "number" == typeof i[3 + o] && (i[3 + o] /= u), a(i)
		}
	},
	md = {
		borderRadius: {
			...ps,
			applyTo: [...Hd]
		},
		borderTopLeftRadius: ps,
		borderTopRightRadius: ps,
		borderBottomLeftRadius: ps,
		borderBottomRightRadius: ps,
		boxShadow: SE
	};

function l1(e, {
	layout: t,
	layoutId: n
}) {
	return dl.has(e) || e.startsWith("origin") || (t || void 0 !== n) && (!!md[e] || "opacity" === e)
}

function Kd(e, t, n) {
	var r;
	const i = e.style,
		a = null == t ? void 0 : t.style,
		o = {};
	if (!i) return o;
	for (const t in i) (Te(i[t]) || a && Te(a[t]) || l1(t, e) || void 0 !== (null == (r = null == n ? void 0 : n.getValue(t)) ? void 0 : r.liveStyle)) && (o[t] = i[t]);
	return o
}

function TE(e) {
	return window.getComputedStyle(e)
}
class EE extends Wv {
	constructor() {
		super(...arguments), this.type = "html", this.renderInstance = a1
	}
	mount(e) {
		Uo(!!e.style), super.mount(e)
	}
	readValueFromInstance(e, t) {
		var n;
		if (dl.has(t)) return null != (n = this.projection) && n.isProjecting ? Wf(t) : XS(e, t);
		{
			const n = TE(e),
				r = (mv(t) ? n.getPropertyValue(t) : n[t]) || 0;
			return "string" == typeof r ? r.trim() : r
		}
	}
	measureInstanceViewportBox(e, {
		transformPagePoint: t
	}) {
		return i1(e, t)
	}
	build(e, t, n) {
		Zd(e, t, n.transformTemplate)
	}
	scrapeMotionValuesFromProps(e, t, n) {
		return Kd(e, t, n)
	}
}
const AE = {
	offset: "stroke-dashoffset",
	array: "stroke-dasharray"
},
	ME = {
		offset: "strokeDashoffset",
		array: "strokeDasharray"
	};

function CE(e, t, n = 1, r = 0, i = !0) {
	e.pathLength = 1;
	const a = i ? AE : ME;
	e[a.offset] = "" + -r, e[a.array] = `${t} ${n}`
}
const DE = ["offsetDistance", "offsetPath", "offsetRotate", "offsetAnchor"];

function s1(e, {
	attrX: t,
	attrY: n,
	attrScale: r,
	pathLength: i,
	pathSpacing: a = 1,
	pathOffset: o = 0,
	...s
}, l, u, c) {
	if (Zd(e, s, u), l) return void (e.style.viewBox && (e.attrs.viewBox = e.style.viewBox));
	e.attrs = e.style, e.style = {};
	const {
		attrs: d,
		style: f
	} = e;
	d.transform && (f.transform = d.transform, delete d.transform), (f.transform || d.transformOrigin) && (f.transformOrigin = d.transformOrigin ?? "50% 50%", delete d.transformOrigin), f.transform && (f.transformBox = (null == c ? void 0 : c.transformBox) ?? "fill-box", delete d.transformBox);
	for (const e of DE) void 0 !== d[e] && (f[e] = d[e], delete d[e]);
	void 0 !== t && (d.x = t), void 0 !== n && (d.y = n), void 0 !== r && (d.scale = r), void 0 !== i && CE(d, i, a, o, !1)
}
const u1 = new Set(["baseFrequency", "diffuseConstant", "kernelMatrix", "kernelUnitLength", "keySplines", "keyTimes", "limitingConeAngle", "markerHeight", "markerWidth", "numOctaves", "targetX", "targetY", "surfaceScale", "specularConstant", "specularExponent", "stdDeviation", "tableValues", "viewBox", "gradientTransform", "pathLength", "startOffset", "textLength", "lengthAdjust"]),
	o1 = e => "string" == typeof e && "svg" === e.toLowerCase();

function NE(e, t, n, r) {
	a1(e, t, void 0, r);
	for (const n in t.attrs) e.setAttribute(u1.has(n) ? n : Ld(n), t.attrs[n])
}

function r1(e, t, n) {
	const r = Kd(e, t, n);
	for (const n in e)
		if (Te(e[n]) || Te(t[n])) {
			r[-1 !== fl.indexOf(n) ? "attr" + n.charAt(0).toUpperCase() + n.substring(1) : n] = e[n]
		} return r
}
class OE extends Wv {
	constructor() {
		super(...arguments), this.type = "svg", this.isSVGTag = !1, this.measureInstanceViewportBox = se
	}
	getBaseTargetFromProps(e, t) {
		return e[t]
	}
	readValueFromInstance(e, t) {
		if (dl.has(t)) {
			const e = Xv(t);
			return e && e.default || 0
		}
		return t = u1.has(t) ? t : Ld(t), e.getAttribute(t)
	}
	scrapeMotionValuesFromProps(e, t, n) {
		return r1(e, t, n)
	}
	build(e, t, n) {
		s1(e, t, this.isSVGTag, n.transformTemplate, n.style)
	}
	renderInstance(e, t, n, r) {
		NE(e, t, n, r)
	}
	mount(e) {
		this.isSVGTag = o1(e.tagName), super.mount(e)
	}
}
const zE = Qd.length;

function c1(e) {
	if (!e) return;
	if (!e.isControllingVariants) {
		const t = e.parent && c1(e.parent) || {};
		return void 0 !== e.props.initial && (t.initial = e.props.initial), t
	}
	const t = {};
	for (let n = 0; n < zE; n++) {
		const r = Qd[n],
			i = e.props[r];
		(Ms(i) || !1 === i) && (t[r] = i)
	}
	return t
}

function f1(e, t) {
	if (!Array.isArray(t)) return !1;
	const n = t.length;
	if (n !== e.length) return !1;
	for (let r = 0; r < n; r++)
		if (t[r] !== e[r]) return !1;
	return !0
}
const wE = [...Xd].reverse(),
	_E = Xd.length;

function RE(e) {
	return t => Promise.all(t.map(({
		animation: t,
		options: n
	}) => zT(e, t, n)))
}

function jE(e) {
	let t = RE(e),
		n = sg(),
		r = !0,
		i = !1;
	const a = t => (n, r) => {
		var i;
		const a = ca(e, r, "exit" === t ? null == (i = e.presenceContext) ? void 0 : i.custom : void 0);
		if (a) {
			const {
				transition: e,
				transitionEnd: t,
				...r
			} = a;
			n = {
				...n,
				...r,
				...t
			}
		}
		return n
	};

	function o(o) {
		const {
			props: s
		} = e, l = c1(e.parent) || {}, u = [], c = new Set;
		let d = {},
			f = 1 / 0;
		for (let t = 0; t < _E; t++) {
			const h = wE[t],
				p = n[h],
				m = void 0 !== s[h] ? s[h] : l[h],
				g = Ms(m),
				v = h === o ? p.isActive : null;
			!1 === v && (f = t);
			let y = m === l[h] && m !== s[h] && g;
			if (y && (r || i) && e.manuallyAnimateOnMount && (y = !1), p.protectedKeys = {
				...d
			}, !p.isActive && null === v || !m && !p.prevProp || Ho(m) || "boolean" == typeof m) continue;
			if ("exit" === h && p.isActive && !0 !== v) {
				p.prevResolvedValues && (d = {
					...d,
					...p.prevResolvedValues
				});
				continue
			}
			const b = VE(p.prevProp, m);
			let x = b || h === o && p.isActive && !y && g || t > f && g,
				w = !1;
			const S = Array.isArray(m) ? m : [m];
			let E = S.reduce(a(h), {});
			!1 === v && (E = {});
			const {
				prevResolvedValues: k = {}
			} = p, T = {
				...k,
				...E
			}, P = t => {
				x = !0, c.has(t) && (w = !0, c.delete(t)), p.needsAnimating[t] = !0;
				const n = e.getValue(t);
				n && (n.liveStyle = !1)
			};
			for (const e in T) {
				const t = E[e],
					n = k[e];
				if (d.hasOwnProperty(e)) continue;
				let r = !1;
				r = ld(t) && ld(n) ? !f1(t, n) || b : t !== n, r ? null != t ? P(e) : c.add(e) : void 0 !== t && c.has(e) ? P(e) : p.protectedKeys[e] = !0
			}
			p.prevProp = m, p.prevResolvedValues = E, p.isActive && (d = {
				...d,
				...E
			}), (r || i) && e.blockInitialAnimation && (x = !1);
			const C = y && b;
			x && (!C || w) && u.push(...S.map(t => {
				const n = {
					type: h
				};
				if ("string" == typeof t && (r || i) && !C && e.manuallyAnimateOnMount && e.parent) {
					const {
						parent: r
					} = e, i = ca(r, t);
					if (r.enteringChildren && i) {
						const {
							delayChildren: t
						} = i.transition || {};
						n.delay = jv(r.enteringChildren, e, t)
					}
				}
				return {
					animation: t,
					options: n
				}
			}))
		}
		if (c.size) {
			const t = {};
			if ("boolean" != typeof s.initial) {
				const n = ca(e, Array.isArray(s.initial) ? s.initial[0] : s.initial);
				n && n.transition && (t.transition = n.transition)
			}
			c.forEach(n => {
				const r = e.getBaseTarget(n),
					i = e.getValue(n);
				i && (i.liveStyle = !0), t[n] = r ?? null
			}), u.push({
				animation: t
			})
		}
		let h = !!u.length;
		return r && (!1 === s.initial || s.initial === s.animate) && !e.manuallyAnimateOnMount && (h = !1), r = !1, i = !1, h ? t(u) : Promise.resolve()
	}
	return {
		animateChanges: o,
		setActive: function (t, r) {
			var i;
			if (n[t].isActive === r) return Promise.resolve();
			null == (i = e.variantChildren) || i.forEach(e => {
				var n;
				return null == (n = e.animationState) ? void 0 : n.setActive(t, r)
			}), n[t].isActive = r;
			const a = o(t);
			for (const e in n) n[e].protectedKeys = {};
			return a
		},
		setAnimateFunction: function (n) {
			t = n(e)
		},
		getState: () => n,
		reset: () => {
			n = sg(), i = !0
		}
	}
}

function VE(e, t) {
	return "string" == typeof t ? t !== e : !!Array.isArray(t) && !f1(t, e)
}

function la(e = !1) {
	return {
		isActive: e,
		protectedKeys: {},
		needsAnimating: {},
		prevResolvedValues: {}
	}
}

function sg() {
	return {
		animate: la(!0),
		whileInView: la(),
		whileHover: la(),
		whileTap: la(),
		whileDrag: la(),
		whileFocus: la(),
		exit: la()
	}
}

function pd(e, t) {
	e.min = t.min, e.max = t.max
}

function yn(e, t) {
	pd(e.x, t.x), pd(e.y, t.y)
}

function ug(e, t) {
	e.translate = t.translate, e.scale = t.scale, e.originPoint = t.originPoint, e.origin = t.origin
}
const d1 = 1e-4,
	BE = 1 - d1,
	UE = 1 + d1,
	h1 = .01,
	LE = 0 - h1,
	HE = .01;

function ze(e) {
	return e.max - e.min
}

function YE(e, t, n) {
	return Math.abs(e - t) <= n
}

function og(e, t, n, r = .5) {
	e.origin = r, e.originPoint = Ht(t.min, t.max, e.origin), e.scale = ze(n) / ze(t), e.translate = Ht(n.min, n.max, e.origin) - e.originPoint, (e.scale >= BE && e.scale <= UE || isNaN(e.scale)) && (e.scale = 1), (e.translate >= LE && e.translate <= HE || isNaN(e.translate)) && (e.translate = 0)
}

function xs(e, t, n, r) {
	og(e.x, t.x, n.x, r ? r.originX : void 0), og(e.y, t.y, n.y, r ? r.originY : void 0)
}

function rg(e, t, n, r = 0) {
	const i = r ? Ht(n.min, n.max, r) : n.min;
	e.min = i + t.min, e.max = e.min + ze(t)
}

function GE(e, t, n, r) {
	rg(e.x, t.x, n.x, null == r ? void 0 : r.x), rg(e.y, t.y, n.y, null == r ? void 0 : r.y)
}

function cg(e, t, n, r = 0) {
	const i = r ? Ht(n.min, n.max, r) : n.min;
	e.min = t.min - i, e.max = e.min + ze(t)
}

function Ro(e, t, n, r) {
	cg(e.x, t.x, n.x, null == r ? void 0 : r.x), cg(e.y, t.y, n.y, null == r ? void 0 : r.y)
}

function fg(e, t, n, r, i) {
	return e = _o(e -= t, 1 / n, r), void 0 !== i && (e = _o(e, 1 / i, r)), e
}

function qE(e, t = 0, n = 1, r = .5, i, a = e, o = e) {
	if (jn.test(t) && (t = parseFloat(t), t = Ht(o.min, o.max, t / 100) - o.min), "number" != typeof t) return;
	let s = Ht(a.min, a.max, r);
	e === a && (s -= t), e.min = fg(e.min, t, n, s, i), e.max = fg(e.max, t, n, s, i)
}

function dg(e, t, [n, r, i], a, o) {
	qE(e, t[n], t[r], t[i], t.scale, a, o)
}
const XE = ["x", "scaleX", "originX"],
	QE = ["y", "scaleY", "originY"];

function hg(e, t, n, r) {
	dg(e.x, t, XE, n ? n.x : void 0, r ? r.x : void 0), dg(e.y, t, QE, n ? n.y : void 0, r ? r.y : void 0)
}

function mg(e) {
	return 0 === e.translate && 1 === e.scale
}

function m1(e) {
	return mg(e.x) && mg(e.y)
}

function pg(e, t) {
	return e.min === t.min && e.max === t.max
}

function ZE(e, t) {
	return pg(e.x, t.x) && pg(e.y, t.y)
}

function yg(e, t) {
	return Math.round(e.min) === Math.round(t.min) && Math.round(e.max) === Math.round(t.max)
}

function p1(e, t) {
	return yg(e.x, t.x) && yg(e.y, t.y)
}

function gg(e) {
	return ze(e.x) / ze(e.y)
}

function vg(e, t) {
	return e.translate === t.translate && e.scale === t.scale && e.originPoint === t.originPoint
}

function _n(e) {
	return [e("x"), e("y")]
}

function KE(e, t, n) {
	let r = "";
	const i = e.x.translate / t.x,
		a = e.y.translate / t.y,
		o = (null == n ? void 0 : n.z) || 0;
	if ((i || a || o) && (r = `translate3d(${i}px, ${a}px, ${o}px) `), (1 !== t.x || 1 !== t.y) && (r += `scale(${1 / t.x}, ${1 / t.y}) `), n) {
		const {
			transformPerspective: e,
			rotate: t,
			pathRotation: i,
			rotateX: a,
			rotateY: o,
			skewX: s,
			skewY: l
		} = n;
		e && (r = `perspective(${e}px) ${r}`), t && (r += `rotate(${t}deg) `), i && (r += `rotate(${i}deg) `), a && (r += `rotateX(${a}deg) `), o && (r += `rotateY(${o}deg) `), s && (r += `skewX(${s}deg) `), l && (r += `skewY(${l}deg) `)
	}
	const s = e.x.scale * t.x,
		l = e.y.scale * t.y;
	return (1 !== s || 1 !== l) && (r += `scale(${s}, ${l})`), r || "none"
}
const PE = Hd.length,
	bg = e => "string" == typeof e ? parseFloat(e) : e,
	xg = e => "number" == typeof e || at.test(e);

function JE(e, t, n, r, i, a) {
	i ? (e.opacity = Ht(0, n.opacity ?? 1, kE(r)), e.opacityExit = Ht(t.opacity ?? 1, 0, FE(r))) : a && (e.opacity = Ht(t.opacity ?? 1, n.opacity ?? 1, r));
	for (let i = 0; i < PE; i++) {
		const a = Hd[i];
		let o = Sg(t, a),
			s = Sg(n, a);
		void 0 === o && void 0 === s || (o || (o = 0), s || (s = 0), 0 === o || 0 === s || xg(o) === xg(s) ? (e[a] = Math.max(Ht(bg(o), bg(s), r), 0), (jn.test(s) || jn.test(o)) && (e[a] += "%")) : e[a] = s)
	} (t.rotate || n.rotate) && (e.rotate = Ht(t.rotate || 0, n.rotate || 0, r))
}

function Sg(e, t) {
	return void 0 !== e[t] ? e[t] : e.borderRadius
}
const kE = y1(0, .5, ov),
	FE = y1(.5, .95, rn);

function y1(e, t, n) {
	return r => r < e ? 0 : r > t ? 1 : n(Es(e, t, r))
}

function IE(e, t, n) {
	const r = Te(e) ? e : rl(e);
	return r.start(Bd("", r, t, n)), r.animation
}

function Cs(e, t, n, r = {
	passive: !0
}) {
	return e.addEventListener(t, n, r), () => e.removeEventListener(t, n, r)
}
const $E = (e, t) => e.depth - t.depth;
class WE {
	constructor() {
		this.children = [], this.isDirty = !1
	}
	add(e) {
		Ad(this.children, e), this.isDirty = !0
	}
	remove(e) {
		Mo(this.children, e), this.isDirty = !0
	}
	forEach(e) {
		this.isDirty && this.children.sort($E), this.isDirty = !1, this.children.forEach(e)
	}
}

function tA(e, t) {
	const n = Oe.now(),
		r = ({
			timestamp: i
		}) => {
			const a = i - n;
			a >= t && (wi(r), e(a - t))
		};
	return Yt.setup(r, !0), () => wi(r)
}

function Eo(e) {
	return Te(e) ? e.get() : e
}
class eA {
	constructor() {
		this.members = []
	}
	add(e) {
		Ad(this.members, e);
		for (let t = this.members.length - 1; t >= 0; t--) {
			const n = this.members[t];
			if (n === e || n === this.lead || n === this.prevLead) continue;
			const r = n.instance;
			(!r || !1 === r.isConnected) && !n.snapshot && (Mo(this.members, n), n.unmount())
		}
		e.scheduleRender()
	}
	remove(e) {
		if (Mo(this.members, e), e === this.prevLead && (this.prevLead = void 0), e === this.lead) {
			const e = this.members[this.members.length - 1];
			e && this.promote(e)
		}
	}
	relegate(e) {
		var t;
		for (let n = this.members.indexOf(e) - 1; n >= 0; n--) {
			const e = this.members[n];
			if (!1 !== e.isPresent && !1 !== (null == (t = e.instance) ? void 0 : t.isConnected)) return this.promote(e), !0
		}
		return !1
	}
	promote(e, t) {
		var n;
		const r = this.lead;
		if (e !== r && (this.prevLead = r, this.lead = e, e.show(), r)) {
			r.updateSnapshot(), e.scheduleRender();
			const {
				layoutDependency: i
			} = r.options, {
				layoutDependency: a
			} = e.options;
			(void 0 === i || i !== a) && (e.resumeFrom = r, t && (r.preserveOpacity = !0), r.snapshot && (e.snapshot = r.snapshot, e.snapshot.latestValues = r.animationValues || r.latestValues), null != (n = e.root) && n.isUpdating && (e.isLayoutDirty = !0)), !1 === e.options.crossfade && r.hide()
		}
	}
	exitAnimationComplete() {
		this.members.forEach(e => {
			var t, n, r, i, a;
			null == (n = (t = e.options).onExitComplete) || n.call(t), null == (a = null == (r = e.resumingFrom) ? void 0 : (i = r.options).onExitComplete) || a.call(i)
		})
	}
	scheduleRender() {
		this.members.forEach(e => e.instance && e.scheduleRender(!1))
	}
	removeLeadSnapshot() {
		var e;
		null != (e = this.lead) && e.snapshot && (this.lead.snapshot = void 0)
	}
}
const Ao = {
	hasAnimatedSinceResize: !0,
	hasEverUpdated: !1
},
	Lf = ["", "X", "Y", "Z"],
	nA = 1e3;
let iA = 0;

function Hf(e, t, n, r) {
	const {
		latestValues: i
	} = t;
	i[e] && (n[e] = i[e], t.setStaticValue(e, 0), r && (r[e] = 0))
}

function g1(e) {
	if (e.hasCheckedOptimisedAppear = !0, e.root === e) return;
	const {
		visualElement: t
	} = e.options;
	if (!t) return;
	const n = Hv(t);
	if (window.MotionHasOptimisedAnimation(n, "transform")) {
		const {
			layout: t,
			layoutId: r
		} = e.options;
		window.MotionCancelOptimisedAnimation(n, "transform", Yt, !(t || r))
	}
	const {
		parent: r
	} = e;
	r && !r.hasCheckedOptimisedAppear && g1(r)
}

function v1({
	attachResizeListener: e,
	defaultParent: t,
	measureScroll: n,
	checkIsScrollRoot: r,
	resetTransform: i
}) {
	return class {
		constructor(e = {}, n = (null == t ? void 0 : t())) {
			this.id = iA++, this.animationId = 0, this.animationCommitId = 0, this.children = new Set, this.options = {}, this.isTreeAnimating = !1, this.isAnimationBlocked = !1, this.isLayoutDirty = !1, this.isProjectionDirty = !1, this.isSharedProjectionDirty = !1, this.isTransformDirty = !1, this.updateManuallyBlocked = !1, this.updateBlockedByResize = !1, this.isUpdating = !1, this.isSVG = !1, this.needsReset = !1, this.shouldResetTransform = !1, this.hasCheckedOptimisedAppear = !1, this.treeScale = {
				x: 1,
				y: 1
			}, this.eventHandlers = new Map, this.hasTreeAnimated = !1, this.layoutVersion = 0, this.updateScheduled = !1, this.scheduleUpdate = () => this.update(), this.projectionUpdateScheduled = !1, this.checkUpdateFailed = () => {
				this.isUpdating && (this.isUpdating = !1, this.clearAllSnapshots())
			}, this.updateProjection = () => {
				this.projectionUpdateScheduled = !1, this.nodes.forEach(sA), this.nodes.forEach(dA), this.nodes.forEach(hA), this.nodes.forEach(uA)
			}, this.resolvedRelativeTargetAt = 0, this.linkedParentVersion = 0, this.hasProjected = !1, this.isVisible = !0, this.animationProgress = 0, this.sharedNodes = new Map, this.latestValues = e, this.root = n ? n.root || n : this, this.path = n ? [...n.path, n] : [], this.parent = n, this.depth = n ? n.depth + 1 : 0;
			for (let e = 0; e < this.path.length; e++) this.path[e].shouldResetTransform = !0;
			this.root === this && (this.nodes = new WE)
		}
		addEventListener(e, t) {
			return this.eventHandlers.has(e) || this.eventHandlers.set(e, new Md), this.eventHandlers.get(e).add(t)
		}
		notifyListeners(e, ...t) {
			const n = this.eventHandlers.get(e);
			n && n.notify(...t)
		}
		hasListeners(e) {
			return this.eventHandlers.has(e)
		}
		mount(t) {
			if (this.instance) return;
			this.isSVG = qd(t) && !lE(t), this.instance = t;
			const {
				layoutId: n,
				layout: r,
				visualElement: i
			} = this.options;
			if (i && !i.current && i.mount(t), this.root.nodes.add(this), this.parent && this.parent.children.add(this), this.root.hasTreeAnimated && (r || n) && (this.isLayoutDirty = !0), e) {
				let n, r = 0;
				const i = () => this.root.updateBlockedByResize = !1;
				Yt.read(() => {
					r = window.innerWidth
				}), e(t, () => {
					const e = window.innerWidth;
					e !== r && (r = e, this.root.updateBlockedByResize = !0, n && n(), n = tA(i, 250), Ao.hasAnimatedSinceResize && (Ao.hasAnimatedSinceResize = !1, this.nodes.forEach(Ag)))
				})
			}
			n && this.root.registerSharedNode(n, this), !1 !== this.options.animate && i && (n || r) && this.addEventListener("didUpdate", ({
				delta: e,
				hasLayoutChanged: t,
				hasRelativeLayoutChanged: n,
				layout: r
			}) => {
				if (this.isTreeAnimationBlocked()) return this.target = void 0, void (this.relativeTarget = void 0);
				const a = this.options.transition || i.getDefaultTransition() || vA,
					{
						onLayoutAnimationStart: o,
						onLayoutAnimationComplete: s
					} = i.getProps(),
					l = !this.targetLayout || !p1(this.targetLayout, r),
					u = !t && n;
				if (this.options.layoutRoot || this.resumeFrom || u || t && (l || !this.currentAnimation)) {
					this.resumeFrom && (this.resumingFrom = this.resumeFrom, this.resumingFrom.resumingFrom = void 0);
					const t = {
						...Vd(a, "layout"),
						onPlay: o,
						onComplete: s
					};
					(i.shouldReduceMotion || this.options.layoutRoot) && (t.delay = 0, t.type = !1), this.startAnimation(t), this.setAnimationOrigin(e, u, t.path)
				} else t || Ag(this), this.isLead() && this.options.onExitComplete && this.options.onExitComplete();
				this.targetLayout = r
			})
		}
		unmount() {
			this.options.layoutId && this.willUpdate(), this.root.nodes.remove(this);
			const e = this.getStack();
			e && e.remove(this), this.parent && this.parent.children.delete(this), this.instance = void 0, this.eventHandlers.clear(), wi(this.updateProjection)
		}
		blockUpdate() {
			this.updateManuallyBlocked = !0
		}
		unblockUpdate() {
			this.updateManuallyBlocked = !1
		}
		isUpdateBlocked() {
			return this.updateManuallyBlocked || this.updateBlockedByResize
		}
		isTreeAnimationBlocked() {
			return this.isAnimationBlocked || this.parent && this.parent.isTreeAnimationBlocked() || !1
		}
		startUpdate() {
			this.isUpdateBlocked() || (this.isUpdating = !0, this.nodes && this.nodes.forEach(mA), this.animationId++)
		}
		getTransformTemplate() {
			const {
				visualElement: e
			} = this.options;
			return e && e.getProps().transformTemplate
		}
		willUpdate(e = !0) {
			if (this.root.hasTreeAnimated = !0, this.root.isUpdateBlocked()) return void (this.options.onExitComplete && this.options.onExitComplete());
			if (window.MotionCancelOptimisedAnimation && !this.hasCheckedOptimisedAppear && g1(this), !this.root.isUpdating && this.root.startUpdate(), this.isLayoutDirty) return;
			this.isLayoutDirty = !0;
			for (let e = 0; e < this.path.length; e++) {
				const t = this.path[e];
				t.shouldResetTransform = !0, ("string" == typeof t.latestValues.x || "string" == typeof t.latestValues.y) && (t.isLayoutDirty = !0), t.updateScroll("snapshot"), t.options.layoutRoot && t.willUpdate(!1)
			}
			const {
				layoutId: t,
				layout: n
			} = this.options;
			if (void 0 === t && !n) return;
			const r = this.getTransformTemplate();
			this.prevTransformTemplateValue = r ? r(this.latestValues, "") : void 0, this.updateSnapshot(), e && this.notifyListeners("willUpdate")
		}
		update() {
			if (this.updateScheduled = !1, this.isUpdateBlocked()) {
				const e = this.updateBlockedByResize;
				return this.unblockUpdate(), this.updateBlockedByResize = !1, this.clearAllSnapshots(), e && this.nodes.forEach(rA), void this.nodes.forEach(Tg)
			}
			if (this.animationId <= this.animationCommitId) return void this.nodes.forEach(Eg);
			this.animationCommitId = this.animationId, this.isUpdating ? (this.isUpdating = !1, this.nodes.forEach(cA), this.nodes.forEach(fA), this.nodes.forEach(aA), this.nodes.forEach(lA)) : this.nodes.forEach(Eg), this.clearAllSnapshots();
			const e = Oe.now();
			xe.delta = Vn(0, 1e3 / 60, e - xe.timestamp), xe.timestamp = e, xe.isProcessing = !0, zf.update.process(xe), zf.preRender.process(xe), zf.render.process(xe), xe.isProcessing = !1
		}
		didUpdate() {
			this.updateScheduled || (this.updateScheduled = !0, Yd.read(this.scheduleUpdate))
		}
		clearAllSnapshots() {
			this.nodes.forEach(oA), this.sharedNodes.forEach(pA)
		}
		scheduleUpdateProjection() {
			this.projectionUpdateScheduled || (this.projectionUpdateScheduled = !0, Yt.preRender(this.updateProjection, !1, !0))
		}
		scheduleCheckAfterUnmount() {
			Yt.postRender(() => {
				this.isLayoutDirty ? this.root.didUpdate() : this.root.checkUpdateFailed()
			})
		}
		updateSnapshot() {
			this.snapshot || !this.instance || (this.snapshot = this.measure(), this.snapshot && !ze(this.snapshot.measuredBox.x) && !ze(this.snapshot.measuredBox.y) && (this.snapshot = void 0))
		}
		updateLayout() {
			if (!(this.instance && (this.updateScroll(), this.options.alwaysMeasureLayout && this.isLead() || this.isLayoutDirty))) return;
			if (this.resumeFrom && !this.resumeFrom.instance)
				for (let e = 0; e < this.path.length; e++) this.path[e].updateScroll();
			const e = this.layout;
			this.layout = this.measure(!1), this.layoutVersion++, this.layoutCorrected || (this.layoutCorrected = se()), this.isLayoutDirty = !1, this.projectionDelta = void 0, this.notifyListeners("measure", this.layout.layoutBox);
			const {
				visualElement: t
			} = this.options;
			t && t.notify("LayoutMeasure", this.layout.layoutBox, e ? e.layoutBox : void 0)
		}
		updateScroll(e = "measure") {
			let t = !(!this.options.layoutScroll || !this.instance);
			if (this.scroll && this.scroll.animationId === this.root.animationId && this.scroll.phase === e && (t = !1), t && this.instance) {
				const t = r(this.instance);
				this.scroll = {
					animationId: this.root.animationId,
					phase: e,
					isRoot: t,
					offset: n(this.instance),
					wasRoot: this.scroll ? this.scroll.isRoot : t
				}
			}
		}
		resetTransform() {
			if (!i) return;
			const e = this.isLayoutDirty || this.shouldResetTransform || this.options.alwaysMeasureLayout,
				t = this.projectionDelta && !m1(this.projectionDelta),
				n = this.getTransformTemplate(),
				r = n ? n(this.latestValues, "") : void 0,
				a = r !== this.prevTransformTemplateValue;
			e && this.instance && (t || sa(this.latestValues) || a) && (i(this.instance, r), this.shouldResetTransform = !1, this.scheduleRender())
		}
		measure(e = !0) {
			const t = this.measurePageBox();
			let n = this.removeElementScroll(t);
			return e && (n = this.removeTransform(n)), bA(n), {
				animationId: this.root.animationId,
				measuredBox: t,
				layoutBox: n,
				latestValues: {},
				source: this.id
			}
		}
		measurePageBox() {
			var e;
			const {
				visualElement: t
			} = this.options;
			if (!t) return se();
			const n = t.measureViewportBox();
			if (!(null == (e = this.scroll) ? void 0 : e.wasRoot) && !this.path.some(xA)) {
				const {
					scroll: e
				} = this.root;
				e && (Rn(n.x, e.offset.x), Rn(n.y, e.offset.y))
			}
			return n
		}
		removeElementScroll(e) {
			var t;
			const n = se();
			if (yn(n, e), null != (t = this.scroll) && t.wasRoot) return n;
			for (let t = 0; t < this.path.length; t++) {
				const r = this.path[t],
					{
						scroll: i,
						options: a
					} = r;
				r !== this.root && i && a.layoutScroll && (i.wasRoot && yn(n, e), Rn(n.x, i.offset.x), Rn(n.y, i.offset.y))
			}
			return n
		}
		applyTransform(e, t = !1, n) {
			var r, i;
			const a = n || se();
			yn(a, e);
			for (let e = 0; e < this.path.length; e++) {
				const n = this.path[e];
				!t && n.options.layoutScroll && n.scroll && n !== n.root && (Rn(a.x, -n.scroll.offset.x), Rn(a.y, -n.scroll.offset.y)), sa(n.latestValues) && To(a, n.latestValues, null == (r = n.layout) ? void 0 : r.layoutBox)
			}
			return sa(this.latestValues) && To(a, this.latestValues, null == (i = this.layout) ? void 0 : i.layoutBox), a
		}
		removeTransform(e) {
			var t;
			const n = se();
			yn(n, e);
			for (let e = 0; e < this.path.length; e++) {
				const r = this.path[e];
				if (!sa(r.latestValues)) continue;
				let i;
				r.instance && (dd(r.latestValues) && r.updateSnapshot(), i = se(), yn(i, r.measurePageBox())), hg(n, r.latestValues, null == (t = r.snapshot) ? void 0 : t.layoutBox, i)
			}
			return sa(this.latestValues) && hg(n, this.latestValues), n
		}
		setTargetDelta(e) {
			this.targetDelta = e, this.root.scheduleUpdateProjection(), this.isProjectionDirty = !0
		}
		setOptions(e) {
			this.options = {
				...this.options,
				...e,
				crossfade: void 0 === e.crossfade || e.crossfade
			}
		}
		clearMeasurements() {
			this.scroll = void 0, this.layout = void 0, this.snapshot = void 0, this.prevTransformTemplateValue = void 0, this.targetDelta = void 0, this.target = void 0, this.isLayoutDirty = !1
		}
		forceRelativeParentToResolveTarget() {
			this.relativeParent && this.relativeParent.resolvedRelativeTargetAt !== xe.timestamp && this.relativeParent.resolveTargetDelta(!0)
		}
		resolveTargetDelta(e = !1) {
			var t;
			const n = this.getLead();
			this.isProjectionDirty || (this.isProjectionDirty = n.isProjectionDirty), this.isTransformDirty || (this.isTransformDirty = n.isTransformDirty), this.isSharedProjectionDirty || (this.isSharedProjectionDirty = n.isSharedProjectionDirty);
			const r = !!this.resumingFrom || this !== n;
			if (!(e || r && this.isSharedProjectionDirty || this.isProjectionDirty || null != (t = this.parent) && t.isProjectionDirty || this.attemptToResolveRelativeTarget || this.root.updateBlockedByResize)) return;
			const {
				layout: i,
				layoutId: a
			} = this.options;
			if (!this.layout || !i && !a) return;
			this.resolvedRelativeTargetAt = xe.timestamp;
			const o = this.getClosestProjectingParent();
			o && this.linkedParentVersion !== o.layoutVersion && !o.options.layoutRoot && this.removeRelativeTarget(), !this.targetDelta && !this.relativeTarget && (!1 !== this.options.layoutAnchor && o && o.layout ? this.createRelativeTarget(o, this.layout.layoutBox, o.layout.layoutBox) : this.removeRelativeTarget()), (this.relativeTarget || this.targetDelta) && (this.target || (this.target = se(), this.targetWithTransforms = se()), this.relativeTarget && this.relativeTargetOrigin && this.relativeParent && this.relativeParent.target ? (this.forceRelativeParentToResolveTarget(), GE(this.target, this.relativeTarget, this.relativeParent.target, this.options.layoutAnchor || void 0)) : this.targetDelta ? (this.resumingFrom ? this.applyTransform(this.layout.layoutBox, !1, this.target) : yn(this.target, this.layout.layoutBox), n1(this.target, this.targetDelta)) : yn(this.target, this.layout.layoutBox), this.attemptToResolveRelativeTarget && (this.attemptToResolveRelativeTarget = !1, !1 !== this.options.layoutAnchor && o && !!o.resumingFrom == !!this.resumingFrom && !o.options.layoutScroll && o.target && 1 !== this.animationProgress ? this.createRelativeTarget(o, this.target, o.target) : this.relativeParent = this.relativeTarget = void 0))
		}
		getClosestProjectingParent() {
			if (this.parent && !dd(this.parent.latestValues) && !e1(this.parent.latestValues)) return this.parent.isProjecting() ? this.parent : this.parent.getClosestProjectingParent()
		}
		isProjecting() {
			return !(!(this.relativeTarget || this.targetDelta || this.options.layoutRoot) || !this.layout)
		}
		createRelativeTarget(e, t, n) {
			this.relativeParent = e, this.linkedParentVersion = e.layoutVersion, this.forceRelativeParentToResolveTarget(), this.relativeTarget = se(), this.relativeTargetOrigin = se(), Ro(this.relativeTargetOrigin, t, n, this.options.layoutAnchor || void 0), yn(this.relativeTarget, this.relativeTargetOrigin)
		}
		removeRelativeTarget() {
			this.relativeParent = this.relativeTarget = void 0
		}
		calcProjection() {
			var e;
			const t = this.getLead(),
				n = !!this.resumingFrom || this !== t;
			let r = !0;
			if ((this.isProjectionDirty || null != (e = this.parent) && e.isProjectionDirty) && (r = !1), n && (this.isSharedProjectionDirty || this.isTransformDirty) && (r = !1), this.resolvedRelativeTargetAt === xe.timestamp && (r = !1), r) return;
			const {
				layout: i,
				layoutId: a
			} = this.options;
			if (this.isTreeAnimating = !!(this.parent && this.parent.isTreeAnimating || this.currentAnimation || this.pendingAnimation), this.isTreeAnimating || (this.targetDelta = this.relativeTarget = void 0), !this.layout || !i && !a) return;
			yn(this.layoutCorrected, this.layout.layoutBox);
			const o = this.treeScale.x,
				s = this.treeScale.y;
			yE(this.layoutCorrected, this.treeScale, this.path, n), t.layout && !t.target && (1 !== this.treeScale.x || 1 !== this.treeScale.y) && (t.target = t.layout.layoutBox, t.targetWithTransforms = se());
			const {
				target: l
			} = t;
			l ? (this.projectionDelta && this.prevProjectionDelta ? (ug(this.prevProjectionDelta.x, this.projectionDelta.x), ug(this.prevProjectionDelta.y, this.projectionDelta.y)) : this.createProjectionDeltas(), xs(this.projectionDelta, this.layoutCorrected, l, this.latestValues), (this.treeScale.x !== o || this.treeScale.y !== s || !vg(this.projectionDelta.x, this.prevProjectionDelta.x) || !vg(this.projectionDelta.y, this.prevProjectionDelta.y)) && (this.hasProjected = !0, this.scheduleRender(), this.notifyListeners("projectionUpdate", l))) : this.prevProjectionDelta && (this.createProjectionDeltas(), this.scheduleRender())
		}
		hide() {
			this.isVisible = !1
		}
		show() {
			this.isVisible = !0
		}
		scheduleRender(e = !0) {
			var t;
			if (null == (t = this.options.visualElement) || t.scheduleRender(), e) {
				const e = this.getStack();
				e && e.scheduleRender()
			}
			this.resumingFrom && !this.resumingFrom.instance && (this.resumingFrom = void 0)
		}
		createProjectionDeltas() {
			this.prevProjectionDelta = ul(), this.projectionDelta = ul(), this.projectionDeltaWithTransform = ul()
		}
		setAnimationOrigin(e, t = !1, n) {
			const r = this.snapshot,
				i = r ? r.latestValues : {},
				a = {
					...this.latestValues
				},
				o = ul();
			(!this.relativeParent || !this.relativeParent.options.layoutRoot) && (this.relativeTarget = this.relativeTargetOrigin = void 0), this.attemptToResolveRelativeTarget = !t;
			const s = se(),
				l = (r ? r.source : void 0) !== (this.layout ? this.layout.source : void 0),
				u = this.getStack(),
				c = !u || u.members.length <= 1,
				d = !(!l || c || !0 !== this.options.crossfade || this.path.some(gA));
			let f;
			this.animationProgress = 0;
			const h = null == n ? void 0 : n.interpolateProjection(e);
			this.mixTargetDelta = t => {
				const n = t / 1e3,
					r = null == h ? void 0 : h(n);
				r ? (o.x.translate = r.x, o.x.scale = Ht(e.x.scale, 1, n), o.x.origin = e.x.origin, o.x.originPoint = e.x.originPoint, o.y.translate = r.y, o.y.scale = Ht(e.y.scale, 1, n), o.y.origin = e.y.origin, o.y.originPoint = e.y.originPoint) : (Mg(o.x, e.x, n), Mg(o.y, e.y, n)), this.setTargetDelta(o), this.relativeTarget && this.relativeTargetOrigin && this.layout && this.relativeParent && this.relativeParent.layout && (Ro(s, this.layout.layoutBox, this.relativeParent.layout.layoutBox, this.options.layoutAnchor || void 0), yA(this.relativeTarget, this.relativeTargetOrigin, s, n), f && ZE(this.relativeTarget, f) && (this.isProjectionDirty = !1), f || (f = se()), yn(f, this.relativeTarget)), l && (this.animationValues = a, JE(a, i, this.latestValues, n, d, c)), r && void 0 !== r.rotate && (this.animationValues || (this.animationValues = a), this.animationValues.pathRotation = r.rotate), this.root.scheduleUpdateProjection(), this.scheduleRender(), this.animationProgress = n
			}, this.mixTargetDelta(this.options.layoutRoot ? 1e3 : 0)
		}
		startAnimation(e) {
			var t, n, r;
			this.notifyListeners("animationStart"), null == (t = this.currentAnimation) || t.stop(), null == (r = null == (n = this.resumingFrom) ? void 0 : n.currentAnimation) || r.stop(), this.pendingAnimation && (wi(this.pendingAnimation), this.pendingAnimation = void 0), this.pendingAnimation = Yt.update(() => {
				Ao.hasAnimatedSinceResize = !0, this.motionValue || (this.motionValue = rl(0)), this.motionValue.jump(0, !1), this.currentAnimation = IE(this.motionValue, [0, 1e3], {
					...e,
					velocity: 0,
					isSync: !0,
					onUpdate: t => {
						this.mixTargetDelta(t), e.onUpdate && e.onUpdate(t)
					},
					onComplete: () => {
						e.onComplete && e.onComplete(), this.completeAnimation()
					}
				}), this.resumingFrom && (this.resumingFrom.currentAnimation = this.currentAnimation), this.pendingAnimation = void 0
			})
		}
		completeAnimation() {
			this.resumingFrom && (this.resumingFrom.currentAnimation = void 0, this.resumingFrom.preserveOpacity = void 0);
			const e = this.getStack();
			e && e.exitAnimationComplete(), this.resumingFrom = this.currentAnimation = this.animationValues = void 0, this.notifyListeners("animationComplete")
		}
		finishAnimation() {
			this.currentAnimation && (this.mixTargetDelta && this.mixTargetDelta(nA), this.currentAnimation.stop()), this.completeAnimation()
		}
		applyTransformsToTarget() {
			const e = this.getLead();
			let {
				targetWithTransforms: t,
				target: n,
				layout: r,
				latestValues: i
			} = e;
			if (t && n && r) {
				if (this !== e && this.layout && r && b1(this.options.animationType, this.layout.layoutBox, r.layoutBox)) {
					n = this.target || se();
					const t = ze(this.layout.layoutBox.x);
					n.x.min = e.target.x.min, n.x.max = n.x.min + t;
					const r = ze(this.layout.layoutBox.y);
					n.y.min = e.target.y.min, n.y.max = n.y.min + r
				}
				yn(t, n), To(t, i), xs(this.projectionDeltaWithTransform, this.layoutCorrected, t, i)
			}
		}
		registerSharedNode(e, t) {
			this.sharedNodes.has(e) || this.sharedNodes.set(e, new eA), this.sharedNodes.get(e).add(t);
			const n = t.options.initialPromotionConfig;
			t.promote({
				transition: n ? n.transition : void 0,
				preserveFollowOpacity: n && n.shouldPreserveFollowOpacity ? n.shouldPreserveFollowOpacity(t) : void 0
			})
		}
		isLead() {
			const e = this.getStack();
			return !e || e.lead === this
		}
		getLead() {
			var e;
			const {
				layoutId: t
			} = this.options;
			return t && (null == (e = this.getStack()) ? void 0 : e.lead) || this
		}
		getPrevLead() {
			var e;
			const {
				layoutId: t
			} = this.options;
			return t ? null == (e = this.getStack()) ? void 0 : e.prevLead : void 0
		}
		getStack() {
			const {
				layoutId: e
			} = this.options;
			if (e) return this.root.sharedNodes.get(e)
		}
		promote({
			needsReset: e,
			transition: t,
			preserveFollowOpacity: n
		} = {}) {
			const r = this.getStack();
			r && r.promote(this, n), e && (this.projectionDelta = void 0, this.needsReset = !0), t && this.setOptions({
				transition: t
			})
		}
		relegate() {
			const e = this.getStack();
			return !!e && e.relegate(this)
		}
		resetSkewAndRotation() {
			const {
				visualElement: e
			} = this.options;
			if (!e) return;
			let t = !1;
			const {
				latestValues: n
			} = e;
			if ((n.z || n.rotate || n.rotateX || n.rotateY || n.rotateZ || n.skewX || n.skewY) && (t = !0), !t) return;
			const r = {};
			n.z && Hf("z", e, r, this.animationValues);
			for (let t = 0; t < Lf.length; t++) Hf(`rotate${Lf[t]}`, e, r, this.animationValues), Hf(`skew${Lf[t]}`, e, r, this.animationValues);
			e.render();
			for (const t in r) e.setStaticValue(t, r[t]), this.animationValues && (this.animationValues[t] = r[t]);
			e.scheduleRender()
		}
		applyProjectionStyles(e, t) {
			if (!this.instance || this.isSVG) return;
			if (!this.isVisible) return void (e.visibility = "hidden");
			const n = this.getTransformTemplate();
			if (this.needsReset) return this.needsReset = !1, e.visibility = "", e.opacity = "", e.pointerEvents = Eo(null == t ? void 0 : t.pointerEvents) || "", void (e.transform = n ? n(this.latestValues, "") : "none");
			const r = this.getLead();
			if (!this.projectionDelta || !this.layout || !r.target) return this.options.layoutId && (e.opacity = void 0 !== this.latestValues.opacity ? this.latestValues.opacity : 1, e.pointerEvents = Eo(null == t ? void 0 : t.pointerEvents) || ""), void (this.hasProjected && !sa(this.latestValues) && (e.transform = n ? n({}, "") : "none", this.hasProjected = !1));
			e.visibility = "";
			const i = r.animationValues || r.latestValues;
			this.applyTransformsToTarget();
			let a = KE(this.projectionDeltaWithTransform, this.treeScale, i);
			n && (a = n(i, a)), e.transform = a;
			const {
				x: o,
				y: s
			} = this.projectionDelta;
			e.transformOrigin = `${100 * o.origin}% ${100 * s.origin}% 0`, r.animationValues ? e.opacity = r === this ? i.opacity ?? this.latestValues.opacity ?? 1 : this.preserveOpacity ? this.latestValues.opacity : i.opacityExit : e.opacity = r === this ? void 0 !== i.opacity ? i.opacity : "" : void 0 !== i.opacityExit ? i.opacityExit : 0;
			for (const t in md) {
				if (void 0 === i[t]) continue;
				const {
					correct: n,
					applyTo: o,
					isCSSVariable: s
				} = md[t], l = "none" === a ? i[t] : n(i[t], r);
				if (o) {
					const t = o.length;
					for (let n = 0; n < t; n++) e[o[n]] = l
				} else s ? this.options.visualElement.renderState.vars[t] = l : e[t] = l
			}
			this.options.layoutId && (e.pointerEvents = r === this ? Eo(null == t ? void 0 : t.pointerEvents) || "" : "none")
		}
		clearSnapshot() {
			this.resumeFrom = this.snapshot = void 0
		}
		resetTree() {
			this.root.nodes.forEach(e => {
				var t;
				return null == (t = e.currentAnimation) ? void 0 : t.stop()
			}), this.root.nodes.forEach(Tg), this.root.sharedNodes.clear()
		}
	}
}

function aA(e) {
	e.updateLayout()
}

function lA(e) {
	var t;
	const n = (null == (t = e.resumeFrom) ? void 0 : t.snapshot) || e.snapshot;
	if (e.isLead() && e.layout && n && e.hasListeners("didUpdate")) {
		const {
			layoutBox: t,
			measuredBox: r
		} = e.layout, {
			animationType: i
		} = e.options, a = n.source !== e.layout.source;
		if ("size" === i) _n(e => {
			const r = a ? n.measuredBox[e] : n.layoutBox[e],
				i = ze(r);
			r.min = t[e].min, r.max = r.min + i
		});
		else if ("x" === i || "y" === i) {
			const e = "x" === i ? "y" : "x";
			pd(a ? n.measuredBox[e] : n.layoutBox[e], t[e])
		} else b1(i, n.layoutBox, t) && _n(r => {
			const i = a ? n.measuredBox[r] : n.layoutBox[r],
				o = ze(t[r]);
			i.max = i.min + o, e.relativeTarget && !e.currentAnimation && (e.isProjectionDirty = !0, e.relativeTarget[r].max = e.relativeTarget[r].min + o)
		});
		const o = ul();
		xs(o, t, n.layoutBox);
		const s = ul();
		a ? xs(s, e.applyTransform(r, !0), n.measuredBox) : xs(s, t, n.layoutBox);
		const l = !m1(o);
		let u = !1;
		if (!e.resumeFrom) {
			const r = e.getClosestProjectingParent();
			if (r && !r.resumeFrom) {
				const {
					snapshot: i,
					layout: a
				} = r;
				if (i && a) {
					const o = e.options.layoutAnchor || void 0,
						s = se();
					Ro(s, n.layoutBox, i.layoutBox, o);
					const l = se();
					Ro(l, t, a.layoutBox, o), p1(s, l) || (u = !0), r.options.layoutRoot && (e.relativeTarget = l, e.relativeTargetOrigin = s, e.relativeParent = r)
				}
			}
		}
		e.notifyListeners("didUpdate", {
			layout: t,
			snapshot: n,
			delta: s,
			layoutDelta: o,
			hasLayoutChanged: l,
			hasRelativeLayoutChanged: u
		})
	} else if (e.isLead()) {
		const {
			onExitComplete: t
		} = e.options;
		t && t()
	}
	e.options.transition = void 0
}

function sA(e) {
	e.parent && (e.isProjecting() || (e.isProjectionDirty = e.parent.isProjectionDirty), e.isSharedProjectionDirty || (e.isSharedProjectionDirty = !!(e.isProjectionDirty || e.parent.isProjectionDirty || e.parent.isSharedProjectionDirty)), e.isTransformDirty || (e.isTransformDirty = e.parent.isTransformDirty))
}

function uA(e) {
	e.isProjectionDirty = e.isSharedProjectionDirty = e.isTransformDirty = !1
}

function oA(e) {
	e.clearSnapshot()
}

function Tg(e) {
	e.clearMeasurements()
}

function rA(e) {
	e.isLayoutDirty = !0, e.updateLayout()
}

function Eg(e) {
	e.isLayoutDirty = !1
}

function cA(e) {
	e.isAnimationBlocked && e.layout && !e.isLayoutDirty && (e.snapshot = e.layout, e.isLayoutDirty = !0)
}

function fA(e) {
	const {
		visualElement: t
	} = e.options;
	t && t.getProps().onBeforeLayoutMeasure && t.notify("BeforeLayoutMeasure"), e.resetTransform()
}

function Ag(e) {
	e.finishAnimation(), e.targetDelta = e.relativeTarget = e.target = void 0, e.isProjectionDirty = !0
}

function dA(e) {
	e.resolveTargetDelta()
}

function hA(e) {
	e.calcProjection()
}

function mA(e) {
	e.resetSkewAndRotation()
}

function pA(e) {
	e.removeLeadSnapshot()
}

function Mg(e, t, n) {
	e.translate = Ht(t.translate, 0, n), e.scale = Ht(t.scale, 1, n), e.origin = t.origin, e.originPoint = t.originPoint
}

function Cg(e, t, n, r) {
	e.min = Ht(t.min, n.min, r), e.max = Ht(t.max, n.max, r)
}

function yA(e, t, n, r) {
	Cg(e.x, t.x, n.x, r), Cg(e.y, t.y, n.y, r)
}

function gA(e) {
	return e.animationValues && void 0 !== e.animationValues.opacityExit
}
const vA = {
	duration: .45,
	ease: [.4, 0, .1, 1]
},
	Dg = e => typeof navigator < "u" && navigator.userAgent && navigator.userAgent.toLowerCase().includes(e),
	Ng = Dg("applewebkit/") && !Dg("chrome/") ? Math.round : rn;

function Og(e) {
	e.min = Ng(e.min), e.max = Ng(e.max)
}

function bA(e) {
	Og(e.x), Og(e.y)
}

function b1(e, t, n) {
	return "position" === e || "preserve-aspect" === e && !YE(gg(t), gg(n), .2)
}

function xA(e) {
	var t;
	return e !== e.root && (null == (t = e.scroll) ? void 0 : t.wasRoot)
}
const SA = v1({
	attachResizeListener: (e, t) => Cs(e, "resize", t),
	measureScroll: () => {
		var e, t;
		return {
			x: document.documentElement.scrollLeft || (null == (e = document.body) ? void 0 : e.scrollLeft) || 0,
			y: document.documentElement.scrollTop || (null == (t = document.body) ? void 0 : t.scrollTop) || 0
		}
	},
	checkIsScrollRoot: () => !0
}),
	Yf = {
		current: void 0
	},
	x1 = v1({
		measureScroll: e => ({
			x: e.scrollLeft,
			y: e.scrollTop
		}),
		defaultParent: () => {
			if (!Yf.current) {
				const e = new SA({});
				e.mount(window), e.setOptions({
					layoutScroll: !0
				}), Yf.current = e
			}
			return Yf.current
		},
		resetTransform: (e, t) => {
			e.style.transform = void 0 !== t ? t : "none"
		},
		checkIsScrollRoot: e => "fixed" === window.getComputedStyle(e).position
	}),
	Pd = Z.createContext({
		transformPagePoint: e => e,
		isStatic: !1,
		reducedMotion: "never"
	});

function zg(e, t) {
	if ("function" == typeof e) return e(t);
	null != e && (e.current = t)
}

function TA(...e) {
	return t => {
		let n = !1;
		const r = e.map(e => {
			const r = zg(e, t);
			return !n && "function" == typeof r && (n = !0), r
		});
		if (n) return () => {
			for (let t = 0; t < r.length; t++) {
				const n = r[t];
				"function" == typeof n ? n() : zg(e[t], null)
			}
		}
	}
}

function EA(...e) {
	return Z.useCallback(TA(...e), e)
}
class AA extends Z.Component {
	getSnapshotBeforeUpdate(e) {
		const t = this.props.childRef.current;
		if (vo(t) && e.isPresent && !this.props.isPresent && !1 !== this.props.pop) {
			const e = t.offsetParent,
				n = vo(e) && e.offsetWidth || 0,
				r = vo(e) && e.offsetHeight || 0,
				i = getComputedStyle(t),
				a = this.props.sizeRef.current;
			a.height = parseFloat(i.height), a.width = parseFloat(i.width), a.top = t.offsetTop, a.left = t.offsetLeft, a.right = n - a.width - a.left, a.bottom = r - a.height - a.top, a.direction = i.direction
		}
		return null
	}
	componentDidUpdate() { }
	render() {
		return this.props.children
	}
}

function MA({
	children: e,
	isPresent: t,
	anchorX: n,
	anchorY: r,
	root: i,
	pop: a
}) {
	var o;
	const s = Z.useId(),
		l = Z.useRef(null),
		u = Z.useRef({
			width: 0,
			height: 0,
			top: 0,
			left: 0,
			right: 0,
			bottom: 0,
			direction: "ltr"
		}),
		{
			nonce: c
		} = Z.useContext(Pd),
		d = !1 !== a ? (null == (o = e.props) ? void 0 : o.ref) ?? (null == e ? void 0 : e.ref) : void 0,
		f = EA(l, d);
	return Z.useInsertionEffect(() => {
		const {
			width: e,
			height: o,
			top: d,
			left: f,
			right: h,
			bottom: p,
			direction: m
		} = u.current;
		if (t || !1 === a || !l.current || !e || !o) return;
		const g = "rtl" === m,
			v = "left" === n ? g ? `right: ${h}` : `left: ${f}` : g ? `left: ${f}` : `right: ${h}`,
			y = "bottom" === r ? `bottom: ${p}` : `top: ${d}`;
		l.current.dataset.motionPopId = s;
		const b = document.createElement("style");
		c && (b.nonce = c);
		const x = i ?? document.head;
		return x.appendChild(b), b.sheet && b.sheet.insertRule(`\n          [data-motion-pop-id="${s}"] {\n            position: absolute !important;\n            width: ${e}px !important;\n            height: ${o}px !important;\n            ${v}px !important;\n            ${y}px !important;\n          }\n        `), () => {
			var e;
			null == (e = l.current) || e.removeAttribute("data-motion-pop-id"), x.contains(b) && x.removeChild(b)
		}
	}, [t]), E.jsx(AA, {
		isPresent: t,
		childRef: l,
		sizeRef: u,
		pop: a,
		children: !1 === a ? e : Z.cloneElement(e, {
			ref: f
		})
	})
}
const CA = ({
	children: e,
	initial: t,
	isPresent: n,
	onExitComplete: r,
	custom: i,
	presenceAffectsLayout: a,
	mode: o,
	anchorX: s,
	anchorY: l,
	root: u
}) => {
	const c = Td(DA),
		d = Z.useId(),
		f = Z.useRef(n),
		h = Z.useRef(r);
	Ed(() => {
		f.current = n, h.current = r
	});
	let p = !0,
		m = Z.useMemo(() => (p = !1, {
			id: d,
			initial: t,
			isPresent: n,
			custom: i,
			onExitComplete: e => {
				c.set(e, !0);
				for (const e of c.values())
					if (!e) return;
				r && r()
			},
			register: e => (c.set(e, !1), () => {
				var t;
				c.delete(e), !f.current && !c.size && (null == (t = h.current) || t.call(h))
			})
		}), [n, c, r]);
	return a && p && (m = {
		...m
	}), Z.useMemo(() => {
		c.forEach((e, t) => c.set(t, !1))
	}, [n]), Z.useEffect(() => {
		!n && !c.size && r && r()
	}, [n]), e = E.jsx(MA, {
		pop: "popLayout" === o,
		isPresent: n,
		anchorX: s,
		anchorY: l,
		root: u,
		children: e
	}), E.jsx(Bo.Provider, {
		value: m,
		children: e
	})
};

function DA() {
	return new Map
}

function S1(e = !0) {
	const t = Z.useContext(Bo);
	if (null === t) return [!0, null];
	const {
		isPresent: n,
		onExitComplete: r,
		register: i
	} = t, a = Z.useId();
	Z.useEffect(() => {
		if (e) return i(a)
	}, [e]);
	const o = Z.useCallback(() => e && r && r(a), [a, r, e]);
	return !n && r ? [!1, o] : [!0]
}
const mo = e => e.key || "";

function wg(e) {
	const t = [];
	return Z.Children.forEach(e, e => {
		Z.isValidElement(e) && t.push(e)
	}), t
}
const Go = ({
	children: e,
	custom: t,
	initial: n = !0,
	onExitComplete: r,
	presenceAffectsLayout: i = !0,
	mode: a = "sync",
	propagate: o = !1,
	anchorX: s = "left",
	anchorY: l = "top",
	root: u
}) => {
	const [c, d] = S1(o), f = Z.useMemo(() => wg(e), [e]), h = o && !c ? [] : f.map(mo), p = Z.useRef(!0), m = Z.useRef(f), g = Td(() => new Map), v = Z.useRef(new Set), [y, b] = Z.useState(f), [x, w] = Z.useState(f);
	Ed(() => {
		p.current = !1, m.current = f;
		for (let e = 0; e < x.length; e++) {
			const t = mo(x[e]);
			h.includes(t) ? (g.delete(t), v.current.delete(t)) : !0 !== g.get(t) && g.set(t, !1)
		}
	}, [x, h.length, h.join("-")]);
	const S = [];
	if (f !== y) {
		let e = [...f];
		for (let t = 0; t < x.length; t++) {
			const n = x[t],
				r = mo(n);
			h.includes(r) || (e.splice(t, 0, n), S.push(n))
		}
		return "wait" === a && S.length && (e = S), w(wg(e)), b(f), null
	}
	const {
		forceRender: k
	} = Z.useContext(Sd);
	return E.jsx(E.Fragment, {
		children: x.map(e => {
			const y = mo(e),
				b = !(o && !c) && (f === x || h.includes(y));
			return E.jsx(CA, {
				isPresent: b,
				initial: !(p.current && !n) && void 0,
				custom: t,
				presenceAffectsLayout: i,
				mode: a,
				root: u,
				onExitComplete: b ? void 0 : () => {
					if (v.current.has(y)) return;
					if (!g.has(y)) return;
					v.current.add(y), g.set(y, !0);
					let e = !0;
					g.forEach(t => {
						t || (e = !1)
					}), e && (null == k || k(), w(m.current), o && (null == d || d()), r && r())
				},
				anchorX: s,
				anchorY: l,
				children: e
			}, y)
		})
	})
},
	T1 = Z.createContext({
		strict: !1
	}),
	_g = {
		animation: ["animate", "variants", "whileHover", "whileTap", "exit", "whileInView", "whileFocus", "whileDrag"],
		exit: ["exit"],
		drag: ["drag", "dragControls"],
		focus: ["whileFocus"],
		hover: ["whileHover", "onHoverStart", "onHoverEnd"],
		tap: ["whileTap", "onTap", "onTapStart", "onTapCancel"],
		pan: ["onPan", "onPanStart", "onPanSessionStart", "onPanEnd"],
		inView: ["whileInView", "onViewportEnter", "onViewportLeave"],
		layout: ["layout", "layoutId"]
	};
let Rg = !1;

function NA() {
	if (Rg) return;
	const e = {};
	for (const t in _g) e[t] = {
		isEnabled: e => _g[t].some(t => !!e[t])
	};
	$v(e), Rg = !0
}

function E1() {
	return NA(), dE()
}

function OA(e) {
	const t = E1();
	for (const n in e) t[n] = {
		...t[n],
		...e[n]
	};
	$v(t)
}
const zA = new Set(["animate", "exit", "variants", "initial", "style", "values", "variants", "transition", "transformTemplate", "custom", "inherit", "onBeforeLayoutMeasure", "onAnimationStart", "onAnimationComplete", "onUpdate", "onDragStart", "onDrag", "onDragEnd", "onMeasureDragConstraints", "onDirectionLock", "onDragTransitionEnd", "_dragX", "_dragY", "onHoverStart", "onHoverEnd", "onViewportEnter", "onViewportLeave", "globalTapTarget", "propagate", "ignoreStrict", "viewport"]);

function jo(e) {
	return e.startsWith("while") || e.startsWith("drag") && "draggable" !== e || e.startsWith("layout") || e.startsWith("onTap") || e.startsWith("onPan") || e.startsWith("onLayout") || zA.has(e)
}
let A1 = e => !jo(e);

function wA(e) {
	"function" == typeof e && (A1 = t => t.startsWith("on") ? !jo(t) : e(t))
}
try {
	wA(require("@emotion/is-prop-valid").default)
} catch { }

function _A(e, t, n) {
	const r = {};
	for (const i in e) "values" === i && "object" == typeof e.values || Te(e[i]) || (A1(i) || !0 === n && jo(i) || !t && !jo(i) || e.draggable && i.startsWith("onDrag")) && (r[i] = e[i]);
	return r
}
const qo = Z.createContext({});

function RA(e, t) {
	if (Yo(e)) {
		const {
			initial: t,
			animate: n
		} = e;
		return {
			initial: !1 === t || Ms(t) ? t : void 0,
			animate: Ms(n) ? n : void 0
		}
	}
	return !1 !== e.inherit ? t : {}
}

function jA(e) {
	const {
		initial: t,
		animate: n
	} = RA(e, Z.useContext(qo));
	return Z.useMemo(() => ({
		initial: t,
		animate: n
	}), [jg(t), jg(n)])
}

function jg(e) {
	return Array.isArray(e) ? e.join(" ") : e
}
const Jd = () => ({
	style: {},
	transform: {},
	transformOrigin: {},
	vars: {}
});

function M1(e, t, n) {
	for (const r in t) !Te(t[r]) && !l1(r, n) && (e[r] = t[r])
}

function VA({
	transformTemplate: e
}, t) {
	return Z.useMemo(() => {
		const n = Jd();
		return Zd(n, t, e), Object.assign({}, n.vars, n.style)
	}, [t])
}

function BA(e, t) {
	const n = {};
	return M1(n, e.style || {}, e), Object.assign(n, VA(e, t)), n
}

function UA(e, t) {
	const n = {},
		r = BA(e, t);
	return e.drag && !1 !== e.dragListener && (n.draggable = !1, r.userSelect = r.WebkitUserSelect = r.WebkitTouchCallout = "none", r.touchAction = !0 === e.drag ? "none" : "pan-" + ("x" === e.drag ? "y" : "x")), void 0 === e.tabIndex && (e.onTap || e.onTapStart || e.whileTap) && (n.tabIndex = 0), n.style = r, n
}
const C1 = () => ({
	...Jd(),
	attrs: {}
});

function LA(e, t, n, r) {
	const i = Z.useMemo(() => {
		const n = C1();
		return s1(n, t, o1(r), e.transformTemplate, e.style), {
			...n.attrs,
			style: {
				...n.style
			}
		}
	}, [t]);
	if (e.style) {
		const t = {};
		M1(t, e.style, e), i.style = {
			...t,
			...i.style
		}
	}
	return i
}
const HA = ["animate", "circle", "defs", "desc", "ellipse", "g", "image", "line", "filter", "marker", "mask", "metadata", "path", "pattern", "polygon", "polyline", "rect", "stop", "switch", "symbol", "svg", "text", "tspan", "use", "view"];

function kd(e) {
	return "string" == typeof e && !e.includes("-") && !!(HA.indexOf(e) > -1 || /[A-Z]/u.test(e))
}

function YA(e, t, n, {
	latestValues: r
}, i, a = !1, o) {
	const s = (o ?? kd(e) ? LA : UA)(t, r, i, e),
		l = _A(t, "string" == typeof e, a),
		u = e !== Z.Fragment ? {
			...l,
			...s,
			ref: n
		} : {},
		{
			children: c
		} = t,
		d = Z.useMemo(() => Te(c) ? c.get() : c, [c]);
	return Z.createElement(e, {
		...u,
		children: d
	})
}

function GA({
	scrapeMotionValuesFromProps: e,
	createRenderState: t
}, n, r, i) {
	return {
		latestValues: qA(n, r, i, e),
		renderState: t()
	}
}

function qA(e, t, n, r) {
	const i = {},
		a = r(e, {});
	for (const e in a) i[e] = Eo(a[e]);
	let {
		initial: o,
		animate: s
	} = e;
	const l = Yo(e),
		u = Fv(e);
	t && u && !l && !1 !== e.inherit && (void 0 === o && (o = t.initial), void 0 === s && (s = t.animate));
	let c = !!n && !1 === n.initial;
	c = c || !1 === o;
	const d = c ? s : o;
	if (d && "boolean" != typeof d && !Ho(d)) {
		const t = Array.isArray(d) ? d : [d];
		for (let n = 0; n < t.length; n++) {
			const r = Ud(e, t[n]);
			if (r) {
				const {
					transitionEnd: e,
					transition: t,
					...n
				} = r;
				for (const e in n) {
					let t = n[e];
					if (Array.isArray(t)) {
						t = t[c ? t.length - 1 : 0]
					}
					null !== t && (i[e] = t)
				}
				for (const t in e) i[t] = e[t]
			}
		}
	}
	return i
}
const D1 = e => (t, n) => {
	const r = Z.useContext(qo),
		i = Z.useContext(Bo),
		a = () => GA(e, t, r, i);
	return n ? a() : Td(a)
},
	XA = D1({
		scrapeMotionValuesFromProps: Kd,
		createRenderState: Jd
	}),
	QA = D1({
		scrapeMotionValuesFromProps: r1,
		createRenderState: C1
	}),
	ZA = Symbol.for("motionComponentSymbol");

function KA(e, t, n) {
	const r = Z.useRef(n);
	Z.useInsertionEffect(() => {
		r.current = n
	});
	const i = Z.useRef(null);
	return Z.useCallback(n => {
		var a;
		n && (null == (a = e.onMount) || a.call(e, n)), t && (n ? t.mount(n) : t.unmount());
		const o = r.current;
		if ("function" == typeof o)
			if (n) {
				const e = o(n);
				"function" == typeof e && (i.current = e)
			} else i.current ? (i.current(), i.current = null) : o(n);
		else o && (o.current = n)
	}, [t])
}
const N1 = Z.createContext({});

function al(e) {
	return e && "object" == typeof e && Object.prototype.hasOwnProperty.call(e, "current")
}

function PA(e, t, n, r, i, a) {
	var o, s;
	const {
		visualElement: l
	} = Z.useContext(qo), u = Z.useContext(T1), c = Z.useContext(Bo), d = Z.useContext(Pd), f = d.reducedMotion, h = d.skipAnimations, p = Z.useRef(null), m = Z.useRef(!1);
	r = r || u.renderer, !p.current && r && (p.current = r(e, {
		visualState: t,
		parent: l,
		props: n,
		presenceContext: c,
		blockInitialAnimation: !!c && !1 === c.initial,
		reducedMotionConfig: f,
		skipAnimations: h,
		isSVG: a
	}), m.current && p.current && (p.current.manuallyAnimateOnMount = !0));
	const g = p.current,
		v = Z.useContext(N1);
	g && !g.projection && i && ("html" === g.type || "svg" === g.type) && JA(p.current, n, i, v);
	const y = Z.useRef(!1);
	Z.useInsertionEffect(() => {
		g && y.current && g.update(n, c)
	});
	const b = n[Lv],
		x = Z.useRef(!!b && typeof window < "u" && !(null != (o = window.MotionHandoffIsComplete) && o.call(window, b)) && (null == (s = window.MotionHasOptimisedAnimation) ? void 0 : s.call(window, b)));
	return Ed(() => {
		m.current = !0, g && (y.current = !0, window.MotionIsMounted = !0, g.updateFeatures(), g.scheduleRenderMicrotask(), x.current && g.animationState && g.animationState.animateChanges())
	}), Z.useEffect(() => {
		g && (!x.current && g.animationState && g.animationState.animateChanges(), x.current && (queueMicrotask(() => {
			var e;
			null == (e = window.MotionHandoffMarkAsComplete) || e.call(window, b)
		}), x.current = !1), g.enteringChildren = void 0)
	}), g
}

function JA(e, t, n, r) {
	const {
		layoutId: i,
		layout: a,
		drag: o,
		dragConstraints: s,
		layoutScroll: l,
		layoutRoot: u,
		layoutAnchor: c,
		layoutCrossfade: d
	} = t;
	e.projection = new n(e.latestValues, t["data-framer-portal-id"] ? void 0 : O1(e.parent)), e.projection.setOptions({
		layoutId: i,
		layout: a,
		alwaysMeasureLayout: !!o || s && al(s),
		visualElement: e,
		animationType: "string" == typeof a ? a : "both",
		initialPromotionConfig: r,
		crossfade: d,
		layoutScroll: l,
		layoutRoot: u,
		layoutAnchor: c
	})
}

function O1(e) {
	if (e) return !1 !== e.options.allowProjection ? e.projection : O1(e.parent)
}

function Gf(e, {
	forwardMotionProps: t = !1,
	type: n
} = {}, r, i) {
	r && OA(r);
	const a = n ? "svg" === n : kd(e),
		o = a ? QA : XA;

	function s(n, r) {
		let s;
		const l = {
			...Z.useContext(Pd),
			...n,
			layoutId: kA(n)
		},
			{
				isStatic: u
			} = l,
			c = jA(n),
			d = o(n, u);
		if (!u && typeof window < "u") {
			FA();
			const t = IA(l);
			s = t.MeasureLayout, c.visualElement = PA(e, d, l, i, t.ProjectionNode, a)
		}
		return E.jsxs(qo.Provider, {
			value: c,
			children: [s && c.visualElement ? E.jsx(s, {
				visualElement: c.visualElement,
				...l
			}) : null, YA(e, n, KA(d, c.visualElement, r), d, u, t, a)]
		})
	}
	s.displayName = `motion.${"string" == typeof e ? e : `create(${e.displayName ?? e.name ?? ""})`}`;
	const l = Z.forwardRef(s);
	return l[ZA] = e, l
}

function kA({
	layoutId: e
}) {
	const t = Z.useContext(Sd).id;
	return t && void 0 !== e ? t + "-" + e : e
}

function FA(e, t) {
	Z.useContext(T1).strict
}

function IA(e) {
	const t = E1(),
		{
			drag: n,
			layout: r
		} = t;
	if (!n && !r) return {};
	const i = {
		...n,
		...r
	};
	return {
		MeasureLayout: null != n && n.isEnabled(e) || null != r && r.isEnabled(e) ? i.MeasureLayout : void 0,
		ProjectionNode: i.ProjectionNode
	}
}

function $A(e, t) {
	if (typeof Proxy > "u") return Gf;
	const n = new Map,
		r = (n, r) => Gf(n, r, e, t);
	return new Proxy((e, t) => r(e, t), {
		get: (i, a) => "create" === a ? r : (n.has(a) || n.set(a, Gf(a, void 0, e, t)), n.get(a))
	})
}
const WA = (e, t) => t.isSVG ?? kd(e) ? new OE(t) : new EE(t, {
	allowProjection: e !== Z.Fragment
});
class t3 extends _i {
	constructor(e) {
		super(e), e.animationState || (e.animationState = jE(e))
	}
	updateAnimationControlsSubscription() {
		const {
			animate: e
		} = this.node.getProps();
		Ho(e) && (this.unmountControls = e.subscribe(this.node))
	}
	mount() {
		this.updateAnimationControlsSubscription()
	}
	update() {
		const {
			animate: e
		} = this.node.getProps(), {
			animate: t
		} = this.node.prevProps || {};
		e !== t && this.updateAnimationControlsSubscription()
	}
	unmount() {
		var e;
		this.node.animationState.reset(), null == (e = this.unmountControls) || e.call(this)
	}
}
let e3 = 0;
class n3 extends _i {
	constructor() {
		super(...arguments), this.id = e3++, this.isExitComplete = !1
	}
	update() {
		var e;
		if (!this.node.presenceContext) return;
		const {
			isPresent: t,
			onExitComplete: n
		} = this.node.presenceContext, {
			isPresent: r
		} = this.node.prevPresenceContext || {};
		if (!this.node.animationState || t === r) return;
		if (t && !1 === r) {
			if (this.isExitComplete) {
				const {
					initial: t,
					custom: n
				} = this.node.getProps();
				if ("string" == typeof t || "object" == typeof t && null !== t && !Array.isArray(t)) {
					const r = ca(this.node, t, n);
					if (r) {
						const {
							transition: t,
							transitionEnd: n,
							...i
						} = r;
						for (const t in i) null == (e = this.node.getValue(t)) || e.jump(i[t])
					}
				}
				this.node.animationState.reset(), this.node.animationState.animateChanges()
			} else this.node.animationState.setActive("exit", !1);
			return void (this.isExitComplete = !1)
		}
		const i = this.node.animationState.setActive("exit", !t);
		n && !t && i.then(() => {
			this.isExitComplete = !0, n(this.id)
		})
	}
	mount() {
		const {
			register: e,
			onExitComplete: t
		} = this.node.presenceContext || {};
		t && t(this.id), e && (this.unmount = e(this.id))
	}
	unmount() { }
}
const i3 = {
	animation: {
		Feature: t3
	},
	exit: {
		Feature: n3
	}
};

function js(e) {
	return {
		point: {
			x: e.pageX,
			y: e.pageY
		}
	}
}
const a3 = e => t => Gd(t) && e(t, js(t));

function Ss(e, t, n, r) {
	return Cs(e, t, a3(n), r)
}
const z1 = ({
	current: e
}) => e ? e.ownerDocument.defaultView : null,
	Vg = (e, t) => Math.abs(e - t);

function l3(e, t) {
	const n = Vg(e.x, t.x),
		r = Vg(e.y, t.y);
	return Math.sqrt(n ** 2 + r ** 2)
}
const Bg = new Set(["auto", "scroll"]);
class w1 {
	constructor(e, t, {
		transformPagePoint: n,
		contextWindow: r = window,
		dragSnapToOrigin: i = !1,
		distanceThreshold: a = 3,
		element: o
	} = {}) {
		if (this.startEvent = null, this.lastMoveEvent = null, this.lastMoveEventInfo = null, this.lastRawMoveEventInfo = null, this.handlers = {}, this.contextWindow = window, this.scrollPositions = new Map, this.removeScrollListeners = null, this.onElementScroll = e => {
			this.handleScroll(e.target)
		}, this.onWindowScroll = () => {
			this.handleScroll(window)
		}, this.updatePoint = () => {
			if (!this.lastMoveEvent || !this.lastMoveEventInfo) return;
			this.lastRawMoveEventInfo && (this.lastMoveEventInfo = po(this.lastRawMoveEventInfo, this.transformPagePoint));
			const e = qf(this.lastMoveEventInfo, this.history),
				t = null !== this.startEvent,
				n = l3(e.offset, {
					x: 0,
					y: 0
				}) >= this.distanceThreshold;
			if (!t && !n) return;
			const {
				point: r
			} = e, {
				timestamp: i
			} = xe;
			this.history.push({
				...r,
				timestamp: i
			});
			const {
				onStart: a,
				onMove: o
			} = this.handlers;
			t || (a && a(this.lastMoveEvent, e), this.startEvent = this.lastMoveEvent), o && o(this.lastMoveEvent, e)
		}, this.handlePointerMove = (e, t) => {
			this.lastMoveEvent = e, this.lastRawMoveEventInfo = t, this.lastMoveEventInfo = po(t, this.transformPagePoint), Yt.update(this.updatePoint, !0)
		}, this.handlePointerUp = (e, t) => {
			this.end();
			const {
				onEnd: n,
				onSessionEnd: r,
				resumeAnimation: i
			} = this.handlers;
			if ((this.dragSnapToOrigin || !this.startEvent) && i && i(), !this.lastMoveEvent || !this.lastMoveEventInfo) return;
			const a = qf("pointercancel" === e.type ? this.lastMoveEventInfo : po(t, this.transformPagePoint), this.history);
			this.startEvent && n && n(e, a), r && r(e, a)
		}, !Gd(e)) return;
		this.dragSnapToOrigin = i, this.handlers = t, this.transformPagePoint = n, this.distanceThreshold = a, this.contextWindow = r || window;
		const s = po(js(e), this.transformPagePoint),
			{
				point: l
			} = s,
			{
				timestamp: u
			} = xe;
		this.history = [{
			...l,
			timestamp: u
		}];
		const {
			onSessionStart: c
		} = t;
		c && c(e, qf(s, this.history));
		const d = {
			passive: !0,
			capture: !0
		};
		this.removeListeners = ws(Ss(this.contextWindow, "pointermove", this.handlePointerMove, d), Ss(this.contextWindow, "pointerup", this.handlePointerUp, d), Ss(this.contextWindow, "pointercancel", this.handlePointerUp, d)), o && this.startScrollTracking(o)
	}
	startScrollTracking(e) {
		let t = e.parentElement;
		for (; t;) {
			const e = getComputedStyle(t);
			(Bg.has(e.overflowX) || Bg.has(e.overflowY)) && this.scrollPositions.set(t, {
				x: t.scrollLeft,
				y: t.scrollTop
			}), t = t.parentElement
		}
		this.scrollPositions.set(window, {
			x: window.scrollX,
			y: window.scrollY
		}), window.addEventListener("scroll", this.onElementScroll, {
			capture: !0
		}), window.addEventListener("scroll", this.onWindowScroll), this.removeScrollListeners = () => {
			window.removeEventListener("scroll", this.onElementScroll, {
				capture: !0
			}), window.removeEventListener("scroll", this.onWindowScroll)
		}
	}
	handleScroll(e) {
		const t = this.scrollPositions.get(e);
		if (!t) return;
		const n = e === window,
			r = n ? {
				x: window.scrollX,
				y: window.scrollY
			} : {
				x: e.scrollLeft,
				y: e.scrollTop
			},
			i = r.x - t.x,
			a = r.y - t.y;
		0 === i && 0 === a || (n ? this.lastMoveEventInfo && (this.lastMoveEventInfo.point.x += i, this.lastMoveEventInfo.point.y += a) : this.history.length > 0 && (this.history[0].x -= i, this.history[0].y -= a), this.scrollPositions.set(e, r), Yt.update(this.updatePoint, !0))
	}
	updateHandlers(e) {
		this.handlers = e
	}
	end() {
		this.removeListeners && this.removeListeners(), this.removeScrollListeners && this.removeScrollListeners(), this.scrollPositions.clear(), wi(this.updatePoint)
	}
}

function po(e, t) {
	return t ? {
		point: t(e.point)
	} : e
}

function Ug(e, t) {
	return {
		x: e.x - t.x,
		y: e.y - t.y
	}
}

function qf({
	point: e
}, t) {
	return {
		point: e,
		delta: Ug(e, _1(t)),
		offset: Ug(e, s3(t)),
		velocity: u3(t, .1)
	}
}

function s3(e) {
	return e[0]
}

function _1(e) {
	return e[e.length - 1]
}

function u3(e, t) {
	if (e.length < 2) return {
		x: 0,
		y: 0
	};
	let n = e.length - 1,
		r = null;
	const i = _1(e);
	for (; n >= 0 && (r = e[n], !(i.timestamp - r.timestamp > Fe(t)));) n--;
	if (!r) return {
		x: 0,
		y: 0
	};
	r === e[0] && e.length > 2 && i.timestamp - r.timestamp > 2 * Fe(t) && (r = e[1]);
	const a = on(i.timestamp - r.timestamp);
	if (0 === a) return {
		x: 0,
		y: 0
	};
	const o = {
		x: (i.x - r.x) / a,
		y: (i.y - r.y) / a
	};
	return o.x === 1 / 0 && (o.x = 0), o.y === 1 / 0 && (o.y = 0), o
}

function o3(e, {
	min: t,
	max: n
}, r) {
	return void 0 !== t && e < t ? e = r ? Ht(t, e, r.min) : Math.max(e, t) : void 0 !== n && e > n && (e = r ? Ht(n, e, r.max) : Math.min(e, n)), e
}

function Lg(e, t, n) {
	return {
		min: void 0 !== t ? e.min + t : void 0,
		max: void 0 !== n ? e.max + n - (e.max - e.min) : void 0
	}
}

function r3(e, {
	top: t,
	left: n,
	bottom: r,
	right: i
}) {
	return {
		x: Lg(e.x, n, i),
		y: Lg(e.y, t, r)
	}
}

function Hg(e, t) {
	let n = t.min - e.min,
		r = t.max - e.max;
	return t.max - t.min < e.max - e.min && ([n, r] = [r, n]), {
		min: n,
		max: r
	}
}

function c3(e, t) {
	return {
		x: Hg(e.x, t.x),
		y: Hg(e.y, t.y)
	}
}

function f3(e, t) {
	let n = .5;
	const r = ze(e),
		i = ze(t);
	return i > r ? n = Es(t.min, t.max - r, e.min) : r > i && (n = Es(e.min, e.max - i, t.min)), Vn(0, 1, n)
}

function d3(e, t) {
	const n = {};
	return void 0 !== t.min && (n.min = t.min - e.min), void 0 !== t.max && (n.max = t.max - e.min), n
}
const yd = .35;

function h3(e = yd) {
	return !1 === e ? e = 0 : !0 === e && (e = yd), {
		x: Yg(e, "left", "right"),
		y: Yg(e, "top", "bottom")
	}
}

function Yg(e, t, n) {
	return {
		min: Gg(e, t),
		max: Gg(e, n)
	}
}

function Gg(e, t) {
	return "number" == typeof e ? e : e[t] || 0
}
const m3 = new WeakMap;
class p3 {
	constructor(e) {
		this.openDragLock = null, this.isDragging = !1, this.currentDirection = null, this.originPoint = {
			x: 0,
			y: 0
		}, this.constraints = !1, this.hasMutatedConstraints = !1, this.elastic = se(), this.latestPointerEvent = null, this.latestPanInfo = null, this.visualElement = e
	}
	start(e, {
		snapToCursor: t = !1,
		distanceThreshold: n
	} = {}) {
		const {
			presenceContext: r
		} = this.visualElement;
		if (r && !1 === r.isPresent) return;
		const {
			dragSnapToOrigin: i
		} = this.getProps();
		this.panSession = new w1(e, {
			onSessionStart: e => {
				t && this.snapToCursor(js(e).point), this.stopAnimation()
			},
			onStart: (e, t) => {
				const {
					drag: n,
					dragPropagation: r,
					onDragStart: i
				} = this.getProps();
				if (n && !r && (this.openDragLock && this.openDragLock(), this.openDragLock = qT(n), !this.openDragLock)) return;
				this.latestPointerEvent = e, this.latestPanInfo = t, this.isDragging = !0, this.currentDirection = null, this.resolveConstraints(), this.visualElement.projection && (this.visualElement.projection.isAnimationBlocked = !0, this.visualElement.projection.target = void 0), _n(e => {
					let t = this.getAxisMotionValue(e).get() || 0;
					if (jn.test(t)) {
						const {
							projection: n
						} = this.visualElement;
						if (n && n.layout) {
							const r = n.layout.layoutBox[e];
							r && (t = ze(r) * (parseFloat(t) / 100))
						}
					}
					this.originPoint[e] = t
				}), i && Yt.update(() => i(e, t), !1, !0), sd(this.visualElement, "transform");
				const {
					animationState: a
				} = this.visualElement;
				a && a.setActive("whileDrag", !0)
			},
			onMove: (e, t) => {
				this.latestPointerEvent = e, this.latestPanInfo = t;
				const {
					dragPropagation: n,
					dragDirectionLock: r,
					onDirectionLock: i,
					onDrag: a
				} = this.getProps();
				if (!n && !this.openDragLock) return;
				const {
					offset: o
				} = t;
				if (r && null === this.currentDirection) return this.currentDirection = g3(o), void (null !== this.currentDirection && i && i(this.currentDirection));
				this.updateAxis("x", t.point, o), this.updateAxis("y", t.point, o), this.visualElement.render(), a && Yt.update(() => a(e, t), !1, !0)
			},
			onSessionEnd: (e, t) => {
				this.latestPointerEvent = e, this.latestPanInfo = t, this.stop(e, t), this.latestPointerEvent = null, this.latestPanInfo = null
			},
			resumeAnimation: () => {
				const {
					dragSnapToOrigin: e
				} = this.getProps();
				(e || this.constraints) && this.startAnimation({
					x: 0,
					y: 0
				})
			}
		}, {
			transformPagePoint: this.visualElement.getTransformPagePoint(),
			dragSnapToOrigin: i,
			distanceThreshold: n,
			contextWindow: z1(this.visualElement),
			element: this.visualElement.current
		})
	}
	stop(e, t) {
		const n = e || this.latestPointerEvent,
			r = t || this.latestPanInfo,
			i = this.isDragging;
		if (this.cancel(), !i || !r || !n) return;
		const {
			velocity: a
		} = r;
		this.startAnimation(a);
		const {
			onDragEnd: o
		} = this.getProps();
		o && Yt.postRender(() => o(n, r))
	}
	cancel() {
		this.isDragging = !1;
		const {
			projection: e,
			animationState: t
		} = this.visualElement;
		e && (e.isAnimationBlocked = !1), this.endPanSession();
		const {
			dragPropagation: n
		} = this.getProps();
		!n && this.openDragLock && (this.openDragLock(), this.openDragLock = null), t && t.setActive("whileDrag", !1)
	}
	endPanSession() {
		this.panSession && this.panSession.end(), this.panSession = void 0
	}
	updateAxis(e, t, n) {
		const {
			drag: r
		} = this.getProps();
		if (!n || !yo(e, r, this.currentDirection)) return;
		const i = this.getAxisMotionValue(e);
		let a = this.originPoint[e] + n[e];
		this.constraints && this.constraints[e] && (a = o3(a, this.constraints[e], this.elastic[e])), i.set(a)
	}
	resolveConstraints() {
		var e;
		const {
			dragConstraints: t,
			dragElastic: n
		} = this.getProps(), r = this.visualElement.projection && !this.visualElement.projection.layout ? this.visualElement.projection.measure(!1) : null == (e = this.visualElement.projection) ? void 0 : e.layout, i = this.constraints;
		t && al(t) ? this.constraints || (this.constraints = this.resolveRefConstraints()) : this.constraints = !(!t || !r) && r3(r.layoutBox, t), this.elastic = h3(n), i !== this.constraints && !al(t) && r && this.constraints && !this.hasMutatedConstraints && _n(e => {
			!1 !== this.constraints && this.getAxisMotionValue(e) && (this.constraints[e] = d3(r.layoutBox[e], this.constraints[e]))
		})
	}
	resolveRefConstraints() {
		const {
			dragConstraints: e,
			onMeasureDragConstraints: t
		} = this.getProps();
		if (!e || !al(e)) return !1;
		const n = e.current,
			{
				projection: r
			} = this.visualElement;
		if (!r || !r.layout) return !1;
		r.root && (r.root.scroll = void 0, r.root.updateScroll());
		const i = gE(n, r.root, this.visualElement.getTransformPagePoint());
		let a = c3(r.layout.layoutBox, i);
		if (t) {
			const e = t(mE(a));
			this.hasMutatedConstraints = !!e, e && (a = t1(e))
		}
		return a
	}
	startAnimation(e) {
		const {
			drag: t,
			dragMomentum: n,
			dragElastic: r,
			dragTransition: i,
			dragSnapToOrigin: a,
			onDragTransitionEnd: o
		} = this.getProps(), s = this.constraints || {}, l = _n(o => {
			if (!yo(o, t, this.currentDirection)) return;
			let l = s && s[o] || {};
			(!0 === a || a === o) && (l = {
				min: 0,
				max: 0
			});
			const u = r ? 200 : 1e6,
				c = r ? 40 : 1e7,
				d = {
					type: "inertia",
					velocity: n ? e[o] : 0,
					bounceStiffness: u,
					bounceDamping: c,
					timeConstant: 750,
					restDelta: 1,
					restSpeed: 10,
					...i,
					...l
				};
			return this.startAxisValueAnimation(o, d)
		});
		return Promise.all(l).then(o)
	}
	startAxisValueAnimation(e, t) {
		const n = this.getAxisMotionValue(e);
		return sd(this.visualElement, e), n.start(Bd(e, n, 0, t, this.visualElement, !1))
	}
	stopAnimation() {
		_n(e => this.getAxisMotionValue(e).stop())
	}
	getAxisMotionValue(e) {
		const t = `_drag${e.toUpperCase()}`;
		return this.visualElement.getProps()[t] || this.visualElement.getValue(e, this.visualElement.latestValues[e] ?? 0)
	}
	snapToCursor(e) {
		_n(t => {
			const {
				drag: n
			} = this.getProps();
			if (!yo(t, n, this.currentDirection)) return;
			const {
				projection: r
			} = this.visualElement, i = this.getAxisMotionValue(t);
			if (r && r.layout) {
				const {
					min: n,
					max: a
				} = r.layout.layoutBox[t], o = i.get() || 0;
				i.set(e[t] - Ht(n, a, .5) + o)
			}
		})
	}
	scalePositionWithinConstraints() {
		if (!this.visualElement.current) return;
		const {
			drag: e,
			dragConstraints: t
		} = this.getProps(), {
			projection: n
		} = this.visualElement;
		if (!al(t) || !n || !this.constraints) return;
		this.stopAnimation();
		const r = {
			x: 0,
			y: 0
		};
		_n(e => {
			const t = this.getAxisMotionValue(e);
			if (t && !1 !== this.constraints) {
				const n = t.get();
				r[e] = f3({
					min: n,
					max: n
				}, this.constraints[e])
			}
		});
		const {
			transformTemplate: i
		} = this.visualElement.getProps();
		this.visualElement.current.style.transform = i ? i({}, "") : "none", n.root && n.root.updateScroll(), n.updateLayout(), this.constraints = !1, this.resolveConstraints(), _n(t => {
			if (!yo(t, e, null)) return;
			const n = this.getAxisMotionValue(t),
				{
					min: i,
					max: a
				} = this.constraints[t];
			n.set(Ht(i, a, r[t]))
		}), this.visualElement.render()
	}
	addListeners() {
		if (!this.visualElement.current) return;
		m3.set(this.visualElement, this);
		const e = this.visualElement.current,
			t = Ss(e, "pointerdown", t => {
				const {
					drag: n,
					dragListener: r = !0
				} = this.getProps(), i = t.target, a = i !== e && JT(i);
				n && r && !a && this.start(t)
			});
		let n;
		const r = () => {
			const {
				dragConstraints: t
			} = this.getProps();
			al(t) && t.current && (this.constraints = this.resolveRefConstraints(), n || (n = y3(e, t.current, () => this.scalePositionWithinConstraints())))
		},
			{
				projection: i
			} = this.visualElement,
			a = i.addEventListener("measure", r);
		i && !i.layout && (i.root && i.root.updateScroll(), i.updateLayout()), Yt.read(r);
		const o = Cs(window, "resize", () => this.scalePositionWithinConstraints()),
			s = i.addEventListener("didUpdate", ({
				delta: e,
				hasLayoutChanged: t
			}) => {
				this.isDragging && t && (_n(t => {
					const n = this.getAxisMotionValue(t);
					n && (this.originPoint[t] += e[t].translate, n.set(n.get() + e[t].translate))
				}), this.visualElement.render())
			});
		return () => {
			o(), t(), a(), s && s(), n && n()
		}
	}
	getProps() {
		const e = this.visualElement.getProps(),
			{
				drag: t = !1,
				dragDirectionLock: n = !1,
				dragPropagation: r = !1,
				dragConstraints: i = !1,
				dragElastic: a = yd,
				dragMomentum: o = !0
			} = e;
		return {
			...e,
			drag: t,
			dragDirectionLock: n,
			dragPropagation: r,
			dragConstraints: i,
			dragElastic: a,
			dragMomentum: o
		}
	}
}

function qg(e) {
	let t = !0;
	return () => {
		t ? t = !1 : e()
	}
}

function y3(e, t, n) {
	const r = ky(e, qg(n)),
		i = ky(t, qg(n));
	return () => {
		r(), i()
	}
}

function yo(e, t, n) {
	return !(!0 !== t && t !== e || null !== n && n !== e)
}

function g3(e, t = 10) {
	let n = null;
	return Math.abs(e.y) > t ? n = "y" : Math.abs(e.x) > t && (n = "x"), n
}
class v3 extends _i {
	constructor(e) {
		super(e), this.removeGroupControls = rn, this.removeListeners = rn, this.controls = new p3(e)
	}
	mount() {
		const {
			dragControls: e
		} = this.node.getProps();
		e && (this.removeGroupControls = e.subscribe(this.controls)), this.removeListeners = this.controls.addListeners() || rn
	}
	update() {
		const {
			dragControls: e
		} = this.node.getProps(), {
			dragControls: t
		} = this.node.prevProps || {};
		e !== t && (this.removeGroupControls(), e && (this.removeGroupControls = e.subscribe(this.controls)))
	}
	unmount() {
		this.removeGroupControls(), this.removeListeners(), this.controls.isDragging || this.controls.endPanSession()
	}
}
const Xf = e => (t, n) => {
	e && Yt.update(() => e(t, n), !1, !0)
};
class b3 extends _i {
	constructor() {
		super(...arguments), this.removePointerDownListener = rn
	}
	onPointerDown(e) {
		this.session = new w1(e, this.createPanHandlers(), {
			transformPagePoint: this.node.getTransformPagePoint(),
			contextWindow: z1(this.node)
		})
	}
	createPanHandlers() {
		const {
			onPanSessionStart: e,
			onPanStart: t,
			onPan: n,
			onPanEnd: r
		} = this.node.getProps();
		return {
			onSessionStart: Xf(e),
			onStart: Xf(t),
			onMove: Xf(n),
			onEnd: (e, t) => {
				delete this.session, r && Yt.postRender(() => r(e, t))
			}
		}
	}
	mount() {
		this.removePointerDownListener = Ss(this.node.current, "pointerdown", e => this.onPointerDown(e))
	}
	update() {
		this.session && this.session.updateHandlers(this.createPanHandlers())
	}
	unmount() {
		this.removePointerDownListener(), this.session && this.session.end()
	}
}
let Qf = !1;
class x3 extends Z.Component {
	componentDidMount() {
		const {
			visualElement: e,
			layoutGroup: t,
			switchLayoutGroup: n,
			layoutId: r
		} = this.props, {
			projection: i
		} = e;
		i && (t.group && t.group.add(i), n && n.register && r && n.register(i), Qf && i.root.didUpdate(), i.addEventListener("animationComplete", () => {
			this.safeToRemove()
		}), i.setOptions({
			...i.options,
			layoutDependency: this.props.layoutDependency,
			onExitComplete: () => this.safeToRemove()
		})), Ao.hasEverUpdated = !0
	}
	getSnapshotBeforeUpdate(e) {
		const {
			layoutDependency: t,
			visualElement: n,
			drag: r,
			isPresent: i
		} = this.props, {
			projection: a
		} = n;
		return a && (a.isPresent = i, e.layoutDependency !== t && a.setOptions({
			...a.options,
			layoutDependency: t
		}), Qf = !0, r || e.layoutDependency !== t || void 0 === t || e.isPresent !== i ? a.willUpdate() : this.safeToRemove(), e.isPresent !== i && (i ? a.promote() : a.relegate() || Yt.postRender(() => {
			const e = a.getStack();
			(!e || !e.members.length) && this.safeToRemove()
		}))), null
	}
	componentDidUpdate() {
		const {
			visualElement: e,
			layoutAnchor: t
		} = this.props, {
			projection: n
		} = e;
		n && (n.options.layoutAnchor = t, n.root.didUpdate(), Yd.postRender(() => {
			!n.currentAnimation && n.isLead() && this.safeToRemove()
		}))
	}
	componentWillUnmount() {
		const {
			visualElement: e,
			layoutGroup: t,
			switchLayoutGroup: n
		} = this.props, {
			projection: r
		} = e;
		Qf = !0, r && (r.scheduleCheckAfterUnmount(), t && t.group && t.group.remove(r), n && n.deregister && n.deregister(r))
	}
	safeToRemove() {
		const {
			safeToRemove: e
		} = this.props;
		e && e()
	}
	render() {
		return null
	}
}

function R1(e) {
	const [t, n] = S1(), r = Z.useContext(Sd);
	return E.jsx(x3, {
		...e,
		layoutGroup: r,
		switchLayoutGroup: Z.useContext(N1),
		isPresent: t,
		safeToRemove: n
	})
}
const S3 = {
	pan: {
		Feature: b3
	},
	drag: {
		Feature: v3,
		ProjectionNode: x1,
		MeasureLayout: R1
	}
};

function Xg(e, t, n) {
	const {
		props: r
	} = e;
	e.animationState && r.whileHover && e.animationState.setActive("whileHover", "Start" === n);
	const i = r["onHover" + n];
	i && Yt.postRender(() => i(t, js(t)))
}
class T3 extends _i {
	mount() {
		const {
			current: e
		} = this.node;
		e && (this.unmount = QT(e, (e, t) => (Xg(this.node, t, "Start"), e => Xg(this.node, e, "End"))))
	}
	unmount() { }
}
class E3 extends _i {
	constructor() {
		super(...arguments), this.isActive = !1
	}
	onFocus() {
		let e = !1;
		try {
			e = this.node.current.matches(":focus-visible")
		} catch {
			e = !0
		} !e || !this.node.animationState || (this.node.animationState.setActive("whileFocus", !0), this.isActive = !0)
	}
	onBlur() {
		!this.isActive || !this.node.animationState || (this.node.animationState.setActive("whileFocus", !1), this.isActive = !1)
	}
	mount() {
		this.unmount = ws(Cs(this.node.current, "focus", () => this.onFocus()), Cs(this.node.current, "blur", () => this.onBlur()))
	}
	unmount() { }
}

function Qg(e, t, n) {
	const {
		props: r
	} = e;
	if (e.current instanceof HTMLButtonElement && e.current.disabled) return;
	e.animationState && r.whileTap && e.animationState.setActive("whileTap", "Start" === n);
	const i = r["onTap" + ("End" === n ? "" : n)];
	i && Yt.postRender(() => i(t, js(t)))
}
class A3 extends _i {
	mount() {
		const {
			current: e
		} = this.node;
		if (!e) return;
		const {
			globalTapTarget: t,
			propagate: n
		} = this.node.props;
		this.unmount = FT(e, (e, t) => (Qg(this.node, t, "Start"), (e, {
			success: t
		}) => Qg(this.node, e, t ? "End" : "Cancel")), {
			useGlobalTarget: t,
			stopPropagation: !1 === (null == n ? void 0 : n.tap)
		})
	}
	unmount() { }
}
const gd = new WeakMap,
	Zf = new WeakMap,
	M3 = e => {
		const t = gd.get(e.target);
		t && t(e)
	},
	C3 = e => {
		e.forEach(M3)
	};

function D3({
	root: e,
	...t
}) {
	const n = e || document;
	Zf.has(n) || Zf.set(n, {});
	const r = Zf.get(n),
		i = JSON.stringify(t);
	return r[i] || (r[i] = new IntersectionObserver(C3, {
		root: e,
		...t
	})), r[i]
}

function N3(e, t, n) {
	const r = D3(t);
	return gd.set(e, n), r.observe(e), () => {
		gd.delete(e), r.unobserve(e)
	}
}
const O3 = {
	some: 0,
	all: 1
};
class z3 extends _i {
	constructor() {
		super(...arguments), this.hasEnteredView = !1, this.isInView = !1
	}
	startObserver() {
		var e;
		null == (e = this.stopObserver) || e.call(this);
		const {
			viewport: t = {}
		} = this.node.getProps(), {
			root: n,
			margin: r,
			amount: i = "some",
			once: a
		} = t, o = {
			root: n ? n.current : void 0,
			rootMargin: r,
			threshold: "number" == typeof i ? i : O3[i]
		};
		this.stopObserver = N3(this.node.current, o, e => {
			const {
				isIntersecting: t
			} = e;
			if (this.isInView === t || (this.isInView = t, a && !t && this.hasEnteredView)) return;
			t && (this.hasEnteredView = !0), this.node.animationState && this.node.animationState.setActive("whileInView", t);
			const {
				onViewportEnter: n,
				onViewportLeave: r
			} = this.node.getProps(), i = t ? n : r;
			i && i(e)
		})
	}
	mount() {
		this.startObserver()
	}
	update() {
		if (typeof IntersectionObserver > "u") return;
		const {
			props: e,
			prevProps: t
		} = this.node;
		["amount", "margin", "root"].some(w3(e, t)) && this.startObserver()
	}
	unmount() {
		var e;
		null == (e = this.stopObserver) || e.call(this), this.hasEnteredView = !1, this.isInView = !1
	}
}

function w3({
	viewport: e = {}
}, {
	viewport: t = {}
} = {}) {
	return n => e[n] !== t[n]
}
const _3 = {
	inView: {
		Feature: z3
	},
	tap: {
		Feature: A3
	},
	focus: {
		Feature: E3
	},
	hover: {
		Feature: T3
	}
},
	R3 = {
		layout: {
			ProjectionNode: x1,
			MeasureLayout: R1
		}
	},
	j3 = {
		...i3,
		..._3,
		...S3,
		...R3
	},
	V3 = $A(j3, WA),
	Se = V3,
	B3 = new Date("2026-10-30T00:00:00").getTime();

function U3() {
	const [e, t] = Z.useState({
		days: 0,
		hours: 0,
		minutes: 0,
		seconds: 0,
		total: 1
	}), [n, r] = Z.useState(!1);
	Z.useEffect(() => {
		const e = () => {
			const e = (new Date).getTime(),
				t = B3 - e;
			return t <= 0 ? (r(!0), {
				days: 0,
				hours: 0,
				minutes: 0,
				seconds: 0,
				total: 0
			}) : {
				days: Math.floor(t / 864e5),
				hours: Math.floor(t / 36e5 % 24),
				minutes: Math.floor(t / 1e3 / 60 % 60),
				seconds: Math.floor(t / 1e3 % 60),
				total: t
			}
		},
			n = e();
		t(n), n.total <= 0 && r(!0);
		const i = setInterval(() => {
			const n = e();
			t(n), n.total <= 0 && clearInterval(i)
		}, 1e3);
		return () => clearInterval(i)
	}, []);
	const i = [{
		label: "Days",
		value: e.days
	}, {
		label: "Hours",
		value: e.hours
	}, {
		label: "Minutes",
		value: e.minutes
	}, {
		label: "Seconds",
		value: e.seconds
	}];
	return E.jsx(Go, {
		children: !n && E.jsx(Se.div, {
			layout: !0,
			initial: {
				opacity: 0,
				y: 20
			},
			animate: {
				opacity: 1,
				y: 0
			},
			exit: {
				opacity: 0,
				height: 0,
				scale: .9,
				marginTop: 0,
				marginBottom: 0
			},
			transition: {
				duration: .8,
				ease: "easeInOut"
			},
			className: "flex justify-center gap-4 sm:gap-8 mb-20 overflow-hidden",
			children: i.map((e, t) => E.jsxs("div", {
				className: "flex flex-col items-center",
				children: [E.jsx("div", {
					className: "text-4xl sm:text-6xl md:text-7xl font-serif font-bold text-white mb-2",
					children: e.value.toString().padStart(2, "0")
				}), E.jsx("div", {
					className: "text-xs sm:text-sm uppercase tracking-[0.2em] text-[#29abe2] font-medium",
					children: e.label
				})]
			}, t))
		})
	})
}

function L3() {
	return E.jsxs("section", {
		className: "relative min-h-[100vh] flex flex-col justify-center items-center text-center px-6 pt-20 pb-40 overflow-hidden bg-navy",
		children: [E.jsxs("picture", {
			className: "absolute inset-0 z-0 pointer-events-none",
			children: [E.jsx("source", {
				media: "(min-width: 768px)",
				srcSet: "./images/Laxmi-Vilas-Palace2.avif",
				type: "image/avif"
			}), E.jsx("source", {
				media: "(max-width: 767.98px)",
				srcSet: "./images/Laxmi-Vilas-Palace-Mob.avif",
				type: "image/avif"
			}), E.jsx("img", {
				src: "./images/Laxmi-Vilas-Palace2.avif",
				alt: "Laxmi Vilas Palace",
				fetchPriority: "high",
				loading: "eager",
				decoding: "async",
				className: "w-full h-full object-cover object-center opacity-35"
			})]
		}), E.jsx("div", {
			className: "absolute inset-0 z-1 bg-gradient-to-b from-navy/40 via-navy/60 to-navy"
		}), E.jsx("div", {
			className: "relative z-10 max-w-5xl mx-auto w-full mt-auto",
			children: E.jsxs(Se.div, {
				initial: {
					opacity: 0,
					y: 30
				},
				animate: {
					opacity: 1,
					y: 0
				},
				transition: {
					duration: 1,
					ease: "easeOut"
				},
				children: [E.jsxs("div", {
					className: "flex items-center justify-center gap-4 sm:gap-6 mb-8",
					children: [E.jsx("div", {
						title: "Baroda Medical College",
						className: "w-14 h-14 sm:w-16 sm:h-16 md:w-20 md:h-20 rounded-full overflow-hidden bg-white shadow-xl border-2 border-white/40 flex items-center justify-center hover:scale-105 transition-all duration-300",
						children: E.jsx("img", {
							src: "./images/Baroda_Medical_College.webp",
							alt: "Baroda Medical College",
							className: "w-full h-full object-cover",
							onError: e => {
								e.currentTarget.src = "./images/bmc-placeholder.svg"
							}
						})
					}), E.jsx("div", {
						title: "Pinnacle Superspeciality Hospital & Research Centre",
						className: "w-14 h-14 sm:w-16 sm:h-16 md:w-20 md:h-20 rounded-full overflow-hidden bg-white shadow-xl border-2 border-white/40 flex items-center justify-center hover:scale-105 transition-all duration-300",
						children: E.jsx("img", {
							src: "./images/Pinnacle_Superspeciality_Hospital_And_Research_Centre.webp",
							alt: "Pinnacle Superspeciality Hospital & Research Centre",
							className: "w-full h-full object-contain",
							onError: e => {
								e.currentTarget.src = "./images/pinnacle-placeholder.svg"
							}
						})
					})]
				}), E.jsxs("h1", {
					className: "text-5xl md:text-7xl lg:text-8xl font-serif text-white mb-8 leading-[1.1]",
					children: [E.jsx("span", {
						className: "text-7xl md:text-8xl lg:text-9xl",
						children: "2"
					}), E.jsx("sup", {
						children: "nd"
					}), " ENDOSPINE", E.jsx("br", {}), E.jsx("span", {
						className: "text-[#29abe2] italic font-light",
						children: "UBECON"
					})]
				}), E.jsxs("p", {
					className: "text-lg md:text-2xl text-white/80 max-w-3xl mx-auto leading-relaxed font-light mb-5",
					children: [E.jsx("strong", {
						children: "Unilateral Biportal Endoscopy (UBE) Course"
					}), " — Advanced learning with a hands-on cadaveric workshop, in association with Baroda Medical College (BMC). Learn from leading experts and advance the future of endoscopic spine surgery."]
				}), E.jsx(U3, {})]
			})
		})]
	})
}
/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const H3 = e => e.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase(),
	Y3 = e => e.replace(/^([A-Z])|[\s-_]+(\w)/g, (e, t, n) => n ? n.toUpperCase() : t.toLowerCase()),
	Zg = e => {
		const t = Y3(e);
		return t.charAt(0).toUpperCase() + t.slice(1)
	},
	j1 = (...e) => e.filter((e, t, n) => !!e && "" !== e.trim() && n.indexOf(e) === t).join(" ").trim(),
	G3 = e => {
		for (const t in e)
			if (t.startsWith("aria-") || "role" === t || "title" === t) return !0
	};
/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
var q3 = {
	xmlns: "http://www.w3.org/2000/svg",
	width: 24,
	height: 24,
	viewBox: "0 0 24 24",
	fill: "none",
	stroke: "currentColor",
	strokeWidth: 2,
	strokeLinecap: "round",
	strokeLinejoin: "round"
};
/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const X3 = Z.forwardRef(({
	color: e = "currentColor",
	size: t = 24,
	strokeWidth: n = 2,
	absoluteStrokeWidth: r,
	className: i = "",
	children: a,
	iconNode: o,
	...s
}, l) => Z.createElement("svg", {
	ref: l,
	...q3,
	width: t,
	height: t,
	stroke: e,
	strokeWidth: r ? 24 * Number(n) / Number(t) : n,
	className: j1("lucide", i),
	...!a && !G3(s) && {
		"aria-hidden": "true"
	},
	...s
}, [...o.map(([e, t]) => Z.createElement(e, t)), ...Array.isArray(a) ? a : [a]])),
	de = (e, t) => {
		const n = Z.forwardRef(({
			className: n,
			...r
		}, i) => Z.createElement(X3, {
			ref: i,
			iconNode: t,
			className: j1(`lucide-${H3(Zg(e))}`, `lucide-${e}`, n),
			...r
		}));
		return n.displayName = Zg(e), n
	},
	Q3 = [
		["path", {
			d: "M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2",
			key: "169zse"
		}]
	],
	Z3 = de("activity", Q3),
	K3 = [
		["path", {
			d: "M12 10h.01",
			key: "1nrarc"
		}],
		["path", {
			d: "M12 14h.01",
			key: "1etili"
		}],
		["path", {
			d: "M12 6h.01",
			key: "1vi96p"
		}],
		["path", {
			d: "M16 10h.01",
			key: "1m94wz"
		}],
		["path", {
			d: "M16 14h.01",
			key: "1gbofw"
		}],
		["path", {
			d: "M16 6h.01",
			key: "1x0f13"
		}],
		["path", {
			d: "M8 10h.01",
			key: "19clt8"
		}],
		["path", {
			d: "M8 14h.01",
			key: "6423bh"
		}],
		["path", {
			d: "M8 6h.01",
			key: "1dz90k"
		}],
		["path", {
			d: "M9 22v-3a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v3",
			key: "cabbwy"
		}],
		["rect", {
			x: "4",
			y: "2",
			width: "16",
			height: "20",
			rx: "2",
			key: "1uxh74"
		}]
	],
	P3 = de("building", K3),
	J3 = [
		["path", {
			d: "M8 2v4",
			key: "1cmpym"
		}],
		["path", {
			d: "M16 2v4",
			key: "4m81vk"
		}],
		["rect", {
			width: "18",
			height: "18",
			x: "3",
			y: "4",
			rx: "2",
			key: "1hopcy"
		}],
		["path", {
			d: "M3 10h18",
			key: "8toen8"
		}]
	],
	k3 = de("calendar", J3),
	F3 = [
		["path", {
			d: "m15 18-6-6 6-6",
			key: "1wnfg3"
		}]
	],
	I3 = de("chevron-left", F3),
	$3 = [
		["path", {
			d: "m9 18 6-6-6-6",
			key: "mthhwq"
		}]
	],
	W3 = de("chevron-right", $3),
	tM = [
		["path", {
			d: "M12 6v6l4 2",
			key: "mmk7yg"
		}],
		["circle", {
			cx: "12",
			cy: "12",
			r: "10",
			key: "1mglay"
		}]
	],
	eM = de("clock", tM),
	nM = [
		["circle", {
			cx: "12",
			cy: "12",
			r: "10",
			key: "1mglay"
		}],
		["path", {
			d: "M12 16v-4",
			key: "1dtifu"
		}],
		["path", {
			d: "M12 8h.01",
			key: "e9boi3"
		}]
	],
	iM = de("info", nM),
	aM = [
		["rect", {
			width: "18",
			height: "11",
			x: "3",
			y: "11",
			rx: "2",
			ry: "2",
			key: "1w4ew1"
		}],
		["path", {
			d: "M7 11V7a5 5 0 0 1 10 0v4",
			key: "fwvmzm"
		}]
	],
	lM = de("lock", aM),
	sM = [
		["path", {
			d: "m22 7-8.991 5.727a2 2 0 0 1-2.009 0L2 7",
			key: "132q7q"
		}],
		["rect", {
			x: "2",
			y: "4",
			width: "20",
			height: "16",
			rx: "2",
			key: "izxlao"
		}]
	],
	uM = de("mail", sM),
	oM = [
		["path", {
			d: "M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0",
			key: "1r0f0z"
		}],
		["circle", {
			cx: "12",
			cy: "10",
			r: "3",
			key: "ilqhr7"
		}]
	],
	Ds = de("map-pin", oM),
	rM = [
		["path", {
			d: "M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z",
			key: "18887p"
		}]
	],
	cM = de("message-square", rM),
	fM = [
		["path", {
			d: "M6 18h8",
			key: "1borvv"
		}],
		["path", {
			d: "M3 22h18",
			key: "8prr45"
		}],
		["path", {
			d: "M14 22a7 7 0 1 0 0-14h-1",
			key: "1jwaiy"
		}],
		["path", {
			d: "M9 14h2",
			key: "197e7h"
		}],
		["path", {
			d: "M9 12a2 2 0 0 1-2-2V6h6v4a2 2 0 0 1-2 2Z",
			key: "1bmzmy"
		}],
		["path", {
			d: "M12 6V3a1 1 0 0 0-1-1H9a1 1 0 0 0-1 1v3",
			key: "1drr47"
		}]
	],
	dM = de("microscope", fM),
	hM = [
		["path", {
			d: "M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384",
			key: "9njp5v"
		}]
	],
	Kg = de("phone", hM),
	mM = [
		["path", {
			d: "M22 14a8 8 0 0 1-8 8",
			key: "56vcr3"
		}],
		["path", {
			d: "M18 11v-1a2 2 0 0 0-2-2a2 2 0 0 0-2 2",
			key: "1agjmk"
		}],
		["path", {
			d: "M14 10V9a2 2 0 0 0-2-2a2 2 0 0 0-2 2v1",
			key: "wdbh2u"
		}],
		["path", {
			d: "M10 9.5V4a2 2 0 0 0-2-2a2 2 0 0 0-2 2v10",
			key: "1ibuk9"
		}],
		["path", {
			d: "M18 11a2 2 0 1 1 4 0v3a8 8 0 0 1-8 8h-2c-2.8 0-4.5-.86-5.99-2.34l-3.6-3.6a2 2 0 0 1 2.83-2.82L7 15",
			key: "g6ys72"
		}]
	],
	pM = de("pointer", mM),
	yM = [
		["path", {
			d: "M2 3h20",
			key: "91anmk"
		}],
		["path", {
			d: "M21 3v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3",
			key: "2k9sn8"
		}],
		["path", {
			d: "m7 21 5-5 5 5",
			key: "bip4we"
		}]
	],
	gM = de("presentation", yM),
	vM = [
		["path", {
			d: "M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2",
			key: "975kel"
		}],
		["circle", {
			cx: "12",
			cy: "7",
			r: "4",
			key: "17ys0d"
		}]
	],
	bM = de("user", vM),
	xM = [
		["path", {
			d: "M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z",
			key: "uqj9uw"
		}],
		["path", {
			d: "M16 9a5 5 0 0 1 0 6",
			key: "1q6k2b"
		}],
		["path", {
			d: "M19.364 18.364a9 9 0 0 0 0-12.728",
			key: "ijwkga"
		}]
	],
	SM = de("volume-2", xM),
	TM = [
		["path", {
			d: "M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z",
			key: "uqj9uw"
		}],
		["line", {
			x1: "22",
			x2: "16",
			y1: "9",
			y2: "15",
			key: "1ewh16"
		}],
		["line", {
			x1: "16",
			x2: "22",
			y1: "9",
			y2: "15",
			key: "5ykzw1"
		}]
	],
	EM = de("volume-x", TM);
/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
function AM() {
	return E.jsx("section", {
		className: "relative z-20 px-4 md:px-8 -mt-24",
		children: E.jsxs(Se.div, {
			initial: {
				opacity: 0,
				y: 40
			},
			whileInView: {
				opacity: 1,
				y: 0
			},
			viewport: {
				once: !0,
				margin: "-100px"
			},
			transition: {
				duration: .8
			},
			className: "max-w-5xl mx-auto bg-white border border-slate-200 p-8 md:p-12 shadow-xl relative overflow-hidden",
			children: [E.jsx("div", {
				className: "absolute top-0 right-0 w-64 h-64 bg-[#29abe2]/5 rounded-full blur-[80px]"
			}), E.jsxs("div", {
				className: "grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-12 relative z-10",
				children: [E.jsxs("div", {
					className: "flex flex-col gap-3",
					children: [E.jsx("div", {
						className: "w-12 h-12 rounded-full border border-[#29abe2]/30 bg-[#29abe2]/5 flex items-center justify-center text-[#29abe2] mb-2",
						children: E.jsx(k3, {
							size: 20,
							strokeWidth: 1.5
						})
					}), E.jsx("h3", {
						className: "text-sm uppercase tracking-[0.2em] text-slate-500 font-medium",
						children: "Date"
					}), E.jsx("p", {
						className: "text-xl font-serif text-navy",
						children: "Oct 31 - Nov 1, 2026"
					})]
				}), E.jsxs("div", {
					className: "flex flex-col gap-3 md:border-l md:border-slate-100 md:pl-8",
					children: [E.jsx("div", {
						className: "w-12 h-12 rounded-full border border-[#29abe2]/30 bg-[#29abe2]/5 flex items-center justify-center text-[#29abe2] mb-2",
						children: E.jsx(Ds, {
							size: 20,
							strokeWidth: 1.5
						})
					}), E.jsx("h3", {
						className: "text-sm uppercase tracking-[0.2em] text-slate-500 font-medium",
						children: "Scientific Conference"
					}), E.jsx("a", {
						href: "https://maps.app.goo.gl/ZcguYbYZT9jg3n3n9",
						target: "_blank",
						rel: "noopener noreferrer",
						className: "text-md font-serif text-navy leading-snug hover:text-[#29abe2] transition-colors block cursor-pointer",
						children: "The Fern Vadodara, Series by Marriott, RC Dutt Rd, behind Alkapuri Petrol Pump, Vishwas Colony, Vadiwadi, Vadodara, Gujarat 390007"
					})]
				}), E.jsxs("div", {
					className: "flex flex-col gap-3 md:border-l md:border-slate-100 md:pl-8",
					children: [E.jsx("div", {
						className: "w-12 h-12 rounded-full border border-[#29abe2]/30 bg-[#29abe2]/5 flex items-center justify-center text-[#29abe2] mb-2",
						children: E.jsx(Ds, {
							size: 20,
							strokeWidth: 1.5
						})
					}), E.jsx("h3", {
						className: "text-sm uppercase tracking-[0.2em] text-slate-500 font-medium",
						children: "Cadaveric Workshop"
					}), E.jsx("a", {
						href: "https://maps.app.goo.gl/7t98TRBZvzCAgTq28",
						target: "_blank",
						rel: "noopener noreferrer",
						className: "text-md font-serif text-navy leading-snug hover:text-[#29abe2] transition-colors block cursor-pointer",
						children: "Baroda Medical College (Department of Anatomy), Vadodara"
					})]
				})]
			}), /* E.jsxs("div",{className:"relative z-10 bg-[#e6f6fd] border-l-4 border-[#29abe2] p-6 md:p-8 italic",children:[E.jsx(iM,{className:"text-[#29abe2] mb-4",size:24,strokeWidth:1.5}),E.jsxs("p",{className:"text-lg md:text-xl text-slate-800 leading-relaxed font-serif",children:[E.jsx("span",{className:"font-bold text-navy not-italic",children:"Important Note:"})," Accommodation check-in date 31th Oct 2026 12:00 noon and check-out date 1st Nov 2026 12:00 noon."]})]}) */]
		})
	})
}

function MM(e) {
	return "[object Object]" === Object.prototype.toString.call(e)
}

function Pg(e) {
	return MM(e) || Array.isArray(e)
}

function CM() {
	return !!(typeof window < "u" && window.document && window.document.createElement)
}

function Fd(e, t) {
	const n = Object.keys(e),
		r = Object.keys(t);
	if (n.length !== r.length) return !1;
	return JSON.stringify(Object.keys(e.breakpoints || {})) === JSON.stringify(Object.keys(t.breakpoints || {})) && n.every(n => {
		const r = e[n],
			i = t[n];
		return "function" == typeof r ? `${r}` == `${i}` : Pg(r) && Pg(i) ? Fd(r, i) : r === i
	})
}

function Jg(e) {
	return e.concat().sort((e, t) => e.name > t.name ? 1 : -1).map(e => e.options)
}

function DM(e, t) {
	if (e.length !== t.length) return !1;
	const n = Jg(e),
		r = Jg(t);
	return n.every((e, t) => Fd(e, r[t]))
}

function Id(e) {
	return "number" == typeof e
}

function vd(e) {
	return "string" == typeof e
}

function Xo(e) {
	return "boolean" == typeof e
}

function kg(e) {
	return "[object Object]" === Object.prototype.toString.call(e)
}

function Kt(e) {
	return Math.abs(e)
}

function $d(e) {
	return Math.sign(e)
}

function Ts(e, t) {
	return Kt(e - t)
}

function NM(e, t) {
	if (0 === e || 0 === t || Kt(e) <= Kt(t)) return 0;
	const n = Ts(Kt(e), Kt(t));
	return Kt(n / e)
}

function OM(e) {
	return Math.round(100 * e) / 100
}

function Ns(e) {
	return Os(e).map(Number)
}

function bn(e) {
	return e[Vs(e)]
}

function Vs(e) {
	return Math.max(0, e.length - 1)
}

function Wd(e, t) {
	return t === Vs(e)
}

function Fg(e, t = 0) {
	return Array.from(Array(e), (e, n) => t + n)
}

function Os(e) {
	return Object.keys(e)
}

function V1(e, t) {
	return [e, t].reduce((e, t) => (Os(t).forEach(n => {
		const r = e[n],
			i = t[n],
			a = kg(r) && kg(i);
		e[n] = a ? V1(r, i) : i
	}), e), {})
}

function bd(e, t) {
	return typeof t.MouseEvent < "u" && e instanceof t.MouseEvent
}

function zM(e, t) {
	const n = {
		start: function () {
			return 0
		},
		center: function (e) {
			return r(e) / 2
		},
		end: r
	};

	function r(e) {
		return t - e
	}
	return {
		measure: function (r, i) {
			return vd(e) ? n[e](r) : e(t, r, i)
		}
	}
}

function zs() {
	let e = [];
	const t = {
		add: function (n, r, i, a = {
			passive: !0
		}) {
			let o;
			if ("addEventListener" in n) n.addEventListener(r, i, a), o = () => n.removeEventListener(r, i, a);
			else {
				const e = n;
				e.addListener(i), o = () => e.removeListener(i)
			}
			return e.push(o), t
		},
		clear: function () {
			e = e.filter(e => e())
		}
	};
	return t
}

function wM(e, t, n, r) {
	const i = zs(),
		a = 1e3 / 60;
	let o = null,
		s = 0,
		l = 0;

	function u(e) {
		if (!l) return;
		o || (o = e, n(), n());
		const i = e - o;
		for (o = e, s += i; s >= a;) n(), s -= a;
		r(s / a), l && (l = t.requestAnimationFrame(u))
	}

	function c() {
		t.cancelAnimationFrame(l), o = null, s = 0, l = 0
	}
	return {
		init: function () {
			i.add(e, "visibilitychange", () => {
				e.hidden && (o = null, s = 0)
			})
		},
		destroy: function () {
			c(), i.clear()
		},
		start: function () {
			l || (l = t.requestAnimationFrame(u))
		},
		stop: c,
		update: n,
		render: r
	}
}

function _M(e, t) {
	const n = "rtl" === t,
		r = "y" === e,
		i = !r && n ? -1 : 1;
	return {
		scroll: r ? "y" : "x",
		cross: r ? "x" : "y",
		startEdge: r ? "top" : n ? "right" : "left",
		endEdge: r ? "bottom" : n ? "left" : "right",
		measureSize: function (e) {
			const {
				height: t,
				width: n
			} = e;
			return r ? t : n
		},
		direction: function (e) {
			return e * i
		}
	}
}

function fa(e = 0, t = 0) {
	const n = Kt(e - t);

	function r(t) {
		return t < e
	}

	function i(e) {
		return e > t
	}

	function a(e) {
		return r(e) || i(e)
	}
	return {
		length: n,
		max: t,
		min: e,
		constrain: function (n) {
			return a(n) ? r(n) ? e : t : n
		},
		reachedAny: a,
		reachedMax: i,
		reachedMin: r,
		removeOffset: function (e) {
			return n ? e - n * Math.ceil((e - t) / n) : e
		}
	}
}

function B1(e, t, n) {
	const {
		constrain: r
	} = fa(0, e), i = e + 1;
	let a = o(t);

	function o(e) {
		return n ? Kt((i + e) % i) : r(e)
	}

	function s() {
		return a
	}

	function l() {
		return B1(e, s(), n)
	}
	const u = {
		get: s,
		set: function (e) {
			return a = o(e), u
		},
		add: function (e) {
			return l().set(s() + e)
		},
		clone: l
	};
	return u
}

function RM(e, t, n, r, i, a, o, s, l, u, c, d, f, h, p, m, g, v, y) {
	const {
		cross: b,
		direction: x
	} = e, w = ["INPUT", "SELECT", "TEXTAREA"], S = {
		passive: !1
	}, E = zs(), k = zs(), T = fa(50, 225).constrain(h.measure(20)), P = {
		mouse: 300,
		touch: 400
	}, C = {
		mouse: 500,
		touch: 600
	}, N = p ? 43 : 25;
	let M = !1,
		A = 0,
		_ = 0,
		L = !1,
		D = !1,
		j = !1,
		O = !1;

	function z(e) {
		if (!bd(e, r) && e.touches.length >= 2) return R(e);
		const t = a.readPoint(e),
			n = a.readPoint(e, b),
			o = Ts(t, A),
			l = Ts(n, _);
		if (!(D || O || e.cancelable && (D = o > l, D))) return R(e);
		const c = a.pointerMove(e);
		o > m && (j = !0), u.useFriction(.3).useDuration(.75), s.start(), i.add(x(c)), e.preventDefault()
	}

	function R(e) {
		const t = c.byDistance(0, !1).index !== d.get(),
			n = a.pointerUp(e) * (p ? C : P)[O ? "mouse" : "touch"],
			r = function (e, t) {
				const n = d.add(-1 * $d(e)),
					r = c.byDistance(e, !p).distance;
				return p || Kt(e) < T ? r : g && t ? .5 * r : c.byIndex(n.get(), 0).distance
			}(x(n), t),
			i = NM(n, r),
			o = N - 10 * i,
			s = v + i / 50;
		D = !1, L = !1, k.clear(), u.useDuration(o).useFriction(s), l.distance(r, !p), O = !1, f.emit("pointerUp")
	}

	function F(e) {
		j && (e.stopPropagation(), e.preventDefault(), j = !1)
	}
	return {
		init: function (e) {
			if (!y) return;

			function s(s) {
				(Xo(y) || y(e, s)) && function (e) {
					const s = bd(e, r);
					O = s, j = p && s && !e.buttons && M, M = Ts(i.get(), o.get()) >= 2, (!s || 0 === e.button) && (function (e) {
						const t = e.nodeName || "";
						return w.includes(t)
					}(e.target) || (L = !0, a.pointerDown(e), u.useFriction(0).useDuration(0), i.set(o), function () {
						const e = O ? n : t;
						k.add(e, "touchmove", z, S).add(e, "touchend", R).add(e, "mousemove", z, S).add(e, "mouseup", R)
					}(), A = a.readPoint(e), _ = a.readPoint(e, b), f.emit("pointerDown")))
				}(s)
			}
			const l = t;
			E.add(l, "dragstart", e => e.preventDefault(), S).add(l, "touchmove", () => { }, S).add(l, "touchend", () => { }).add(l, "touchstart", s).add(l, "mousedown", s).add(l, "touchcancel", R).add(l, "contextmenu", R).add(l, "click", F, !0)
		},
		destroy: function () {
			E.clear(), k.clear()
		},
		pointerDown: function () {
			return L
		}
	}
}

function jM(e, t) {
	let n, r;

	function i(e) {
		return e.timeStamp
	}

	function a(n, r) {
		const i = "client" + ("x" === (r || e.scroll) ? "X" : "Y");
		return (bd(n, t) ? n : n.touches[0])[i]
	}
	return {
		pointerDown: function (e) {
			return n = e, r = e, a(e)
		},
		pointerMove: function (e) {
			const t = a(e) - a(r),
				o = i(e) - i(n) > 170;
			return r = e, o && (n = e), t
		},
		pointerUp: function (e) {
			if (!n || !r) return 0;
			const t = a(r) - a(n),
				o = i(e) - i(n),
				s = i(e) - i(r) > 170,
				l = t / o;
			return o && !s && Kt(l) > .1 ? l : 0
		},
		readPoint: a
	}
}

function VM() {
	return {
		measure: function (e) {
			const {
				offsetTop: t,
				offsetLeft: n,
				offsetWidth: r,
				offsetHeight: i
			} = e;
			return {
				top: t,
				right: n + r,
				bottom: t + i,
				left: n,
				width: r,
				height: i
			}
		}
	}
}

function BM(e) {
	return {
		measure: function (t) {
			return e * (t / 100)
		}
	}
}

function UM(e, t, n, r, i, a, o) {
	const s = [e].concat(r);
	let l, u, c = [],
		d = !1;

	function f(e) {
		return i.measureSize(o.measure(e))
	}
	return {
		init: function (i) {
			a && (u = f(e), c = r.map(f), l = new ResizeObserver(n => {
				(Xo(a) || a(i, n)) && function (n) {
					for (const a of n) {
						if (d) return;
						const n = a.target === e,
							o = r.indexOf(a.target),
							s = n ? u : c[o];
						if (Kt(f(n ? e : r[o]) - s) >= .5) {
							i.reInit(), t.emit("resize");
							break
						}
					}
				}(n)
			}), n.requestAnimationFrame(() => {
				s.forEach(e => l.observe(e))
			}))
		},
		destroy: function () {
			d = !0, l && l.disconnect()
		}
	}
}

function LM(e, t, n, r, i, a) {
	let o = 0,
		s = 0,
		l = i,
		u = a,
		c = e.get(),
		d = 0;

	function f(e) {
		return l = e, p
	}

	function h(e) {
		return u = e, p
	}
	const p = {
		direction: function () {
			return s
		},
		duration: function () {
			return l
		},
		velocity: function () {
			return o
		},
		seek: function () {
			const t = r.get() - e.get();
			let i = 0;
			return !l ? (o = 0, n.set(r), e.set(r), i = t) : (n.set(e), o += t / l, o *= u, c += o, e.add(o), i = c - d), s = $d(i), d = c, p
		},
		settled: function () {
			return Kt(r.get() - t.get()) < .001
		},
		useBaseFriction: function () {
			return h(a)
		},
		useBaseDuration: function () {
			return f(i)
		},
		useFriction: h,
		useDuration: f
	};
	return p
}

function HM(e, t, n, r, i) {
	const a = i.measure(10),
		o = i.measure(50),
		s = fa(.1, .99);
	let l = !1;

	function u() {
		return !(l || !e.reachedAny(n.get()) || !e.reachedAny(t.get()))
	}
	return {
		shouldConstrain: u,
		constrain: function (i) {
			if (!u()) return;
			const l = e.reachedMin(t.get()) ? "min" : "max",
				c = Kt(e[l] - t.get()),
				d = n.get() - t.get(),
				f = s.constrain(c / o);
			n.subtract(d * f), !i && Kt(d) < a && (n.set(e.constrain(n.get())), r.useDuration(25).useBaseFriction())
		},
		toggleActive: function (e) {
			l = !e
		}
	}
}

function YM(e, t, n, r, i) {
	const a = fa(-t + e, 0),
		o = n.map((e, t) => {
			const {
				min: r,
				max: i
			} = a, o = a.constrain(e), s = !t, u = Wd(n, t);
			return s ? i : u || l(r, o) ? r : l(i, o) ? i : o
		}).map(e => parseFloat(e.toFixed(3))),
		s = function () {
			const e = o[0],
				t = bn(o),
				n = o.lastIndexOf(e),
				r = o.indexOf(t) + 1;
			return fa(n, r)
		}();

	function l(e, t) {
		return Ts(e, t) <= 1
	}
	return {
		snapsContained: function () {
			if (t <= e + i) return [a.max];
			if ("keepSnaps" === r) return o;
			const {
				min: n,
				max: l
			} = s;
			return o.slice(n, l)
		}(),
		scrollContainLimit: s
	}
}

function GM(e, t, n) {
	const r = t[0];
	return {
		limit: fa(n ? r - e : bn(t), r)
	}
}

function qM(e, t, n, r) {
	const i = t.min + .1,
		a = t.max + .1,
		{
			reachedMin: o,
			reachedMax: s
		} = fa(i, a);
	return {
		loop: function (t) {
			if (! function (e) {
				return 1 === e ? s(n.get()) : -1 === e && o(n.get())
			}(t)) return;
			const i = e * (-1 * t);
			r.forEach(e => e.add(i))
		}
	}
}

function XM(e) {
	const {
		max: t,
		length: n
	} = e;
	return {
		get: function (e) {
			return n ? (e - t) / -n : 0
		}
	}
}

function QM(e, t, n, r, i) {
	const {
		startEdge: a,
		endEdge: o
	} = e, {
		groupSlides: s
	} = i, l = s(r).map(e => bn(e)[o] - e[0][a]).map(Kt).map(t.measure), u = r.map(e => n[a] - e[a]).map(e => -Kt(e)), c = s(u).map(e => e[0]).map((e, t) => e + l[t]);
	return {
		snaps: u,
		snapsAligned: c
	}
}

function ZM(e, t, n, r, i, a) {
	const {
		groupSlides: o
	} = i, {
		min: s,
		max: l
	} = r;
	return {
		slideRegistry: function () {
			const r = o(a),
				i = !e || "keepSnaps" === t;
			return 1 === n.length ? [a] : i ? r : r.slice(s, l).map((e, t, n) => {
				const r = !t,
					i = Wd(n, t);
				if (r) {
					return Fg(bn(n[0]) + 1)
				}
				if (i) {
					return Fg(Vs(a) - bn(n)[0] + 1, bn(n)[0])
				}
				return e
			})
		}()
	}
}

function KM(e, t, n, r, i) {
	const {
		reachedAny: a,
		removeOffset: o,
		constrain: s
	} = r;

	function l(e) {
		return e.concat().sort((e, t) => Kt(e) - Kt(t))[0]
	}

	function u(t, r) {
		const i = [t, t + n, t - n];
		if (!e) return t;
		if (!r) return l(i);
		const a = i.filter(e => $d(e) === r);
		return a.length ? l(a) : bn(i) - n
	}
	return {
		byDistance: function (n, r) {
			const l = i.get() + n,
				{
					index: c,
					distance: d
				} = function (n) {
					const r = e ? o(n) : s(n),
						i = t.map((e, t) => ({
							diff: u(e - r, 0),
							index: t
						})).sort((e, t) => Kt(e.diff) - Kt(t.diff)),
						{
							index: a
						} = i[0];
					return {
						index: a,
						distance: r
					}
				}(l),
				f = !e && a(l);
			return !r || f ? {
				index: c,
				distance: n
			} : {
				index: c,
				distance: n + u(t[c] - d, 0)
			}
		},
		byIndex: function (e, n) {
			return {
				index: e,
				distance: u(t[e] - i.get(), n)
			}
		},
		shortcut: u
	}
}

function PM(e, t, n, r, i, a, o) {
	function s(i) {
		const s = i.distance,
			l = i.index !== t.get();
		a.add(s), s && (r.duration() ? e.start() : (e.update(), e.render(1), e.update())), l && (n.set(t.get()), t.set(i.index), o.emit("select"))
	}
	return {
		distance: function (e, t) {
			s(i.byDistance(e, t))
		},
		index: function (e, n) {
			const r = t.clone().set(e);
			s(i.byIndex(r.get(), n))
		}
	}
}

function JM(e, t, n, r, i, a, o, s) {
	const l = {
		passive: !0,
		capture: !0
	};
	let u = 0;

	function c(e) {
		"Tab" === e.code && (u = (new Date).getTime())
	}
	return {
		init: function (d) {
			s && (a.add(document, "keydown", c, !1), t.forEach((t, c) => {
				a.add(t, "focus", t => {
					(Xo(s) || s(d, t)) && function (t) {
						if ((new Date).getTime() - u > 10) return;
						o.emit("slideFocusStart"), e.scrollLeft = 0;
						const a = n.findIndex(e => e.includes(t));
						Id(a) && (i.useDuration(0), r.index(a, 0), o.emit("slideFocus"))
					}(c)
				}, l)
			}))
		}
	}
}

function gs(e) {
	let t = e;

	function n(e) {
		return Id(e) ? e : e.get()
	}
	return {
		get: function () {
			return t
		},
		set: function (e) {
			t = n(e)
		},
		add: function (e) {
			t += n(e)
		},
		subtract: function (e) {
			t -= n(e)
		}
	}
}

function U1(e, t) {
	const n = "x" === e.scroll ? function (e) {
		return `translate3d(${e}px,0px,0px)`
	} : function (e) {
		return `translate3d(0px,${e}px,0px)`
	},
		r = t.style;
	let i = null,
		a = !1;
	return {
		clear: function () {
			a || (r.transform = "", t.getAttribute("style") || t.removeAttribute("style"))
		},
		to: function (t) {
			if (a) return;
			const o = OM(e.direction(t));
			o !== i && (r.transform = n(o), i = o)
		},
		toggleActive: function (e) {
			a = !e
		}
	}
}

function kM(e, t, n, r, i, a, o, s, l) {
	const u = Ns(i),
		c = Ns(i).reverse(),
		d = function () {
			const e = o[0];
			return p(h(c, e), n, !1)
		}().concat(function () {
			const e = t - o[0] - 1;
			return p(h(u, e), -n, !0)
		}());

	function f(e, t) {
		return e.reduce((e, t) => e - i[t], t)
	}

	function h(e, t) {
		return e.reduce((e, n) => f(e, t) > 0 ? e.concat([n]) : e, [])
	}

	function p(i, o, u) {
		const c = function (e) {
			return a.map((n, i) => ({
				start: n - r[i] + .5 + e,
				end: n + t - .5 + e
			}))
		}(o);
		return i.map(t => {
			const r = u ? 0 : -n,
				i = u ? n : 0,
				a = u ? "end" : "start",
				o = c[t][a];
			return {
				index: t,
				loopPoint: o,
				slideLocation: gs(-1),
				translate: U1(e, l[t]),
				target: () => s.get() > o ? r : i
			}
		})
	}
	return {
		canLoop: function () {
			return d.every(({
				index: e
			}) => f(u.filter(t => t !== e), t) <= .1)
		},
		clear: function () {
			d.forEach(e => e.translate.clear())
		},
		loop: function () {
			d.forEach(e => {
				const {
					target: t,
					translate: n,
					slideLocation: r
				} = e, i = t();
				i !== r.get() && (n.to(i), r.set(i))
			})
		},
		loopPoints: d
	}
}

function FM(e, t, n) {
	let r, i = !1;
	return {
		init: function (a) {
			n && (r = new MutationObserver(e => {
				i || (Xo(n) || n(a, e)) && function (e) {
					for (const n of e)
						if ("childList" === n.type) {
							a.reInit(), t.emit("slidesChanged");
							break
						}
				}(e)
			}), r.observe(e, {
				childList: !0
			}))
		},
		destroy: function () {
			r && r.disconnect(), i = !0
		}
	}
}

function IM(e, t, n, r) {
	const i = {};
	let a, o = null,
		s = null,
		l = !1;
	return {
		init: function () {
			a = new IntersectionObserver(e => {
				l || (e.forEach(e => {
					const n = t.indexOf(e.target);
					i[n] = e
				}), o = null, s = null, n.emit("slidesInView"))
			}, {
				root: e.parentElement,
				threshold: r
			}), t.forEach(e => a.observe(e))
		},
		destroy: function () {
			a && a.disconnect(), l = !0
		},
		get: function (e = !0) {
			if (e && o) return o;
			if (!e && s) return s;
			const t = function (e) {
				return Os(i).reduce((t, n) => {
					const r = parseInt(n),
						{
							isIntersecting: a
						} = i[r];
					return (e && a || !e && !a) && t.push(r), t
				}, [])
			}(e);
			return e && (o = t), e || (s = t), t
		}
	}
}

function $M(e, t, n, r, i, a) {
	const {
		measureSize: o,
		startEdge: s,
		endEdge: l
	} = e, u = n[0] && i, c = function () {
		if (!u) return 0;
		const e = n[0];
		return Kt(t[s] - e[s])
	}(), d = function () {
		if (!u) return 0;
		const e = a.getComputedStyle(bn(r));
		return parseFloat(e.getPropertyValue(`margin-${l}`))
	}(), f = n.map(o), h = n.map((e, t, n) => {
		const r = !t,
			i = Wd(n, t);
		return r ? f[t] + c : i ? f[t] + d : n[t + 1][s] - e[s]
	}).map(Kt);
	return {
		slideSizes: f,
		slideSizesWithGaps: h,
		startGap: c,
		endGap: d
	}
}

function WM(e, t, n, r, i, a, o, s, l) {
	const {
		startEdge: u,
		endEdge: c,
		direction: d
	} = e, f = Id(n);
	return {
		groupSlides: function (e) {
			return f ? function (e, t) {
				return Ns(e).filter(e => e % t === 0).map(n => e.slice(n, n + t))
			}(e, n) : function (e) {
				return e.length ? Ns(e).reduce((n, f, h) => {
					const p = bn(n) || 0,
						m = 0 === p,
						g = f === Vs(e),
						v = i[u] - a[p][u],
						y = i[u] - a[f][c],
						b = !r && m ? d(o) : 0,
						x = Kt(y - (!r && g ? d(s) : 0) - (v + b));
					return h && x > t + l && n.push(f), g && n.push(e.length), n
				}, []).map((t, n, r) => {
					const i = Math.max(r[n - 1] || 0);
					return e.slice(i, t)
				}) : []
			}(e)
		}
	}
}

function tC(e, t, n, r, i, a, o) {
	const {
		align: s,
		axis: l,
		direction: u,
		startIndex: c,
		loop: d,
		duration: f,
		dragFree: h,
		dragThreshold: p,
		inViewThreshold: m,
		slidesToScroll: g,
		skipSnaps: v,
		containScroll: y,
		watchResize: b,
		watchSlides: x,
		watchDrag: w,
		watchFocus: S
	} = a, E = VM(), k = E.measure(t), T = n.map(E.measure), P = _M(l, u), C = P.measureSize(k), N = BM(C), M = zM(s, C), A = !d && !!y, _ = d || !!y, {
		slideSizes: L,
		slideSizesWithGaps: D,
		startGap: j,
		endGap: O
	} = $M(P, k, T, n, _, i), z = WM(P, C, g, d, k, T, j, O, 2), {
		snaps: R,
		snapsAligned: F
	} = QM(P, M, k, T, z), I = -bn(R) + bn(D), {
		snapsContained: V,
		scrollContainLimit: B
	} = YM(C, I, F, y, 2), U = A ? V : F, {
		limit: H
	} = GM(I, U, d), $ = B1(Vs(U), c, d), W = $.clone(), Z = Ns(n), Y = wM(r, i, () => (({
		dragHandler: e,
		scrollBody: t,
		scrollBounds: n,
		options: {
			loop: r
		}
	}) => {
		r || n.constrain(e.pointerDown()), t.seek()
	})(se), e => (({
		scrollBody: e,
		translate: t,
		location: n,
		offsetLocation: r,
		previousLocation: i,
		scrollLooper: a,
		slideLooper: o,
		dragHandler: s,
		animation: l,
		eventHandler: u,
		scrollBounds: c,
		options: {
			loop: d
		}
	}, f) => {
		const h = e.settled(),
			p = !c.shouldConstrain(),
			m = d ? h : h && p,
			g = m && !s.pointerDown();
		g && l.stop();
		const v = n.get() * f + i.get() * (1 - f);
		r.set(v), d && (a.loop(e.direction()), o.loop()), t.to(r.get()), g && u.emit("settle"), m || u.emit("scroll")
	})(se, e)), q = U[$.get()], K = gs(q), Q = gs(q), X = gs(q), G = gs(q), J = LM(K, X, Q, G, f, .68), ee = KM(d, U, I, H, G), te = PM(Y, $, W, J, ee, G, o), ne = XM(H), re = zs(), ie = IM(t, n, o, m), {
		slideRegistry: ae
	} = ZM(A, y, U, B, z, Z), oe = JM(e, n, ae, te, J, re, o, S), se = {
		ownerDocument: r,
		ownerWindow: i,
		eventHandler: o,
		containerRect: k,
		slideRects: T,
		animation: Y,
		axis: P,
		dragHandler: RM(P, e, r, i, G, jM(P, i), K, Y, te, J, ee, $, o, N, h, p, v, .68, w),
		eventStore: re,
		percentOfView: N,
		index: $,
		indexPrevious: W,
		limit: H,
		location: K,
		offsetLocation: X,
		previousLocation: Q,
		options: a,
		resizeHandler: UM(t, o, i, n, P, b, E),
		scrollBody: J,
		scrollBounds: HM(H, X, G, J, N),
		scrollLooper: qM(I, H, X, [K, X, Q, G]),
		scrollProgress: ne,
		scrollSnapList: U.map(ne.get),
		scrollSnaps: U,
		scrollTarget: ee,
		scrollTo: te,
		slideLooper: kM(P, C, I, L, D, R, U, X, n),
		slideFocus: oe,
		slidesHandler: FM(t, o, x),
		slidesInView: ie,
		slideIndexes: Z,
		slideRegistry: ae,
		slidesToScroll: z,
		target: G,
		translate: U1(P, t)
	};
	return se
}

function eC() {
	let e, t = {};

	function n(e) {
		return t[e] || []
	}
	const r = {
		init: function (t) {
			e = t
		},
		emit: function (t) {
			return n(t).forEach(n => n(e, t)), r
		},
		off: function (e, i) {
			return t[e] = n(e).filter(e => e !== i), r
		},
		on: function (e, i) {
			return t[e] = n(e).concat([i]), r
		},
		clear: function () {
			t = {}
		}
	};
	return r
}
const nC = {
	align: "center",
	axis: "x",
	container: null,
	slides: null,
	containScroll: "trimSnaps",
	direction: "ltr",
	slidesToScroll: 1,
	inViewThreshold: 0,
	breakpoints: {},
	dragFree: !1,
	dragThreshold: 10,
	loop: !1,
	skipSnaps: !1,
	duration: 25,
	startIndex: 0,
	active: !0,
	watchDrag: !0,
	watchResize: !0,
	watchSlides: !0,
	watchFocus: !0
};

function iC(e) {
	function t(e, t) {
		return V1(e, t || {})
	}
	return {
		mergeOptions: t,
		optionsAtMedia: function (n) {
			const r = n.breakpoints || {},
				i = Os(r).filter(t => e.matchMedia(t).matches).map(e => r[e]).reduce((e, n) => t(e, n), {});
			return t(n, i)
		},
		optionsMediaQueries: function (t) {
			return t.map(e => Os(e.breakpoints || {})).reduce((e, t) => e.concat(t), []).map(e.matchMedia)
		}
	}
}

function aC(e) {
	let t = [];
	return {
		init: function (n, r) {
			return t = r.filter(({
				options: t
			}) => !1 !== e.optionsAtMedia(t).active), t.forEach(t => t.init(n, e)), r.reduce((e, t) => Object.assign(e, {
				[t.name]: t
			}), {})
		},
		destroy: function () {
			t = t.filter(e => e.destroy())
		}
	}
}

function Vo(e, t, n) {
	const r = e.ownerDocument,
		i = r.defaultView,
		a = iC(i),
		o = aC(a),
		s = zs(),
		l = eC(),
		{
			mergeOptions: u,
			optionsAtMedia: c,
			optionsMediaQueries: d
		} = a,
		{
			on: f,
			off: h,
			emit: p
		} = l,
		m = P;
	let g, v, y, b, x = !1,
		w = u(nC, Vo.globalOptions),
		S = u(w),
		E = [];

	function k(t) {
		const n = tC(e, y, b, r, i, t, l);
		if (t.loop && !n.slideLooper.canLoop()) {
			return k(Object.assign({}, t, {
				loop: !1
			}))
		}
		return n
	}

	function T(t, n) {
		x || (w = u(w, t), S = c(w), E = n || E, function () {
			const {
				container: t,
				slides: n
			} = S;
			y = (vd(t) ? e.querySelector(t) : t) || e.children[0];
			const r = vd(n) ? y.querySelectorAll(n) : n;
			b = [].slice.call(r || y.children)
		}(), g = k(S), d([w, ...E.map(({
			options: e
		}) => e)]).forEach(e => s.add(e, "change", P)), S.active && (g.translate.to(g.location.get()), g.animation.init(), g.slidesInView.init(), g.slideFocus.init(A), g.eventHandler.init(A), g.resizeHandler.init(A), g.slidesHandler.init(A), g.options.loop && g.slideLooper.loop(), y.offsetParent && b.length && g.dragHandler.init(A), v = o.init(A, E)))
	}

	function P(e, t) {
		const n = M();
		C(), T(u({
			startIndex: n
		}, e), t), l.emit("reInit")
	}

	function C() {
		g.dragHandler.destroy(), g.eventStore.clear(), g.translate.clear(), g.slideLooper.clear(), g.resizeHandler.destroy(), g.slidesHandler.destroy(), g.slidesInView.destroy(), g.animation.destroy(), o.destroy(), s.clear()
	}

	function N(e, t, n) {
		!S.active || x || (g.scrollBody.useBaseFriction().useDuration(!0 === t ? 0 : S.duration), g.scrollTo.index(e, n || 0))
	}

	function M() {
		return g.index.get()
	}
	const A = {
		canScrollNext: function () {
			return g.index.add(1).get() !== M()
		},
		canScrollPrev: function () {
			return g.index.add(-1).get() !== M()
		},
		containerNode: function () {
			return y
		},
		internalEngine: function () {
			return g
		},
		destroy: function () {
			x || (x = !0, s.clear(), C(), l.emit("destroy"), l.clear())
		},
		off: h,
		on: f,
		emit: p,
		plugins: function () {
			return v
		},
		previousScrollSnap: function () {
			return g.indexPrevious.get()
		},
		reInit: m,
		rootNode: function () {
			return e
		},
		scrollNext: function (e) {
			N(g.index.add(1).get(), e, -1)
		},
		scrollPrev: function (e) {
			N(g.index.add(-1).get(), e, 1)
		},
		scrollProgress: function () {
			return g.scrollProgress.get(g.offsetLocation.get())
		},
		scrollSnapList: function () {
			return g.scrollSnapList
		},
		scrollTo: N,
		selectedScrollSnap: M,
		slideNodes: function () {
			return b
		},
		slidesInView: function () {
			return g.slidesInView.get()
		},
		slidesNotInView: function () {
			return g.slidesInView.get(!1)
		}
	};
	return T(t, n), setTimeout(() => l.emit("init"), 0), A
}

function Qo(e = {}, t = []) {
	const n = Z.useRef(e),
		r = Z.useRef(t),
		[i, a] = Z.useState(),
		[o, s] = Z.useState(),
		l = Z.useCallback(() => {
			i && i.reInit(n.current, r.current)
		}, [i]);
	return Z.useEffect(() => {
		Fd(n.current, e) || (n.current = e, l())
	}, [e, l]), Z.useEffect(() => {
		DM(r.current, t) || (r.current = t, l())
	}, [t, l]), Z.useEffect(() => {
		if (CM() && o) {
			Vo.globalOptions = Qo.globalOptions;
			const e = Vo(o, n.current, r.current);
			return a(e), () => e.destroy()
		}
		a(void 0)
	}, [o, a]), [s, i]
}
Vo.globalOptions = void 0, Qo.globalOptions = void 0;
const lC = [{
	title: "UBE surgery",
	image: "https://images.unsplash.com/photo-1551076805-e1869033e561?auto=format&fit=crop&q=80&w=800",
	Icon: Z3
}, {
	title: "Didactic lectures from faculties",
	image: "https://images.unsplash.com/photo-1540575467063-178a50c2df87?auto=format&fit=crop&q=80&w=800",
	Icon: gM
}, {
	title: "Cadaveric workshop",
	image: "./images/Cadaveric_workshop.avif",
	Icon: dM
}, {
	title: "Panel discussion + Re-live surgery",
	image: "https://images.unsplash.com/photo-1551818255-e6e10975bc17?auto=format&fit=crop&q=80&w=800",
	Icon: cM
}];

function sC() {
	const [e] = Qo({
		align: "start",
		loop: !1,
		dragFree: !0
	});
	return E.jsxs("section", {
		className: "py-24 md:py-40 bg-slate-50 overflow-hidden",
		children: [E.jsx("div", {
			className: "max-w-7xl mx-auto px-6 md:px-12 mb-16",
			children: E.jsxs(Se.div, {
				initial: {
					opacity: 0,
					y: 30
				},
				whileInView: {
					opacity: 1,
					y: 0
				},
				viewport: {
					once: !0
				},
				transition: {
					duration: .8
				},
				children: [E.jsx("h2", {
					className: "text-sm uppercase tracking-[0.3em] text-[#29abe2] mb-4 font-medium",
					children: "The Program"
				}), E.jsx("h3", {
					className: "text-4xl md:text-5xl font-serif text-navy",
					children: "What You Will Experience"
				})]
			})
		}), E.jsx("div", {
			className: "pl-6 md:pl-12 lg:pl-[max(3rem,calc((100vw-80rem)/2))] cursor-grab active:cursor-grabbing",
			children: E.jsx("div", {
				className: "overflow-hidden",
				ref: e,
				children: E.jsx("div", {
					className: "flex -ml-4 md:-ml-8 pb-12",
					children: lC.map((e, t) => E.jsx("div", {
						className: "flex-[0_0_85%] sm:flex-[0_0_50%] lg:flex-[0_0_35%] pl-4 md:pl-8",
						children: E.jsxs(Se.div, {
							className: "group relative h-[450px] overflow-hidden rounded-xl shadow-lg bg-white border border-slate-100",
							children: [E.jsx("img", {
								src: e.image,
								alt: e.title,
								className: "absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105 opacity-90"
							}), E.jsx("div", {
								className: "absolute inset-0 bg-gradient-to-t from-navy/90 via-navy/40 to-transparent"
							}), E.jsxs("div", {
								className: "absolute inset-0 p-8 flex flex-col justify-end",
								children: [E.jsxs("div", {
									className: "w-12 h-12 bg-white/10 backdrop-blur-md rounded-full flex items-center justify-center mb-6 overflow-hidden relative border border-white/20",
									children: [E.jsx("div", {
										className: "absolute inset-0 bg-[#29abe2] translate-y-full group-hover:translate-y-0 transition-transform duration-300"
									}), E.jsx(e.Icon, {
										size: 20,
										className: "text-white relative z-10"
									})]
								}), E.jsx("h4", {
									className: "text-2xl font-serif text-white leading-tight group-hover:text-[#29abe2] transition-colors duration-300",
									children: e.title
								})]
							})]
						})
					}, t))
				})
			})
		})]
	})
}
const uC = [{
	name: "Dr. Shaishav Shah",
	role: "UBE Course Director",
	desc: "Endoscopic Spine Surgeon",
	image: "./images/Organizing_Committee4.avif"
}, {
	name: "Prof R.G. Aiyer",
	role: "Patron",
	desc: "Medical Superintendent, BMC",
	image: "./images/Organizing_Committee1.avif"
}, {
	name: "Prof H. Mathur",
	role: "Patron",
	desc: "HOD, Orthopedics",
	image: "./images/Organizing_Committee2.avif"
}, {
	name: "Prof A. Udainia",
	role: "Patron",
	desc: "HOD, Anatomy",
	image: "./images/Organizing_Committee3.avif"
}, {
	name: "Prof D. Parmar",
	role: "Patron",
	desc: "Dean, BMC",
	image: "./images/Organizing_Committee5.webp"
}],
	oC = [{
		name: "Dr. Jose Machado",
		location: "Portugal",
		image: "./images/UBE_International_Faculty1.avif"
	}, {
		name: "Dr. Piya Chavalparit",
		location: "Thailand",
		image: "./images/UBE_International_Faculty2.avif"
	}, {
		name: "Dr. Nadir Benmebarek",
		location: "Algeria",
		image: "./images/UBE_International_Faculty3.avif"
	}, {
		name: "Dr. Zoryan Saldan",
		location: "Ukraine",
		image: "./images/UBE_International_Faculty4.avif"
	}],
	rC = [{
		name: "Dr. Anindya Basu",
		location: "Kolkata",
		image: "./images/UBE_National_Faculty1.avif"
	}, {
		name: "Dr. Bhupesh Patel",
		location: "Ahmedabad",
		image: "./images/UBE_National_Faculty2.avif"
	}, {
		name: "Dr. Vardan Kulshreshtha",
		location: "Karnal",
		image: "./images/UBE_National_Faculty3.avif"
	}, {
		name: "Dr. Raghvendra Raghuvanshi",
		location: "Bhopal",
		image: "./images/UBE_National_Faculty5.avif"
	}],
	Kf = ({
		title: e,
		data: t,
		type: n
	}) => {
		const [r, i] = Qo({
			align: "start",
			loop: !1,
			slidesToScroll: 1
		}), [a, o] = co.useState(!1), [s, l] = co.useState(!1), [u, c] = co.useState(!1), d = Z.useCallback(() => {
			i && i.scrollPrev()
		}, [i]), f = Z.useCallback(() => {
			i && i.scrollNext()
		}, [i]), h = Z.useCallback(() => {
			i && (o(i.canScrollPrev()), l(i.canScrollNext()), c(i.canScrollPrev() || i.canScrollNext()))
		}, [i]);
		return co.useEffect(() => {
			i && (h(), i.on("select", h), i.on("reInit", h))
		}, [i, h]), E.jsxs("div", {
			className: "mb-20 last:mb-0",
			children: [E.jsxs("div", {
				className: "flex items-center justify-between mb-8 px-4 md:px-0",
				children: [E.jsx("h4", {
					className: "text-xl md:text-3xl font-serif text-navy border-l-4 border-[#29abe2] pl-3 md:pl-4",
					children: e
				}), u && E.jsxs("div", {
					className: "flex gap-2",
					children: [E.jsx("button", {
						onClick: d,
						disabled: !a,
						className: "w-10 h-10 md:w-12 md:h-12 rounded-full border flex items-center justify-center transition-colors " + (a ? "border-slate-200 text-slate-600 hover:bg-[#29abe2] hover:text-white hover:border-[#29abe2]" : "border-slate-100 text-slate-300 cursor-not-allowed"),
						children: E.jsx(I3, {
							size: 20
						})
					}), E.jsx("button", {
						onClick: f,
						disabled: !s,
						className: "w-10 h-10 md:w-12 md:h-12 rounded-full border flex items-center justify-center transition-colors " + (s ? "border-slate-200 text-slate-600 hover:bg-[#29abe2] hover:text-white hover:border-[#29abe2]" : "border-slate-100 text-slate-300 cursor-not-allowed"),
						children: E.jsx(W3, {
							size: 20
						})
					})]
				})]
			}), E.jsx("div", {
				className: "overflow-hidden px-4 md:px-0",
				ref: r,
				children: E.jsx("div", {
					className: "flex -ml-4 py-4",
					children: t.map((e, t) => E.jsx("div", {
						className: "flex-[0_0_50%] md:flex-[0_0_33.33%] lg:flex-[0_0_25%] pl-4",
						children: E.jsxs(Se.div, {
							initial: {
								opacity: 0,
								y: 20
							},
							whileInView: {
								opacity: 1,
								y: 0
							},
							viewport: {
								once: !0
							},
							transition: {
								duration: .5,
								delay: .1 * t
							},
							className: "bg-white rounded-xl md:rounded-2xl p-4 md:p-6 shadow-sm border border-slate-100 h-full flex flex-col items-center text-center group hover:-translate-y-1 md:hover:-translate-y-2 transition-transform duration-300",
							children: [E.jsx("div", {
								className: "w-20 h-20 md:w-32 md:h-32 rounded-full overflow-hidden mb-4 md:mb-6 border-2 md:border-4 border-[#29abe2]/10 p-1",
								children: E.jsx("img", {
									src: e.image,
									alt: e.name,
									className: "w-full h-full object-cover rounded-full group-hover:scale-110 transition-transform duration-500"
								})
							}), E.jsx("h5", {
								className: "text-sm md:text-xl font-serif text-navy mb-1 md:mb-2 leading-tight",
								children: e.name
							}), "organizing" === n ? E.jsxs(E.Fragment, {
								children: [E.jsx("p", {
									className: "text-xs md:text-sm font-medium text-[#29abe2] mb-1",
									children: e.role
								}), E.jsx("p", {
									className: "text-[10px] md:text-sm text-slate-500 italic leading-tight",
									children: e.desc
								})]
							}) : E.jsxs("div", {
								className: "flex items-center gap-1 text-slate-500 mt-1 md:mt-2",
								children: [E.jsx(Ds, {
									size: 14,
									className: "text-[#29abe2] shrink-0 md:w-4 md:h-4"
								}), E.jsx("span", {
									className: "text-xs md:text-sm font-medium truncate",
									children: e.location
								})]
							})]
						})
					}, t))
				})
			})]
		})
	};

function cC() {
	return E.jsx("section", {
		className: "pb-24 md:pb-32 bg-slate-50 relative overflow-hidden",
		children: E.jsxs("div", {
			className: "max-w-[1440px] mx-auto md:px-12 lg:px-24",
			children: [E.jsxs(Se.div, {
				initial: {
					opacity: 0,
					y: 30
				},
				whileInView: {
					opacity: 1,
					y: 0
				},
				viewport: {
					once: !0
				},
				transition: {
					duration: .8
				},
				className: "text-center mb-16 px-6",
				children: [E.jsx("h2", {
					className: "text-sm uppercase tracking-[0.3em] text-[#29abe2] mb-4 font-medium",
					children: "The Prestige"
				}), E.jsx("h3", {
					className: "text-4xl md:text-5xl lg:text-6xl font-serif text-navy",
					children: "Faculty & Committees"
				})]
			}), E.jsx(Kf, {
				title: "Organizing Committee",
				data: uC,
				type: "organizing"
			}), E.jsx(Kf, {
				title: "International Faculty",
				data: oC,
				type: "faculty"
			}), E.jsx(Kf, {
				title: "National Faculty",
				data: rC,
				type: "faculty"
			})]
		})
	})
}
const fC = {
	day1: [{
		time: "08:00 AM - 08:50 AM",
		title: "Registration & Welcome Breakfast",
		location: "Utsav-2 Hall 2nd Floor"
	}, {
		time: "08:50 AM - 10:50 AM",
		title: "Didactic lectures",
		speaker: "Prof R.G. Aiyer & Dr. Shaishav Shah",
		location: "Utsav-1 Hall 2nd Floor"
	}, {
		time: "10:50 AM - 11:05 AM",
		title: "Tea-Coffee break",
		location: "Utsav-1 Hall 2nd Floor"
	}, {
		time: "11:05 AM - 12:25 PM",
		title: "Live Surgery Session 1: Lumbar Decompression",
		speaker: "Dr. Joao Machado",
		location: "Operating Theater 1 (Broadcast to Auditorium)"
	}, {
		time: "12:25 PM - 01:30 PM",
		title: "Networking Lunch",
		location: "Dining Hall"
	}, {
		time: "01:30 PM - 02:30 PM",
		title: "Re-Live Surgery: Operative Video with Commentary",
		speaker: "Team Endospine"
		// location: "Auditorium A"
	},{
		time: "02:30 PM - 03:50 PM",
		title: "FORAMINAL ACCESS, FUSION & SAFETY",
		speaker: "International Faculty Panel"
		// location: "Auditorium A"
	},{
		time: "03:50 PM - 04:05 PM",
		title: "Evening Tea / Coffee Break"
		// location: "Auditorium A"
	},{
		time: "04:05 PM - 05:40 PM",
		title: "CERVICAL & THORACIC UBE"
		// speaker: "International Faculty Panel",
		// location: "Auditorium A"
	},{
		time: "05:40 PM - 05:50 PM",
		title: "Closing Remarks & Day 2 Cadaveric Workshop Briefing",
		speaker: "Organizing Team",
		// location: "Auditorium A"
	}
],
	day2: [{
		time: "08:00 AM - 08:30 AM",
		title: "Breakfast & Briefing",
		location: "Baroda Medical College, Department of Anatomy",
		locationLink: "https://maps.app.goo.gl/d9CcxjsbDLr5Be246"
	}, {
		time: "08:30 AM - 01:00 PM",
		title: "Hands-on Cadaveric Workshop",
		speaker: "All National & International Faculty",
		location: "Anatomy Lab, Baroda Medical College"
	}, {
		time: "01:00 PM - 02:00 PM",
		title: "Lunch Break",
		location: "Dining Hall"
	}, {
		time: "02:00 PM - 04:30 PM",
		title: "Hands-on Cadaveric Workshop",
		speaker: "All National & International Faculty",
		location: "Anatomy Lab, Baroda Medical College",
	}, {
		time: "04:30 PM - 05:00 PM",
		title: "Closing Ceremony & Certificate Distribution",
		speaker: "Organizing Committee",
		location: "Main Auditorium"
	}]
};

function dC() {
	const [e, t] = Z.useState("day1");
	return Z.useEffect(() => {
		new Date >= new Date("2026-11-01T00:00:00") && t("day2")
	}, []), E.jsx("section", {
		className: "py-24 md:py-32 bg-white relative border-t border-slate-100",
		children: E.jsxs("div", {
			className: "max-w-4xl mx-auto px-6 md:px-12",
			children: [E.jsxs(Se.div, {
				initial: {
					opacity: 0,
					y: 30
				},
				whileInView: {
					opacity: 1,
					y: 0
				},
				viewport: {
					once: !0
				},
				transition: {
					duration: .8
				},
				className: "text-center mb-16",
				children: [E.jsx("h2", {
					className: "text-sm uppercase tracking-[0.3em] text-[#29abe2] mb-4 font-medium",
					children: "The Agenda"
				}), E.jsx("h3", {
					className: "text-4xl md:text-5xl font-serif text-navy",
					children: "Course Information"
				})]
			}), E.jsxs("div", {
				className: "flex flex-col md:flex-row justify-center gap-4 mb-12",
				children: [E.jsx("button", {
					onClick: () => t("day1"),
					className: "px-8 py-3 rounded-full text-sm font-medium transition-all " + ("day1" === e ? "bg-[#29abe2] text-white shadow-lg shadow-[#29abe2]/25" : "bg-slate-50 text-slate-600 hover:bg-slate-100 border border-slate-200"),
					children: "Day 1: Oct 31, 2026"
				}), E.jsx("button", {
					onClick: () => t("day2"),
					className: "px-8 py-3 rounded-full text-sm font-medium transition-all " + ("day2" === e ? "bg-[#29abe2] text-white shadow-lg shadow-[#29abe2]/25" : "bg-slate-50 text-slate-600 hover:bg-slate-100 border border-slate-200"),
					children: "Day 2: Nov 1, 2026"
				})]
			}), E.jsx("div", {
				className: "relative min-h-[400px]",
				children: E.jsx(Go, {
					mode: "wait",
					children: E.jsx(Se.div, {
						initial: {
							opacity: 0,
							y: 20
						},
						animate: {
							opacity: 1,
							y: 0
						},
						exit: {
							opacity: 0,
							y: -20
						},
						transition: {
							duration: .3
						},
						className: "space-y-4",
						children: fC[e].map((e, t) => E.jsxs("div", {
							className: "bg-slate-50 border border-slate-100 rounded-2xl p-6 md:p-8 flex flex-col md:flex-row md:items-center gap-6 hover:shadow-md transition-shadow duration-300 group",
							children: [E.jsxs("div", {
								className: "md:w-1/3 shrink-0 flex items-center gap-3 text-[#29abe2]",
								children: [E.jsx(eM, {
									size: 20,
									className: "shrink-0"
								}), E.jsx("span", {
									className: "font-medium tracking-wide",
									children: e.time
								})]
							}), E.jsxs("div", {
								className: "md:w-2/3 flex flex-col gap-2 md:border-l md:border-slate-200 md:pl-8",
								children: [E.jsx("h4", {
									className: "text-xl font-serif text-navy group-hover:text-[#29abe2] transition-colors",
									children: e.title
								}), e.speaker && E.jsxs("div", {
									className: "flex items-center gap-2 text-slate-600 mt-1",
									children: [E.jsx(bM, {
										size: 16,
										className: "text-slate-400 shrink-0"
									}), E.jsx("span", {
										className: "text-sm font-medium",
										children: e.speaker
									})]
								}), e.locationLink ? E.jsxs("a", {
									href: e.locationLink,
									target: "_blank",
									rel: "noopener noreferrer",
									className: "flex items-center gap-2 text-slate-500 hover:text-[#29abe2] transition-colors cursor-pointer group/loc w-fit",
									children: [E.jsx(Ds, {
										size: 16,
										className: "text-slate-400 group-hover/loc:text-[#29abe2] shrink-0 transition-colors"
									}), E.jsx("span", {
										className: "text-sm underline underline-offset-2 decoration-slate-300 group-hover/loc:decoration-[#29abe2]",
										children: e.location
									})]
								}) : E.jsxs("div", {
									className: "flex items-center gap-2 text-slate-500",
									children: [E.jsx(Ds, {
										size: 16,
										className: "text-slate-400 shrink-0"
									}), E.jsx("span", {
										className: "text-sm",
										children: e.location
									})]
								})]
							})]
						}, t))
					}, e)
				})
			})]
		})
	})
}

function hC() {
	return E.jsx("section", {
		className: "py-24 md:py-32 bg-slate-50 relative border-t border-slate-100 overflow-hidden",
		children: E.jsxs("div", {
			className: "max-w-6xl mx-auto px-6 md:px-12",
			children: [E.jsxs(Se.div, {
				initial: {
					opacity: 0,
					y: 30
				},
				whileInView: {
					opacity: 1,
					y: 0
				},
				viewport: {
					once: !0
				},
				transition: {
					duration: .8
				},
				className: "text-center mb-16",
				children: [E.jsx("h2", {
					className: "text-sm uppercase tracking-[0.3em] text-[#29abe2] mb-4 font-medium",
					children: "Location"
				}), E.jsx("h3", {
					className: "text-4xl md:text-5xl font-serif text-navy",
					children: "Venue Information"
				})]
			}), E.jsxs("div", {
				className: "bg-white rounded-3xl overflow-hidden shadow-xl border border-slate-100 flex flex-col lg:flex-row",
				children: [E.jsxs("div", {
					className: "lg:w-2/5 p-8 md:p-12 lg:p-16 flex flex-col justify-center",
					children: [E.jsx("div", {
						className: "w-12 h-12 bg-[#29abe2]/10 rounded-full flex items-center justify-center text-[#29abe2] mb-6",
						children: E.jsx(P3, {
							size: 24
						})
					}), E.jsx("h4", {
						className: "text-2xl md:text-3xl font-serif text-navy mb-4",
						children: "Official Accommodation"
					}), E.jsx("p", {
						className: "text-slate-600 leading-relaxed mb-8",
						children: "Experience world-class hospitality and seamless access to the conference events. The official accommodation partner ensures a comfortable environment for all attendees."
					}), E.jsx("div", {
						className: "space-y-6",
						children: E.jsxs("div", {
							className: "flex items-start gap-4",
							children: [E.jsx(Ds, {
								className: "text-[#29abe2] shrink-0 mt-1",
								size: 20
							}), E.jsxs("div", {
								children: [E.jsx("h5", {
									className: "font-medium text-navy mb-1",
									children: "The Fern Vadodara, Series by Marriott"
								}), E.jsxs("a", {
									href: "https://maps.app.goo.gl/ZcguYbYZT9jg3n3n9",
									target: "_blank",
									rel: "noopener noreferrer",
									className: "text-sm text-slate-500 hover:text-[#29abe2] leading-relaxed transition-colors block cursor-pointer",
									children: ["RC Dutt Rd, behind Alkapuri Petrol Pump, Vishwas Colony, Vadiwadi, Vadodara, Gujarat 390007"]
								})]
							})]
						})
					})]
				}), E.jsx("div", {
					className: "lg:w-3/5 h-[400px] lg:h-auto relative bg-slate-200",
					children: E.jsx("iframe", {
						src: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3691.150835664949!2d73.16865497589738!3d22.310134542537778!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x395fc9006d3a64ef%3A0xa032a9455ae936ba!2sThe%20Fern%20Residency%20Vadodara%2C%20Alkapuri%2C%20Series%20by%20Marriott!5e0!3m2!1sen!2sin!4v1792734302949!5m2!1sen!2sin",
						width: "100%",
						height: "100%",
						style: {
							border: 0
						},
						allowFullScreen: !0,
						loading: "lazy",
						referrerPolicy: "strict-origin-when-cross-origin",
						className: "absolute inset-0 w-full h-full border-0",
						title: "Venue Map"
					})
				})]
			})]
		})
	})
}

function mC() {
	return E.jsx("footer", {
		className: "bg-[#030917] pt-24 pb-12 border-t border-white/5",
		children: E.jsxs("div", {
			className: "max-w-4xl mx-auto px-6 text-center",
			children: [E.jsxs("h2", {
				className: "text-3xl font-serif text-white mb-12",
				children: [E.jsx("span", {
					className: "text-5xl lg:text-6xl",
					children: "2"
				}), E.jsx("sup", {
					children: "nd"
				}), " ENDOSPINE", E.jsx("br", {}), E.jsx("span", {
					className: "text-[#29abe2] italic font-light text-xl",
					children: "UBECON"
				})]
			}), E.jsxs("div", {
				className: "flex flex-col md:flex-row items-center justify-center gap-6 md:gap-12 mb-16",
				children: [E.jsxs("div", {
					className: "flex items-center gap-3 text-white/80",
					children: [E.jsx(Kg, {
						size: 16,
						className: "text-[#29abe2]"
					}), E.jsx("span", {
						className: "text-sm",
						children: E.jsx("a", {
							target: "_blank",
							rel: "noopener noreferrer",
							href: "tel:+919825127185",
							children: "+91 98251 27185"
						})
					})]
				}), E.jsxs("div", {
					className: "flex items-center gap-3 text-white/80",
					children: [E.jsx(Kg, {
						size: 16,
						className: "text-[#29abe2]"
					}), E.jsx("span", {
						className: "text-sm",
						children: E.jsx("a", {
							target: "_blank",
							rel: "noopener noreferrer",
							href: "tel:+919727137860",
							children: "+91 97271 37860"
						})
					})]
				}), E.jsxs("div", {
					className: "flex items-center gap-3 text-white/80",
					children: [E.jsx(uM, {
						size: 16,
						className: "text-[#29abe2]"
					}), E.jsx("span", {
						className: "text-sm",
						children: E.jsx("a", {
							target: "_blank",
							rel: "noopener noreferrer",
							href: "mailto:endospineubecon25@gmail.com",
							children: "endospineubecon25@gmail.com"
						})
					})]
				})]
			}), E.jsxs("div", {
				className: "text-xs uppercase tracking-[0.3em] text-white/30",
				children: ["Designed by ", E.jsx("a", {
					href: "https://invitebox.in/",
					target: "_blank",
					rel: "noreferrer",
					className: "text-[#29abe2] hover:underline",
					children: "Invite Box"
				})]
			})]
		})
	})
}

function pC() {
	const e = Z.useRef(null),
		[t, n] = Z.useState(!1),
		[r, i] = Z.useState(!1),
		[a, o] = Z.useState(!1);
	Z.useEffect(() => {
		const t = e.current;
		if (!t) return;
		i(!t.paused && !t.ended), n(t.muted);
		const r = () => i(!0),
			a = () => i(!1),
			o = () => n(t.muted);
		return t.addEventListener("play", r), t.addEventListener("playing", r), t.addEventListener("pause", a), t.addEventListener("volumechange", o), () => {
			t.removeEventListener("play", r), t.removeEventListener("playing", r), t.removeEventListener("pause", a), t.removeEventListener("volumechange", o)
		}
	}, []);
	return E.jsxs("div", {
		className: "fixed bottom-6 right-6 z-50 flex items-center",
		children: [E.jsx("audio", {
			id: "global-bg-music",
			ref: e,
			src: "./audio/bg-music.mp3",
			loop: !0,
			preload: "auto",
			playsInline: !0
		}), E.jsxs("div", {
			className: "absolute right-16 px-3 py-1.5 rounded-lg bg-navy/90 border border-white/10 text-white text-xs whitespace-nowrap shadow-xl backdrop-blur-md transition-all duration-200 pointer-events-none " + (a ? "opacity-100 translate-x-0" : "opacity-0 translate-x-2"),
			children: [E.jsx("span", {
				className: "font-medium text-[#29abe2]",
				children: !t && r ? "Music Playing" : "Music Muted"
			}), E.jsxs("span", {
				className: "text-white/60 ml-1",
				children: ["— Click to ", !t && r ? "mute" : "unmute"]
			})]
		}), E.jsxs("button", {
			onClick: () => {
				const t = e.current;
				if (t)
					if (t.paused || t.muted) {
						t.muted = !1, t.volume = .5;
						const e = t.play();
						void 0 !== e && e.then(() => {
							i(!0), n(!1)
						}).catch(() => {
							n(!1)
						})
					} else t.muted = !0, t.pause(), n(!0), i(!1)
			},
			onMouseEnter: () => o(!0),
			onMouseLeave: () => o(!1),
			"aria-label": !t && r ? "Mute background music" : "Unmute background music",
			className: "relative group w-14 h-14 rounded-full bg-[#051024]/90 hover:bg-[#071633] text-white border border-[#29abe2]/40 hover:border-[#29abe2] shadow-[0_8px_30px_rgb(0,0,0,0.4)] hover:shadow-[0_0_25px_rgba(41,171,226,0.6)] backdrop-blur-md flex items-center justify-center transition-all duration-300 transform hover:scale-105 active:scale-95 cursor-pointer",
			children: [!t && r && E.jsxs(E.Fragment, {
				children: [E.jsx("span", {
					className: "absolute inset-0 rounded-full border border-[#29abe2]/40 animate-ping opacity-60 pointer-events-none"
				}), E.jsx("span", {
					className: "absolute -inset-1 rounded-full bg-[#29abe2]/10 blur-sm pointer-events-none"
				})]
			}), !t && r ? E.jsx("div", {
				className: "relative flex items-center justify-center",
				children: E.jsx(SM, {
					className: "w-6 h-6 text-[#29abe2] transition-transform duration-200 group-hover:scale-110"
				})
			}) : E.jsx("div", {
				className: "relative flex items-center justify-center",
				children: E.jsx(EM, {
					className: "w-6 h-6 text-white/70 transition-transform duration-200 group-hover:scale-110"
				})
			})]
		})]
	})
}
const yC = () => typeof window < "u" && window.matchMedia("(max-width: 767.98px)").matches ? "./images/Laxmi-Vilas-Palace-Mob.avif" : "./images/Laxmi-Vilas-Palace2.avif";

function gC({
	onLoaded: e
}) {
	const [t, n] = Z.useState(!0);
	return Z.useEffect(() => {
		let e = !0;
		const t = new Promise(e => {
			const t = new Image;
			t.src = yC(), t.complete ? e() : (t.onload = () => e(), t.onerror = () => e())
		}),
			r = document.fonts && document.fonts.ready ? document.fonts.ready : Promise.resolve(),
			i = new Promise(e => {
				setTimeout(e, 3e3)
			}),
			a = new Promise(e => {
				setTimeout(e, 400)
			}),
			o = Promise.race([Promise.all([t, r]), i]);
		return Promise.all([o, a]).then(() => {
			e && n(!1)
		}), () => {
			e = !1
		}
	}, []), E.jsx(Go, {
		onExitComplete: e,
		children: t && E.jsxs(Se.div, {
			initial: {
				opacity: 1
			},
			exit: {
				opacity: 0
			},
			transition: {
				duration: .5,
				ease: "easeInOut"
			},
			className: "fixed inset-0 z-[9999] flex flex-col items-center justify-center bg-[#051024] text-white select-none pointer-events-auto",
			children: [E.jsx("div", {
				className: "absolute w-96 h-96 rounded-full bg-[#29abe2]/10 blur-3xl pointer-events-none"
			}), E.jsxs("div", {
				className: "relative flex flex-col items-center",
				children: [E.jsxs("div", {
					className: "relative w-16 h-16 mb-6",
					children: [E.jsx("div", {
						className: "absolute inset-0 rounded-full border-2 border-[#29abe2]/20"
					}), E.jsx("div", {
						className: "absolute inset-0 rounded-full border-2 border-transparent border-t-[#29abe2] animate-spin"
					}), E.jsx("div", {
						className: "absolute inset-2 rounded-full border border-transparent border-b-[#29abe2]/70 animate-[spin_1.5s_linear_infinite_reverse]"
					})]
				}), E.jsxs("h2", {
					className: "text-xl font-serif tracking-wider text-white mb-2",
					children: [E.jsxs("span", {
						className: "text-[#29abe2] font-semibold",
						children: ["2", E.jsx("sup", {
							children: "nd"
						})]
					}), " ENDOSPINE", " ", E.jsx("span", {
						className: "text-[#29abe2] italic font-light",
						children: "UBECON"
					})]
				}), E.jsx("div", {
					className: "w-36 h-0.5 bg-white/10 rounded-full overflow-hidden mt-3 relative",
					children: E.jsx("div", {
						className: "h-full bg-gradient-to-r from-transparent via-[#29abe2] to-transparent w-full animate-[pulse_1.5s_ease-in-out_infinite]"
					})
				}), E.jsx("p", {
					className: "text-[11px] uppercase tracking-[0.25em] text-white/50 mt-4 font-light",
					children: "Loading Experience"
				})]
			})]
		}, "app-minimal-loader")
	})
}

function vC({
	onEnter: e,
	isVisible: t
}) {
	return E.jsx(Go, {
		children: t && E.jsxs(Se.div, {
			initial: {
				opacity: 1
			},
			exit: {
				opacity: 0
			},
			transition: {
				duration: .8,
				ease: "easeInOut"
			},
			onClick: e,
			className: "fixed inset-0 z-[100] flex flex-col items-center justify-center bg-[#051024] text-white overflow-hidden cursor-pointer",
			children: [E.jsx("div", {
				className: "absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(41,171,226,0.15)_0%,transparent_60%)]"
			}), E.jsxs("div", {
				className: "relative z-10 flex flex-col items-center px-6 text-center",
				children: [E.jsx(Se.div, {
					initial: {
						y: 20,
						opacity: 0
					},
					animate: {
						y: 0,
						opacity: 1
					},
					transition: {
						delay: .2,
						duration: .6
					},
					children: E.jsx("div", {
						className: "mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-[#29abe2]/20 border border-[#29abe2]/40 mb-6",
						children: E.jsx(lM, {
							className: "w-6 h-6 text-[#29abe2]"
						})
					})
				}), E.jsxs(Se.div, {
					initial: {
						y: 20,
						opacity: 0
					},
					animate: {
						y: 0,
						opacity: 1
					},
					transition: {
						delay: .4,
						duration: .6
					},
					children: [E.jsx("div", {
						className: "text-[0.65rem] md:text-xs font-semibold tracking-[0.3em] text-[#29abe2] uppercase mb-4",
						children: "Medical Invitation"
					}), E.jsxs("h1", {
						className: "text-4xl md:text-5xl font-playfair mb-8 leading-tight",
						children: ["2", E.jsx("sup", {
							children: "nd"
						}), " ENDOSPINE", E.jsx("br", {}), E.jsx("span", {
							className: "text-[#29abe2] italic",
							children: "UBECON"
						})]
					})]
				}), E.jsxs(Se.button, {
					initial: {
						opacity: 0
					},
					animate: {
						opacity: 1
					},
					transition: {
						delay: .8,
						duration: .6
					},
					onClick: e,
					className: "group relative inline-flex items-center justify-center px-8 py-3 overflow-hidden rounded-full border border-[#29abe2] bg-transparent text-[#29abe2] transition-all hover:bg-[#29abe2] hover:text-white cursor-pointer",
					children: [E.jsx("span", {
						className: "absolute w-0 h-0 transition-all duration-500 ease-out bg-[#29abe2] rounded-full group-hover:w-56 group-hover:h-56"
					}), E.jsx("span", {
						className: "relative text-sm font-semibold tracking-widest uppercase",
						children: "Tap to Access"
					})]
				}), E.jsxs(Se.div, {
					initial: {
						opacity: 0
					},
					animate: {
						opacity: 1
					},
					transition: {
						delay: 1.2,
						duration: .6
					},
					className: "mt-10 flex flex-col items-center justify-center gap-2 text-white/50",
					children: [E.jsx(Se.div, {
						animate: {
							y: [0, -8, 0],
							scale: [1, .9, 1]
						},
						transition: {
							repeat: 1 / 0,
							duration: 1.5,
							ease: "easeInOut"
						},
						children: E.jsx(pM, {
							className: "w-6 h-6 text-[#29abe2]/70"
						})
					}), E.jsx("span", {
						className: "text-[10px] tracking-[0.2em] uppercase",
						children: "Tap Anywhere"
					})]
				})]
			})]
		})
	})
}

function bC() {
	const [e, t] = Z.useState(!0), [n, r] = Z.useState(!1);
	Z.useEffect(() => {
		document.body.style.overflow = n ? "unset" : "hidden"
	}, [n]);
	return E.jsxs(E.Fragment, {
		children: [E.jsx(vC, {
			isVisible: !n,
			onEnter: () => {
				r(!0);
				const e = document.getElementById("global-bg-music");
				e && (e.muted = !1, e.volume = .5, e.play().catch(e => console.log("Audio play blocked:", e)))
			}
		}), e && E.jsx(gC, {
			onLoaded: () => t(!1)
		}), E.jsxs("div", {
			className: "min-h-screen bg-slate-50 text-slate-900 font-inter " + (n ? "" : "pointer-events-none"),
			children: [E.jsxs("main", {
				children: [E.jsx(L3, {}), E.jsx(AM, {}), E.jsx(sC, {}), E.jsx(cC, {}), E.jsx(dC, {}), E.jsx(hC, {})]
			}), E.jsx(mC, {}), E.jsx(pC, {})]
		})]
	})
}
U2.createRoot(document.getElementById("root")).render(E.jsx(Z.StrictMode, {
	children: E.jsx(bC, {})
}));